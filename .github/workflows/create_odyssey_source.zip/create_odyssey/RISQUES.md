# Risques connus
1. **Jamais compilé** : première compilation = quelques erreurs possibles (signatures vanilla/NeoForge/Create). Les points les plus à surveiller :
   `RocketEntity` (dimensions, passagers), `ModFluids` (génériques DeferredHolder), `ModItems`/`ModArmor` (ArmorMaterial), `AlternatorBlock(Entity)` (API Create).
2. **Worldgen** : JSON écrit d'après les formats 1.21.1 (dimension_type, noise_settings, biomes, jigsaw). Au premier lancement serveur, lire les logs :
   toute erreur de parsing est nommée (fichier + champ).
3. **Équilibrage** non testé en jeu (coûts des fusées, énergie des machines, oxygène par seconde) : tout est réglable dans `config/create_odyssey-common.toml`
   ou dans `tools/catalog.py`.
4. **Textures** procédurales : correctes mais sobres ; à retoucher dans Blockbench / un éditeur pixel si souhaité.
5. **Non inclus** : distributeur d'oxygène, régulateur thermique, scènes Ponder, intégration JEI/EMI dédiée, ciels personnalisés, outils par matériau, jetpack, rover.
6. **Fabric / Forge / 26.x** : non pris en charge (Create n'y est pas disponible pour cette cible).
