# Décisions de conception
- Cible NeoForge 1.21.1 + Create 6.0.10 (dernière version de Minecraft avec Create officiel au 12/10/2026).
- Aucun mod additionnel : modèles en cubes (ModelPart) générés par script, textures procédurales (Pillow), sons de Minecraft uniquement.
- Électricité : FE. L'alternateur cinétique (API cinétique de Create) convertit la rotation en FE ; les câbles diffusent l'énergie voisin à voisin.
- Les trois machines (raffinerie, électrolyseur, liquéfacteur) partagent une seule classe ; recettes codées dans `ProcessorBlockEntity`.
- Dimensions : terrain par fonctions de densité (bruit) + règles de surface ; gravité via attributs vanille appliqués à l'entrée de la planète.
- Voyage : la fusée est recréée à destination (pas de transfert d'entité), pad d'atterrissage 7×7 généré une seule fois par planète.
- Pas de GUI de conteneur : machines et fusées s'utilisent par clic droit (état en barre d'action), seaux ou tuyaux Create ; seule la carte stellaire est un écran.
