package com.createodyssey.suit;

import com.createodyssey.registry.ModComponents;
import com.createodyssey.registry.ModFluids;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.templates.FluidHandlerItemStack;

/** Item fluid handler of a suit chestplate: only accepts and gives oxygen. Works with Create's spout too. */
public class OxygenTank extends FluidHandlerItemStack {
    public OxygenTank(ItemStack stack, int capacity) {
        super(ModComponents.FLUID_CONTENT, stack, capacity);
    }

    private static boolean isOxygen(FluidStack fluid) {
        return fluid.getFluid() == ModFluids.fluid("oxygen");
    }

    @Override
    public boolean canFillFluidType(FluidStack fluid) {
        return isOxygen(fluid);
    }

    @Override
    public boolean canDrainFluidType(FluidStack fluid) {
        return isOxygen(fluid);
    }
}
