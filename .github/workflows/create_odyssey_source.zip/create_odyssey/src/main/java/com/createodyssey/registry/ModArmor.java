package com.createodyssey.registry;

import com.createodyssey.Catalog;
import com.createodyssey.OdysseyMod;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModArmor {
    public static final DeferredRegister<ArmorMaterial> MATERIALS = DeferredRegister.create(Registries.ARMOR_MATERIAL, OdysseyMod.MODID);
    public static final List<DeferredHolder<ArmorMaterial, ArmorMaterial>> BY_TIER = new ArrayList<>();
    private static final String[] REPAIR = {"steel_sheet", "titanium_sheet", "stainless_steel_sheet", "tungsten_sheet", "stellar_alloy_sheet"};

    static {
        for (int t = 1; t <= 5; t++) {
            final int tier = t;
            BY_TIER.add(MATERIALS.register("suit_t" + t, () -> make(tier)));
        }
    }

    private static ArmorMaterial make(int tier) {
        EnumMap<ArmorItem.Type, Integer> defense = new EnumMap<>(ArmorItem.Type.class);
        int[] d = Catalog.SUIT_DEFENSE[tier - 1];
        defense.put(ArmorItem.Type.HELMET, d[0]);
        defense.put(ArmorItem.Type.CHESTPLATE, d[1]);
        defense.put(ArmorItem.Type.LEGGINGS, d[2]);
        defense.put(ArmorItem.Type.BOOTS, d[3]);
        defense.put(ArmorItem.Type.BODY, d[1]);
        return new ArmorMaterial(defense, 10 + tier * 2, SoundEvents.ARMOR_EQUIP_IRON,
                () -> Ingredient.of(BuiltInRegistries.ITEM.get(OdysseyMod.rl(REPAIR[tier - 1]))),
                List.of(new ArmorMaterial.Layer(OdysseyMod.rl("suit_t" + tier))),
                (float) Catalog.SUIT_TOUGHNESS[tier - 1], tier >= 4 ? 0.05F : 0.0F);
    }

    private ModArmor() {}
}
