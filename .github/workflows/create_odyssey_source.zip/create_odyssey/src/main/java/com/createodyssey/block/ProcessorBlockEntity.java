package com.createodyssey.block;

import com.createodyssey.OdysseyConfig;
import com.createodyssey.registry.ModBlockEntities;
import com.createodyssey.registry.ModFluids;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

/** Shared logic of the three electric fluid machines. Recipes are listed below (ids of our fluids or "water"). */
public class ProcessorBlockEntity extends BlockEntity {
    public record Recipe(String[] inIds, int[] inAmt, String[] outIds, int[] outAmt, int ticks, int fe) {}

    private static final List<Recipe> REFINERY = List.of(
            new Recipe(new String[]{"crude_oil"}, new int[]{1000}, new String[]{"kerosene", "insulating_resin"}, new int[]{600, 100}, 100, 40));
    private static final List<Recipe> ELECTROLYZER = List.of(
            new Recipe(new String[]{"water"}, new int[]{500}, new String[]{"hydrogen", "oxygen"}, new int[]{1000, 500}, 40, 60));
    private static final List<Recipe> LIQUEFIER = List.of(
            new Recipe(new String[]{"hydrogen"}, new int[]{1000}, new String[]{"liquid_hydrogen"}, new int[]{500}, 80, 120),
            new Recipe(new String[]{"oxygen"}, new int[]{1000}, new String[]{"liquid_oxygen"}, new int[]{500}, 80, 120),
            new Recipe(new String[]{"methane"}, new int[]{1000}, new String[]{"liquid_methane"}, new int[]{500}, 80, 120),
            new Recipe(new String[]{"liquid_hydrogen", "liquid_oxygen"}, new int[]{500, 250}, new String[]{"hydrolox"}, new int[]{750}, 60, 100),
            new Recipe(new String[]{"liquid_methane", "liquid_oxygen"}, new int[]{500, 500}, new String[]{"methalox"}, new int[]{1000}, 60, 100));

    private static final class Energy extends EnergyStorage {
        Energy() {
            super(20000, 1000, 0);
        }

        void consume(int n) {
            energy = Math.max(0, energy - n);
        }

        void set(int e) {
            energy = Math.max(0, Math.min(capacity, e));
        }
    }

    private final class Tank extends FluidTank {
        Tank() {
            super(4000);
        }

        @Override
        protected void onContentsChanged() {
            setChanged();
        }
    }

    private final Energy energy = new Energy();
    private final FluidTank[] in = {new Tank(), new Tank()};
    private final FluidTank[] out = {new Tank(), new Tank()};
    private int progress;
    private int activeIdx = -1;

    private final IFluidHandler handler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 4;
        }

        @Override
        public FluidStack getFluidInTank(int i) {
            return tank(i).getFluid();
        }

        @Override
        public int getTankCapacity(int i) {
            return tank(i).getCapacity();
        }

        @Override
        public boolean isFluidValid(int i, FluidStack s) {
            return i < 2 && acceptsInput(s);
        }

        @Override
        public int fill(FluidStack s, FluidAction a) {
            if (!acceptsInput(s)) {
                return 0;
            }
            for (FluidTank t : in) {
                if (!t.isEmpty() && t.getFluid().getFluid() == s.getFluid()) {
                    return t.fill(s, a);
                }
            }
            for (FluidTank t : in) {
                if (t.isEmpty()) {
                    return t.fill(s, a);
                }
            }
            return 0;
        }

        @Override
        public FluidStack drain(FluidStack s, FluidAction a) {
            for (FluidTank t : out) {
                if (!t.isEmpty() && t.getFluid().getFluid() == s.getFluid()) {
                    return t.drain(s.getAmount(), a);
                }
            }
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int max, FluidAction a) {
            for (FluidTank t : out) {
                if (!t.isEmpty()) {
                    return t.drain(max, a);
                }
            }
            return FluidStack.EMPTY;
        }
    };

    public ProcessorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PROCESSOR.get(), pos, state);
    }

    private FluidTank tank(int i) {
        return i < 2 ? in[i] : out[i - 2];
    }

    private List<Recipe> recipes() {
        if (getBlockState().getBlock() instanceof ProcessorBlock pb) {
            return switch (pb.kind()) {
                case REFINERY -> REFINERY;
                case ELECTROLYZER -> ELECTROLYZER;
                case LIQUEFIER -> LIQUEFIER;
            };
        }
        return List.of();
    }

    private boolean acceptsInput(FluidStack s) {
        if (s.isEmpty()) {
            return false;
        }
        for (Recipe r : recipes()) {
            for (String id : r.inIds()) {
                if (ModFluids.fluid(id) == s.getFluid()) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean hasInputs(Recipe r) {
        boolean[] used = new boolean[2];
        for (int i = 0; i < r.inIds().length; i++) {
            boolean found = false;
            for (int k = 0; k < 2 && !found; k++) {
                if (!used[k] && !in[k].isEmpty() && in[k].getFluid().getFluid() == ModFluids.fluid(r.inIds()[i]) && in[k].getFluidAmount() >= r.inAmt()[i]) {
                    used[k] = true;
                    found = true;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    private boolean fitsOutputs(Recipe r) {
        for (int i = 0; i < r.outIds().length; i++) {
            FluidStack add = ModFluids.stack(r.outIds()[i], r.outAmt()[i]);
            if (out[i].fill(add, IFluidHandler.FluidAction.SIMULATE) < r.outAmt()[i]) {
                return false;
            }
        }
        return true;
    }

    private int scaledFe(int fe) {
        return (int) Math.ceil(fe * OdysseyConfig.MACHINE_ENERGY_MULTIPLIER.get());
    }

    public void serverTick() {
        List<Recipe> list = recipes();
        if (activeIdx < 0 || activeIdx >= list.size()) {
            activeIdx = -1;
            progress = 0;
            for (int i = 0; i < list.size(); i++) {
                if (hasInputs(list.get(i)) && fitsOutputs(list.get(i))) {
                    activeIdx = i;
                    break;
                }
            }
            if (activeIdx < 0) {
                return;
            }
        }
        Recipe r = list.get(activeIdx);
        if (progress == 0 && !(hasInputs(r) && fitsOutputs(r))) {
            activeIdx = -1;
            return;
        }
        int fe = scaledFe(r.fe());
        if (energy.getEnergyStored() < fe) {
            return;
        }
        energy.consume(fe);
        progress++;
        setChanged();
        if (progress >= r.ticks()) {
            if (hasInputs(r) && fitsOutputs(r)) {
                boolean[] used = new boolean[2];
                for (int i = 0; i < r.inIds().length; i++) {
                    for (int k = 0; k < 2; k++) {
                        if (!used[k] && !in[k].isEmpty() && in[k].getFluid().getFluid() == ModFluids.fluid(r.inIds()[i]) && in[k].getFluidAmount() >= r.inAmt()[i]) {
                            in[k].drain(r.inAmt()[i], IFluidHandler.FluidAction.EXECUTE);
                            used[k] = true;
                            break;
                        }
                    }
                }
                for (int i = 0; i < r.outIds().length; i++) {
                    out[i].fill(ModFluids.stack(r.outIds()[i], r.outAmt()[i]), IFluidHandler.FluidAction.EXECUTE);
                }
            }
            progress = 0;
            activeIdx = -1;
        }
    }

    public IEnergyStorage energy() {
        return energy;
    }

    public IFluidHandler fluids() {
        return handler;
    }

    public Component statusMessage() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            FluidTank t = tank(i);
            if (!t.isEmpty()) {
                sb.append(t.getFluid().getHoverName().getString()).append(' ').append(t.getFluidAmount()).append(" mB  ");
            }
        }
        String tanks = sb.length() == 0 ? "-" : sb.toString().trim();
        return Component.translatable("message.create_odyssey.machine_status", getBlockState().getBlock().getName(), energy.getEnergyStored(), tanks);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("In0", in[0].writeToNBT(registries, new CompoundTag()));
        tag.put("In1", in[1].writeToNBT(registries, new CompoundTag()));
        tag.put("Out0", out[0].writeToNBT(registries, new CompoundTag()));
        tag.put("Out1", out[1].writeToNBT(registries, new CompoundTag()));
        tag.putInt("Energy", energy.getEnergyStored());
        tag.putInt("Progress", progress);
        tag.putInt("Active", activeIdx);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        in[0].readFromNBT(registries, tag.getCompound("In0"));
        in[1].readFromNBT(registries, tag.getCompound("In1"));
        out[0].readFromNBT(registries, tag.getCompound("Out0"));
        out[1].readFromNBT(registries, tag.getCompound("Out1"));
        energy.set(tag.getInt("Energy"));
        progress = tag.getInt("Progress");
        activeIdx = tag.contains("Active") ? tag.getInt("Active") : -1;
    }
}
