package com.createodyssey.rocket;

import com.createodyssey.Catalog;
import com.createodyssey.registry.ModComponents;
import com.createodyssey.registry.ModEntities;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.SimpleFluidContent;

public class RocketItem extends Item {
    private final int tier;

    public RocketItem(Properties properties, int tier) {
        super(properties);
        this.tier = tier;
    }

    public int tier() {
        return tier;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos clicked = ctx.getClickedPos();
        Player player = ctx.getPlayer();
        int size = Catalog.PAD_SIZE[tier - 1];
        if (!PadUtil.isPlate(level, clicked)) {
            if (!level.isClientSide && player != null) {
                player.displayClientMessage(Component.translatable("message.create_odyssey.not_on_pad"), true);
            }
            return InteractionResult.FAIL;
        }
        BlockPos center = PadUtil.findCenter(level, clicked, size);
        if (center == null) {
            if (!level.isClientSide && player != null) {
                player.displayClientMessage(Component.translatable("message.create_odyssey.pad_missing", PadUtil.bestCount(level, clicked, size), size * size), true);
            }
            return InteractionResult.FAIL;
        }
        if (!level.isClientSide) {
            RocketEntity rocket = ModEntities.ROCKET.get().create(level);
            if (rocket == null) {
                return InteractionResult.FAIL;
            }
            rocket.setTier(tier);
            rocket.moveTo(center.getX() + 0.5D, center.getY() + 1.0D, center.getZ() + 0.5D, ctx.getHorizontalDirection().toYRot(), 0.0F);
            SimpleFluidContent fuel = ctx.getItemInHand().get(ModComponents.FLUID_CONTENT.get());
            if (fuel != null && !fuel.isEmpty()) {
                FluidStack fs = fuel.copy();
                rocket.getTank().setFluid(fs);
            }
            rocket.rememberHome();
            level.addFreshEntity(rocket);
            if (player == null || !player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.create_odyssey.rocket", tier).withStyle(ChatFormatting.GRAY));
        SimpleFluidContent fuel = stack.get(ModComponents.FLUID_CONTENT.get());
        if (fuel != null && !fuel.isEmpty()) {
            tooltip.add(Component.literal(fuel.copy().getHoverName().getString() + " " + fuel.copy().getAmount() + " mB").withStyle(ChatFormatting.GOLD));
        }
    }
}
