package com.createodyssey.net;

import com.createodyssey.OdysseyMod;
import com.createodyssey.rocket.RocketEntity;
import com.createodyssey.rocket.Travel;
import java.util.function.Consumer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Three tiny packets: open the star map (server to client), launch and choose a destination (client to server). */
public final class OdysseyNetwork {
    private OdysseyNetwork() {}

    /** Set by the client at startup; stays a no-op on a dedicated server. */
    public static Consumer<OpenStarMapPayload> clientOpenStarMap = p -> { };

    public record OpenStarMapPayload(int rocketId, int tier, int fuel, int planetIndex) implements CustomPacketPayload {
        public static final Type<OpenStarMapPayload> TYPE = new Type<>(OdysseyMod.rl("open_star_map"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenStarMapPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, OpenStarMapPayload::rocketId,
                ByteBufCodecs.VAR_INT, OpenStarMapPayload::tier,
                ByteBufCodecs.VAR_INT, OpenStarMapPayload::fuel,
                ByteBufCodecs.VAR_INT, OpenStarMapPayload::planetIndex,
                OpenStarMapPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record LaunchPayload(int rocketId) implements CustomPacketPayload {
        public static final Type<LaunchPayload> TYPE = new Type<>(OdysseyMod.rl("launch"));
        public static final StreamCodec<RegistryFriendlyByteBuf, LaunchPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, LaunchPayload::rocketId, LaunchPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record DestinationPayload(int rocketId, int dest) implements CustomPacketPayload {
        public static final Type<DestinationPayload> TYPE = new Type<>(OdysseyMod.rl("destination"));
        public static final StreamCodec<RegistryFriendlyByteBuf, DestinationPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, DestinationPayload::rocketId,
                ByteBufCodecs.VAR_INT, DestinationPayload::dest,
                DestinationPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(OpenStarMapPayload.TYPE, OpenStarMapPayload.CODEC, OdysseyNetwork::onOpenStarMap);
        registrar.playToServer(LaunchPayload.TYPE, LaunchPayload.CODEC, OdysseyNetwork::onLaunch);
        registrar.playToServer(DestinationPayload.TYPE, DestinationPayload.CODEC, OdysseyNetwork::onDestination);
    }

    private static void onOpenStarMap(OpenStarMapPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> clientOpenStarMap.accept(payload));
    }

    private static void onLaunch(LaunchPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp && sp.level().getEntity(payload.rocketId()) instanceof RocketEntity rocket && sp.getVehicle() == rocket) {
                rocket.tryLaunch(sp);
            }
        });
    }

    private static void onDestination(DestinationPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp && sp.level().getEntity(payload.rocketId()) instanceof RocketEntity rocket
                    && sp.getVehicle() == rocket && rocket.getState() == RocketEntity.AWAIT) {
                Travel.go(sp, rocket, payload.dest());
            }
        });
    }
}
