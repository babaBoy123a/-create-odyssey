package com.createodyssey.suit;

import com.createodyssey.Catalog;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

/** Space suit piece. The chestplate carries the oxygen tank. */
public class SuitArmorItem extends ArmorItem {
    private final int tier;

    public SuitArmorItem(Holder<ArmorMaterial> material, ArmorItem.Type type, int tier, Properties properties) {
        super(material, type, properties);
        this.tier = tier;
    }

    public int tier() {
        return tier;
    }

    public int coldResist() {
        return Catalog.SUIT_COLD[tier - 1];
    }

    public int heatResist() {
        return Catalog.SUIT_HEAT[tier - 1];
    }

    public static int oxygenCapacity(int tier) {
        return Catalog.SUIT_O2[tier - 1];
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.create_odyssey.suit", coldResist(), heatResist()).withStyle(ChatFormatting.AQUA));
        if (getType() == ArmorItem.Type.CHESTPLATE) {
            IFluidHandlerItem h = stack.getCapability(Capabilities.FluidHandler.ITEM);
            if (h != null) {
                tooltip.add(Component.translatable("tooltip.create_odyssey.oxygen", h.getFluidInTank(0).getAmount(), h.getTankCapacity(0)).withStyle(ChatFormatting.BLUE));
            }
        }
    }
}
