package com.createodyssey.registry;

import com.createodyssey.Catalog;
import com.createodyssey.OdysseyMod;
import com.createodyssey.block.AlternatorBlock;
import com.createodyssey.block.CableBlock;
import com.createodyssey.block.FuelingPortBlock;
import com.createodyssey.block.LaunchConsoleBlock;
import com.createodyssey.block.LaunchPadPlateBlock;
import com.createodyssey.block.ProcessorBlock;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(OdysseyMod.MODID);
    /** Every block that gets a block item (fluid blocks are registered by ModFluids and have none). */
    public static final Map<String, DeferredBlock<? extends Block>> ALL = new LinkedHashMap<>();

    public static final DeferredBlock<AlternatorBlock> ALTERNATOR;
    public static final DeferredBlock<CableBlock> CABLE;
    public static final DeferredBlock<ProcessorBlock> REFINERY;
    public static final DeferredBlock<ProcessorBlock> ELECTROLYZER;
    public static final DeferredBlock<ProcessorBlock> LIQUEFIER;
    public static final DeferredBlock<LaunchPadPlateBlock> PAD_PLATE;
    public static final DeferredBlock<LaunchConsoleBlock> CONSOLE;
    public static final DeferredBlock<FuelingPortBlock> FUELING_PORT;

    static {
        for (Catalog.BlockSpec s : Catalog.BLOCKS) {
            BlockBehaviour.Properties p = BlockBehaviour.Properties.of()
                    .strength(s.hardness(), s.resistance())
                    .sound(sound(s.sound()))
                    .lightLevel(state -> s.light());
            if (s.requiresTool()) {
                p = p.requiresCorrectToolForDrops();
            }
            ALL.put(s.id(), BLOCKS.registerBlock(s.id(), Block::new, p));
        }
        ALTERNATOR = machine("kinetic_alternator", AlternatorBlock::new);
        CABLE = BLOCKS.registerBlock("power_cable", CableBlock::new,
                BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(SoundType.METAL).noOcclusion());
        ALL.put("power_cable", CABLE);
        REFINERY = BLOCKS.registerBlock("electric_refinery", p -> new ProcessorBlock(p, ProcessorBlock.Kind.REFINERY), machineProps());
        ELECTROLYZER = BLOCKS.registerBlock("electrolyzer", p -> new ProcessorBlock(p, ProcessorBlock.Kind.ELECTROLYZER), machineProps());
        LIQUEFIER = BLOCKS.registerBlock("cryo_liquefier", p -> new ProcessorBlock(p, ProcessorBlock.Kind.LIQUEFIER), machineProps());
        ALL.put("electric_refinery", REFINERY);
        ALL.put("electrolyzer", ELECTROLYZER);
        ALL.put("cryo_liquefier", LIQUEFIER);
        PAD_PLATE = machine("launch_pad_plate", LaunchPadPlateBlock::new);
        CONSOLE = machine("launch_console", LaunchConsoleBlock::new);
        FUELING_PORT = machine("fueling_port", FuelingPortBlock::new);
    }

    private static BlockBehaviour.Properties machineProps() {
        return BlockBehaviour.Properties.of().strength(4.0F, 6.0F).sound(SoundType.METAL).requiresCorrectToolForDrops();
    }

    private static <B extends Block> DeferredBlock<B> machine(String id, java.util.function.Function<BlockBehaviour.Properties, B> factory) {
        DeferredBlock<B> b = BLOCKS.registerBlock(id, factory, machineProps());
        ALL.put(id, b);
        return b;
    }

    private static SoundType sound(String name) {
        return switch (name) {
            case "METAL" -> SoundType.METAL;
            case "GRAVEL" -> SoundType.GRAVEL;
            case "SAND" -> SoundType.SAND;
            case "GLASS" -> SoundType.GLASS;
            case "AMETHYST" -> SoundType.AMETHYST;
            default -> SoundType.STONE;
        };
    }

    private ModBlocks() {}
}
