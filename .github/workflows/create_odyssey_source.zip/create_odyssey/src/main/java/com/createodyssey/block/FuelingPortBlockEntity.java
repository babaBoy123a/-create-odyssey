package com.createodyssey.block;

import com.createodyssey.registry.ModBlockEntities;
import com.createodyssey.rocket.RocketEntity;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;

public class FuelingPortBlockEntity extends BlockEntity {
    private final IFluidHandler handler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int i) {
            RocketEntity r = rocket();
            return r == null ? FluidStack.EMPTY : r.getTank().getFluid();
        }

        @Override
        public int getTankCapacity(int i) {
            RocketEntity r = rocket();
            return r == null ? 0 : r.getTank().getCapacity();
        }

        @Override
        public boolean isFluidValid(int i, FluidStack s) {
            RocketEntity r = rocket();
            return r != null && r.getTank().isFluidValid(s);
        }

        @Override
        public int fill(FluidStack s, FluidAction a) {
            RocketEntity r = rocket();
            return r == null ? 0 : r.fillFuel(s, a);
        }

        @Override
        public FluidStack drain(FluidStack s, FluidAction a) {
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int max, FluidAction a) {
            return FluidStack.EMPTY;
        }
    };

    public FuelingPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FUELING_PORT.get(), pos, state);
    }

    private RocketEntity rocket() {
        if (level == null) {
            return null;
        }
        List<RocketEntity> list = level.getEntitiesOfClass(RocketEntity.class, new AABB(worldPosition).inflate(6.0D, 4.0D, 6.0D),
                r -> r.getState() == RocketEntity.IDLE);
        RocketEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (RocketEntity r : list) {
            double d = r.distanceToSqr(worldPosition.getX() + 0.5D, worldPosition.getY() + 0.5D, worldPosition.getZ() + 0.5D);
            if (d < bestD) {
                bestD = d;
                best = r;
            }
        }
        return best;
    }

    public IFluidHandler fluids() {
        return handler;
    }
}
