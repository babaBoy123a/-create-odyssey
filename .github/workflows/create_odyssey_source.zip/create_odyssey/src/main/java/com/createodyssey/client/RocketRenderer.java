package com.createodyssey.client;

import com.createodyssey.OdysseyMod;
import com.createodyssey.rocket.RocketEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Renders the five rocket models (one per tier), shaking during the countdown. */
public class RocketRenderer extends EntityRenderer<RocketEntity> {
    private final RocketModel[] models = new RocketModel[5];

    public RocketRenderer(EntityRendererProvider.Context context) {
        super(context);
        for (int t = 1; t <= 5; t++) {
            models[t - 1] = new RocketModel(context.bakeLayer(ClientSetup.layer("rocket_t" + t)));
        }
    }

    @Override
    public ResourceLocation getTextureLocation(RocketEntity entity) {
        return OdysseyMod.rl("textures/entity/rocket_t" + entity.getTier() + ".png");
    }

    @Override
    public void render(RocketEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
        if (entity.getState() == RocketEntity.COUNTDOWN || entity.getState() == RocketEntity.ASCEND) {
            float t = entity.tickCount + partialTick;
            float amp = entity.getState() == RocketEntity.ASCEND ? 0.03F : 0.015F;
            poseStack.translate(Mth.sin(t * 2.7F) * amp, 0.0D, Mth.cos(t * 3.1F) * amp);
        }
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0F, -1.501F, 0.0F);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        models[entity.getTier() - 1].renderToBuffer(poseStack, vc, packedLight, OverlayTexture.NO_OVERLAY, -1);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }
}
