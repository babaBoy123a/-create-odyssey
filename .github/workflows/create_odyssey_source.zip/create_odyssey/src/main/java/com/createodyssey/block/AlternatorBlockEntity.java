package com.createodyssey.block;

import com.createodyssey.OdysseyConfig;
import com.createodyssey.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

public class AlternatorBlockEntity extends KineticBlockEntity {
    /** Output-only buffer. */
    private static final class Output extends EnergyStorage {
        Output() {
            super(8000, 0, 2000);
        }

        void add(int n) {
            energy = Math.min(capacity, energy + n);
        }

        void remove(int n) {
            energy = Math.max(0, energy - n);
        }

        void set(int e) {
            energy = Math.max(0, Math.min(capacity, e));
        }
    }

    private final Output buffer = new Output();

    public AlternatorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ALTERNATOR.get(), pos, state);
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) {
            return;
        }
        float speed = Math.abs(getSpeed());
        if (speed > 0.0F) {
            buffer.add((int) (speed * OdysseyConfig.FE_PER_RPM.get()));
        }
        if (buffer.getEnergyStored() <= 0) {
            return;
        }
        for (Direction d : Direction.values()) {
            IEnergyStorage target = level.getCapability(Capabilities.EnergyStorage.BLOCK, worldPosition.relative(d), d.getOpposite());
            if (target == null || !target.canReceive()) {
                continue;
            }
            int moved = target.receiveEnergy(Math.min(buffer.getEnergyStored(), 2000), false);
            buffer.remove(moved);
            if (buffer.getEnergyStored() <= 0) {
                break;
            }
        }
    }

    public IEnergyStorage energy() {
        return buffer;
    }

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        compound.putInt("Energy", buffer.getEnergyStored());
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        buffer.set(compound.getInt("Energy"));
    }
}
