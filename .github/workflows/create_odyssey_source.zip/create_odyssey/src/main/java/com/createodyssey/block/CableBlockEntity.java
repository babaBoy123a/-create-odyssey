package com.createodyssey.block;

import com.createodyssey.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

public class CableBlockEntity extends BlockEntity {
    private static final class Buffer extends EnergyStorage {
        Buffer() {
            super(2000, 1000, 1000);
        }

        @Override
        public boolean canExtract() {
            return false;
        }

        void remove(int n) {
            energy = Math.max(0, energy - n);
        }

        void set(int e) {
            energy = Math.max(0, Math.min(capacity, e));
        }
    }

    private final Buffer buffer = new Buffer();

    public CableBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CABLE.get(), pos, state);
    }

    public IEnergyStorage energy() {
        return buffer;
    }

    public void serverTick() {
        if (level == null || buffer.getEnergyStored() <= 0) {
            return;
        }
        for (Direction d : Direction.values()) {
            BlockPos np = worldPosition.relative(d);
            IEnergyStorage n = level.getCapability(Capabilities.EnergyStorage.BLOCK, np, d.getOpposite());
            if (n == null || !n.canReceive()) {
                continue;
            }
            boolean cable = level.getBlockState(np).getBlock() instanceof CableBlock;
            if (cable && n.getEnergyStored() >= buffer.getEnergyStored()) {
                continue;
            }
            int moved = n.receiveEnergy(Math.min(buffer.getEnergyStored(), 1000), false);
            buffer.remove(moved);
            if (buffer.getEnergyStored() <= 0) {
                return;
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", buffer.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        buffer.set(tag.getInt("Energy"));
    }
}
