package com.createodyssey.registry;

import com.createodyssey.Catalog;
import com.createodyssey.OdysseyMod;
import com.createodyssey.entity.MobSpec;
import com.createodyssey.entity.MobSpecs;
import com.createodyssey.rocket.RocketItem;
import com.createodyssey.suit.SuitArmorItem;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyItem;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(OdysseyMod.MODID);
    public static final List<DeferredItem<RocketItem>> ROCKETS = new ArrayList<>();
    public static final Map<String, DeferredItem<SuitArmorItem>> SUITS = new LinkedHashMap<>();

    static {
        for (String id : Catalog.SIMPLE_ITEMS) {
            ITEMS.registerSimpleItem(id);
        }
        for (String id : Catalog.TRANSITIONAL_ITEMS) {
            ITEMS.registerItem(id, SequencedAssemblyItem::new);
        }
        for (Map.Entry<String, net.neoforged.neoforge.registries.DeferredBlock<? extends net.minecraft.world.level.block.Block>> e : ModBlocks.ALL.entrySet()) {
            ITEMS.registerSimpleBlockItem(e.getValue());
        }
        ArmorItem.Type[] types = {ArmorItem.Type.HELMET, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.LEGGINGS, ArmorItem.Type.BOOTS};
        for (int t = 1; t <= 5; t++) {
            final int tier = t;
            ROCKETS.add(ITEMS.registerItem("rocket_t" + t, p -> new RocketItem(p.stacksTo(1), tier)));
            for (ArmorItem.Type type : types) {
                SUITS.put("suit_t" + t + "_" + type.getName(), ITEMS.registerItem("suit_t" + t + "_" + type.getName(),
                        p -> new SuitArmorItem(ModArmor.BY_TIER.get(tier - 1), type, tier,
                                p.durability(type.getDurability(Catalog.SUIT_DURABILITY[tier - 1])).stacksTo(1))));
            }
        }
        for (MobSpec spec : MobSpecs.BY_ID.values()) {
            ITEMS.register(spec.id() + "_spawn_egg", () -> new DeferredSpawnEggItem(ModEntities.MOBS.get(spec.id()),
                    spec.eggPrimary(), spec.eggSecondary(), new Item.Properties()));
        }
    }

    public static Item[] suitChestplates() {
        return SUITS.entrySet().stream().filter(e -> e.getKey().endsWith("_chestplate")).map(e -> (Item) e.getValue().get()).toArray(Item[]::new);
    }

    private ModItems() {}
}
