package com.createodyssey.client;

import com.createodyssey.OdysseyMod;
import com.createodyssey.net.OdysseyNetwork;
import com.createodyssey.rocket.RocketEntity;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = OdysseyMod.MODID, value = Dist.CLIENT)
public final class ClientGameEvents {
    private ClientGameEvents() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        while (ClientSetup.LAUNCH_KEY.consumeClick()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof RocketEntity rocket) {
                PacketDistributor.sendToServer(new OdysseyNetwork.LaunchPayload(rocket.getId()));
            }
        }
    }
}
