package com.createodyssey.registry;

import com.createodyssey.OdysseyMod;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OdysseyMod.MODID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.create_odyssey"))
            .icon(() -> new ItemStack(ModItems.ROCKETS.get(0).get()))
            .displayItems((params, output) -> ModItems.ITEMS.getEntries().forEach(e -> output.accept(e.get())))
            .build());

    private ModTabs() {}
}
