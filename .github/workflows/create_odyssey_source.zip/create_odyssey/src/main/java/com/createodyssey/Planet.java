package com.createodyssey;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** A destination planet (backed by a data-driven dimension). */
public final class Planet {
    public static final int PAD_X = 8;
    public static final int PAD_Z = 8;
    private static final List<Planet> ALL = new ArrayList<>();

    static {
        for (Catalog.PlanetSpec s : Catalog.PLANETS) {
            ALL.add(new Planet(s));
        }
    }

    public final Catalog.PlanetSpec spec;
    public final ResourceKey<Level> dimension;

    private Planet(Catalog.PlanetSpec spec) {
        this.spec = spec;
        this.dimension = ResourceKey.create(Registries.DIMENSION, OdysseyMod.rl(spec.id()));
    }

    public static List<Planet> all() {
        return ALL;
    }

    public static Planet of(Level level) {
        if (level == null) {
            return null;
        }
        for (Planet p : ALL) {
            if (p.dimension.equals(level.dimension())) {
                return p;
            }
        }
        return null;
    }

    public static int indexOf(Planet p) {
        return p == null ? -1 : ALL.indexOf(p);
    }

    public String id() {
        return spec.id();
    }

    public int tier() {
        return spec.tier();
    }

    public int cost() {
        return spec.cost();
    }

    public double gravity() {
        return spec.gravity();
    }

    public int coldLevel(Level level) {
        if (spec.dayNight()) {
            return level.isDay() ? 0 : spec.cold();
        }
        return spec.cold();
    }

    public int heatLevel(Level level) {
        if (spec.dayNight()) {
            return level.isDay() ? spec.heat() : 0;
        }
        return spec.heat();
    }

    public Component displayName() {
        return Component.translatable("planet." + OdysseyMod.MODID + "." + spec.id());
    }
}
