package com.createodyssey;

import com.createodyssey.registry.ModArmor;
import com.createodyssey.registry.ModBlockEntities;
import com.createodyssey.registry.ModBlocks;
import com.createodyssey.registry.ModComponents;
import com.createodyssey.registry.ModEntities;
import com.createodyssey.registry.ModFluids;
import com.createodyssey.registry.ModItems;
import com.createodyssey.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

/** Create: Odyssey - space exploration addon for Create. */
@Mod(OdysseyMod.MODID)
public class OdysseyMod {
    public static final String MODID = "create_odyssey";

    public static ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public OdysseyMod(IEventBus bus, ModContainer container) {
        // ModFluids registers into the block and item registers, so touch it first.
        ModFluids.FLUID_TYPES.register(bus);
        ModFluids.FLUIDS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.TYPES.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModComponents.TYPES.register(bus);
        ModArmor.MATERIALS.register(bus);
        ModTabs.TABS.register(bus);
        container.registerConfig(ModConfig.Type.COMMON, OdysseyConfig.SPEC);
    }
}
