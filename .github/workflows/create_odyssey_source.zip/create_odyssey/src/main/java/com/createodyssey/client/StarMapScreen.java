package com.createodyssey.client;

import com.createodyssey.Planet;
import com.createodyssey.net.OdysseyNetwork;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Destination chooser shown when the rocket reaches the top of its ascent. */
public class StarMapScreen extends Screen {
    private final OdysseyNetwork.OpenStarMapPayload data;

    public static void open(OdysseyNetwork.OpenStarMapPayload payload) {
        Minecraft.getInstance().setScreen(new StarMapScreen(payload));
    }

    protected StarMapScreen(OdysseyNetwork.OpenStarMapPayload data) {
        super(Component.translatable("screen.create_odyssey.star_map"));
        this.data = data;
    }

    @Override
    protected void init() {
        List<Planet> planets = Planet.all();
        int cx = this.width / 2;
        int y = this.height / 2 - (planets.size() + 2) * 13;
        for (int i = 0; i < planets.size(); i++) {
            final int dest = i;
            Planet p = planets.get(i);
            boolean current = i == data.planetIndex();
            boolean unlocked = data.tier() >= p.tier();
            boolean fuelOk = data.fuel() >= p.cost();
            Component label = p.displayName().copy().append(Component.literal("  (T" + p.tier() + ")"));
            Component tip = unlocked
                    ? Component.translatable("screen.create_odyssey.hazard", String.format("%.2f", p.gravity()), p.spec.cold(), p.spec.heat())
                            .append(Component.literal("  -  ")).append(Component.translatable("screen.create_odyssey.cost", p.cost()))
                    : Component.translatable("screen.create_odyssey.locked", p.tier());
            Button b = Button.builder(label, btn -> send(dest)).bounds(cx - 110, y, 220, 20).tooltip(Tooltip.create(tip)).build();
            b.active = unlocked && !current && fuelOk;
            addRenderableWidget(b);
            y += 24;
        }
        if (data.planetIndex() >= 0) {
            Planet here = planets.get(data.planetIndex());
            Button earth = Button.builder(Component.translatable("screen.create_odyssey.earth"), btn -> send(planets.size()))
                    .bounds(cx - 110, y, 220, 20).tooltip(Tooltip.create(Component.translatable("screen.create_odyssey.cost", here.cost()))).build();
            earth.active = data.fuel() >= here.cost();
            addRenderableWidget(earth);
            y += 24;
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.create_odyssey.cancel"), btn -> send(-1))
                .bounds(cx - 110, y + 6, 220, 20).build());
    }

    private void send(int dest) {
        PacketDistributor.sendToServer(new OdysseyNetwork.DestinationPayload(data.rocketId(), dest));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);
        g.drawCenteredString(this.font, Component.literal("T" + data.tier() + "  -  " + data.fuel() + " mB"), this.width / 2, 34, 0xFFD27F);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
