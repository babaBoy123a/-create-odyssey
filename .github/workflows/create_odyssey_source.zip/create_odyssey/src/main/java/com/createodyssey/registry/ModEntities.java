package com.createodyssey.registry;

import com.createodyssey.OdysseyMod;
import com.createodyssey.entity.MobSpec;
import com.createodyssey.entity.MobSpecs;
import com.createodyssey.entity.OdysseyCritter;
import com.createodyssey.entity.OdysseyMob;
import com.createodyssey.rocket.RocketEntity;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, OdysseyMod.MODID);
    public static final Map<String, Supplier<EntityType<? extends Mob>>> MOBS = new LinkedHashMap<>();

    public static final DeferredHolder<EntityType<?>, EntityType<RocketEntity>> ROCKET = ENTITIES.register("rocket",
            () -> EntityType.Builder.<RocketEntity>of(RocketEntity::new, MobCategory.MISC)
                    .sized(3.2F, 10.7F).clientTrackingRange(12).updateInterval(2).fireImmune().build("rocket"));

    static {
        for (MobSpec spec : MobSpecs.BY_ID.values()) {
            DeferredHolder<EntityType<?>, EntityType<? extends Mob>> holder = ENTITIES.register(spec.id(), () -> build(spec));
            MOBS.put(spec.id(), holder);
        }
    }

    private static EntityType<? extends Mob> build(MobSpec spec) {
        if (spec.behavior() == MobSpec.Behavior.PASSIVE) {
            EntityType.Builder<OdysseyCritter> b = EntityType.Builder.of(OdysseyCritter::new, MobCategory.CREATURE);
            b.sized(spec.width(), spec.height()).clientTrackingRange(8);
            return b.build(spec.id());
        }
        EntityType.Builder<OdysseyMob> b = EntityType.Builder.of(OdysseyMob::new, MobCategory.MONSTER);
        b.sized(spec.width(), spec.height()).clientTrackingRange(spec.boss() ? 12 : 8);
        if (spec.effect().equals("fire") || spec.boss()) {
            b.fireImmune();
        }
        return b.build(spec.id());
    }

    private ModEntities() {}
}
