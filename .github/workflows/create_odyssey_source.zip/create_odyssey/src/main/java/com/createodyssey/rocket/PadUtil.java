package com.createodyssey.rocket;

import com.createodyssey.Catalog;
import com.createodyssey.block.LaunchPadPlateBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/** Launch pad geometry helpers (a pad is a full square of launch plates). */
public final class PadUtil {
    private PadUtil() {}

    public static boolean isPlate(Level level, BlockPos pos) {
        return level.getBlockState(pos).getBlock() instanceof LaunchPadPlateBlock;
    }

    public static int plateCount(Level level, BlockPos center, int size) {
        int r = size / 2;
        int n = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (isPlate(level, center.offset(dx, 0, dz))) {
                    n++;
                }
            }
        }
        return n;
    }

    /** Finds the centre of a complete size x size pad that contains the clicked plate, or null. */
    public static BlockPos findCenter(Level level, BlockPos clicked, int size) {
        int r = size / 2;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                BlockPos c = clicked.offset(dx, 0, dz);
                if (plateCount(level, c, size) == size * size) {
                    return c;
                }
            }
        }
        return null;
    }

    public static int bestCount(Level level, BlockPos clicked, int size) {
        int r = size / 2;
        int best = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                best = Math.max(best, plateCount(level, clicked.offset(dx, 0, dz), size));
            }
        }
        return best;
    }

    /** Returns null when the space above the pad is free, otherwise the lang key suffix of the error. */
    public static String clearanceError(Level level, BlockPos center, int tier) {
        int height = (int) Math.ceil(Catalog.ROCKET_HEIGHT[tier - 1]) + 3;
        for (int dy = 1; dy <= height; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos p = center.offset(dx, dy, dz);
                    if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) {
                        return "pad_blocked";
                    }
                }
            }
        }
        return null;
    }
}
