package com.createodyssey.entity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Hostile or neutral planet creature, fully described by its MobSpec. */
public class OdysseyMob extends Monster {
    private MobSpec cached;
    private final ServerBossEvent bossEvent;

    public OdysseyMob(EntityType<? extends OdysseyMob> type, Level level) {
        super(type, level);
        MobSpec s = spec();
        if (s.flying()) {
            this.moveControl = new FlyingMoveControl(this, 20, true);
            this.setNoGravity(true);
        }
        this.xpReward = s.boss() ? 250 : 8;
        this.bossEvent = s.boss()
                ? new ServerBossEvent(Component.translatable("entity.create_odyssey." + s.id()), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS)
                : null;
    }

    public MobSpec spec() {
        if (cached == null) {
            cached = MobSpecs.BY_ID.get(BuiltInRegistries.ENTITY_TYPE.getKey(getType()).getPath());
        }
        return cached;
    }

    public static AttributeSupplier.Builder createAttributes(MobSpec s) {
        AttributeSupplier.Builder b = Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, s.health())
                .add(Attributes.ATTACK_DAMAGE, s.damage())
                .add(Attributes.MOVEMENT_SPEED, s.speed())
                .add(Attributes.ARMOR, s.armor())
                .add(Attributes.KNOCKBACK_RESISTANCE, s.kbResistance())
                .add(Attributes.FOLLOW_RANGE, 28.0D);
        if (s.flying()) {
            b.add(Attributes.FLYING_SPEED, s.speed());
        }
        return b;
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        if (spec().flying()) {
            FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
            nav.setCanOpenDoors(false);
            nav.setCanFloat(true);
            nav.setCanPassDoors(true);
            return nav;
        }
        return super.createNavigation(level);
    }

    @Override
    protected void registerGoals() {
        MobSpec s = spec();
        if (!s.flying()) {
            this.goalSelector.addGoal(0, new FloatGoal(this));
        }
        if (s.leap()) {
            this.goalSelector.addGoal(1, new LeapAtTargetGoal(this, 0.5F));
        }
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, false));
        if (s.flying()) {
            this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        } else {
            this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        }
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        if (s.behavior() == MobSpec.Behavior.HOSTILE) {
            this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            switch (spec().effect()) {
                case "poison" -> living.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0), this);
                case "slow" -> living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1), this);
                case "blind" -> living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0), this);
                case "nausea" -> living.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0), this);
                case "wither" -> living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1), this);
                case "fire" -> living.igniteForSeconds(5.0F);
                default -> { }
            }
        }
        return hit;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && spec().explode()) {
            level().explode(this, getX(), getY(), getZ(), 1.0F, Level.ExplosionInteraction.NONE);
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !spec().boss();
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (bossEvent != null) {
            bossEvent.addPlayer(player);
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        if (bossEvent != null) {
            bossEvent.removePlayer(player);
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (bossEvent != null) {
            bossEvent.setProgress(getHealth() / getMaxHealth());
        }
    }
}
