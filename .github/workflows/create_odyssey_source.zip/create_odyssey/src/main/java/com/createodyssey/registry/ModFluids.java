package com.createodyssey.registry;

import com.createodyssey.Catalog;
import com.createodyssey.OdysseyMod;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Registers every fluid of the catalog: fluid type, source, flowing, liquid block and bucket. */
public final class ModFluids {
    public static final DeferredRegister<FluidType> FLUID_TYPES = DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES, OdysseyMod.MODID);
    public static final DeferredRegister<Fluid> FLUIDS = DeferredRegister.create(BuiltInRegistries.FLUID, OdysseyMod.MODID);
    public static final Map<String, Entry> BY_ID = new LinkedHashMap<>();

    public static final class Entry {
        public final String id;
        public final int color;
        public DeferredHolder<FluidType, FluidType> type;
        public DeferredHolder<Fluid, FlowingFluid> source;
        public DeferredHolder<Fluid, FlowingFluid> flowing;
        public DeferredBlock<LiquidBlock> block;
        public DeferredItem<BucketItem> bucket;

        Entry(String id, int color) {
            this.id = id;
            this.color = color;
        }

        BaseFlowingFluid.Properties props() {
            return new BaseFlowingFluid.Properties(type, source, flowing).bucket(bucket).block(block)
                    .slopeFindDistance(2).levelDecreasePerBlock(2).tickRate(8);
        }
    }

    static {
        for (Catalog.FluidSpec s : Catalog.FLUIDS) {
            Entry e = new Entry(s.id(), s.color());
            e.type = FLUID_TYPES.register(s.id(), () -> new FluidType(FluidType.Properties.create()
                    .descriptionId("fluid_type." + OdysseyMod.MODID + "." + s.id())
                    .density(s.density()).viscosity(s.viscosity()).temperature(s.temperature())
                    .canSwim(false).canDrown(false).canPushEntity(true)));
            e.source = FLUIDS.register(s.id(), () -> new BaseFlowingFluid.Source(e.props()));
            e.flowing = FLUIDS.register(s.id() + "_flowing", () -> new BaseFlowingFluid.Flowing(e.props()));
            e.block = ModBlocks.BLOCKS.register(s.id(), () -> new LiquidBlock((FlowingFluid) e.source.get(),
                    BlockBehaviour.Properties.of().mapColor(MapColor.WATER).replaceable().noCollission().strength(100.0F)
                            .pushReaction(PushReaction.DESTROY).noLootTable().liquid()));
            e.bucket = ModItems.ITEMS.register(s.id() + "_bucket", () -> new BucketItem(e.source.get(),
                    new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));
            BY_ID.put(s.id(), e);
        }
    }

    /** Fluid stack of one of our fluids, or vanilla water for the id "water". */
    public static FluidStack stack(String id, int amount) {
        if (id.equals("water")) {
            return new FluidStack(Fluids.WATER, amount);
        }
        return new FluidStack(BY_ID.get(id).source.get(), amount);
    }

    public static Fluid fluid(String id) {
        return id.equals("water") ? Fluids.WATER : BY_ID.get(id).source.get();
    }

    /** 0 = kerosene, 1 = hydrolox, 2 = methalox, -1 = not a rocket fuel. */
    public static int fuelGrade(Fluid f) {
        ResourceLocation k = BuiltInRegistries.FLUID.getKey(f);
        if (!OdysseyMod.MODID.equals(k.getNamespace())) {
            return -1;
        }
        return switch (k.getPath()) {
            case "kerosene" -> 0;
            case "hydrolox" -> 1;
            case "methalox" -> 2;
            default -> -1;
        };
    }

    public static int requiredGrade(int tier) {
        return tier <= 2 ? 0 : (tier <= 4 ? 1 : 2);
    }

    private ModFluids() {}
}
