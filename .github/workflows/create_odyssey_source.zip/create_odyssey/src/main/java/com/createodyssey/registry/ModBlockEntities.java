package com.createodyssey.registry;

import com.createodyssey.OdysseyMod;
import com.createodyssey.block.AlternatorBlockEntity;
import com.createodyssey.block.CableBlockEntity;
import com.createodyssey.block.FuelingPortBlockEntity;
import com.createodyssey.block.ProcessorBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, OdysseyMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AlternatorBlockEntity>> ALTERNATOR = TYPES.register("kinetic_alternator",
            () -> BlockEntityType.Builder.of(AlternatorBlockEntity::new, ModBlocks.ALTERNATOR.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ProcessorBlockEntity>> PROCESSOR = TYPES.register("processor",
            () -> BlockEntityType.Builder.of(ProcessorBlockEntity::new, ModBlocks.REFINERY.get(), ModBlocks.ELECTROLYZER.get(), ModBlocks.LIQUEFIER.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CableBlockEntity>> CABLE = TYPES.register("power_cable",
            () -> BlockEntityType.Builder.of(CableBlockEntity::new, ModBlocks.CABLE.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FuelingPortBlockEntity>> FUELING_PORT = TYPES.register("fueling_port",
            () -> BlockEntityType.Builder.of(FuelingPortBlockEntity::new, ModBlocks.FUELING_PORT.get()).build(null));

    private ModBlockEntities() {}
}
