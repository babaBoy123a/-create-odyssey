package com.createodyssey.block;

import com.createodyssey.rocket.RocketEntity;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/** Right-click: shows the status of the nearest rocket and starts the countdown when a pilot is aboard. */
public class LaunchConsoleBlock extends Block {
    public LaunchConsoleBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        List<RocketEntity> rockets = level.getEntitiesOfClass(RocketEntity.class, new AABB(pos).inflate(10.0D));
        RocketEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (RocketEntity r : rockets) {
            double d = r.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            if (d < bestD) {
                bestD = d;
                best = r;
            }
        }
        if (best == null) {
            player.displayClientMessage(Component.translatable("message.create_odyssey.no_rocket"), true);
            return InteractionResult.CONSUME;
        }
        player.displayClientMessage(best.statusComponent(), true);
        if (best.getState() == RocketEntity.IDLE) {
            best.tryLaunch(player instanceof ServerPlayer sp ? sp : null);
        }
        return InteractionResult.CONSUME;
    }
}
