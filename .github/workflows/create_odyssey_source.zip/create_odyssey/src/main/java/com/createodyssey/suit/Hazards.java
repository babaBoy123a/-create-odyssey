package com.createodyssey.suit;

import com.createodyssey.OdysseyConfig;
import com.createodyssey.OdysseyMod;
import com.createodyssey.Planet;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

/** Once-per-second planet hazards: gravity, oxygen and temperature. */
public final class Hazards {
    private static final ResourceKey<DamageType> SUFFOCATION = ResourceKey.create(Registries.DAMAGE_TYPE, OdysseyMod.rl("space_suffocation"));
    private static final ResourceKey<DamageType> HEAT = ResourceKey.create(Registries.DAMAGE_TYPE, OdysseyMod.rl("extreme_heat"));
    private static final ResourceKey<DamageType> COLD = ResourceKey.create(Registries.DAMAGE_TYPE, OdysseyMod.rl("extreme_cold"));
    private static final ResourceLocation GRAVITY_ID = OdysseyMod.rl("planet_gravity");
    private static final ResourceLocation JUMP_ID = OdysseyMod.rl("planet_jump");
    private static final ResourceLocation FALL_ID = OdysseyMod.rl("planet_fall");
    private static final ResourceLocation SAFE_ID = OdysseyMod.rl("planet_safe_fall");

    private Hazards() {}

    public static void tick(ServerPlayer p) {
        Planet planet = Planet.of(p.level());
        if (planet == null) {
            clearGravity(p);
            return;
        }
        applyGravity(p, planet.gravity());
        if (!OdysseyConfig.HAZARDS_ENABLED.get() || p.isCreative() || p.isSpectator()) {
            return;
        }
        float perLevel = OdysseyConfig.HAZARD_DAMAGE.get().floatValue();
        if (!breathe(p)) {
            p.hurt(source(p, SUFFOCATION), perLevel);
            p.displayClientMessage(Component.translatable("message.create_odyssey.suffocating"), true);
        }
        int coldDeficit = planet.coldLevel(p.level()) - suitLevel(p, true);
        if (coldDeficit > 0) {
            p.hurt(source(p, COLD), perLevel * coldDeficit);
            p.displayClientMessage(Component.translatable("message.create_odyssey.freezing"), true);
        }
        int heatDeficit = planet.heatLevel(p.level()) - suitLevel(p, false);
        if (heatDeficit > 0) {
            p.hurt(source(p, HEAT), perLevel * heatDeficit);
            p.displayClientMessage(Component.translatable("message.create_odyssey.burning"), true);
        }
    }

    private static DamageSource source(ServerPlayer p, ResourceKey<DamageType> key) {
        return new DamageSource(p.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(key));
    }

    /** Lowest resistance among the four suit pieces; 0 when any piece is missing. */
    public static int suitLevel(ServerPlayer p, boolean cold) {
        int min = Integer.MAX_VALUE;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!(p.getItemBySlot(slot).getItem() instanceof SuitArmorItem suit)) {
                return 0;
            }
            min = Math.min(min, cold ? suit.coldResist() : suit.heatResist());
        }
        return min;
    }

    /** Drains oxygen from the chestplate tank; true when the player can breathe this second. */
    public static boolean breathe(ServerPlayer p) {
        ItemStack head = p.getItemBySlot(EquipmentSlot.HEAD);
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        if (!(head.getItem() instanceof SuitArmorItem) || !(chest.getItem() instanceof SuitArmorItem)) {
            return false;
        }
        IFluidHandlerItem tank = chest.getCapability(Capabilities.FluidHandler.ITEM);
        if (tank == null) {
            return false;
        }
        int need = OdysseyConfig.OXYGEN_MB_PER_SECOND.get() * (p.isSprinting() ? 2 : 1);
        if (need <= 0) {
            return true;
        }
        FluidStack drained = tank.drain(need, IFluidHandler.FluidAction.EXECUTE);
        return drained.getAmount() >= need;
    }

    private static void setModifier(ServerPlayer p, Holder<Attribute> attribute, ResourceLocation id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) {
            return;
        }
        AttributeModifier current = inst.getModifier(id);
        if (current == null || Math.abs(current.amount() - amount) > 1.0E-6D) {
            inst.removeModifier(id);
            inst.addTransientModifier(new AttributeModifier(id, amount, op));
        }
    }

    private static void applyGravity(ServerPlayer p, double g) {
        setModifier(p, Attributes.GRAVITY, GRAVITY_ID, g - 1.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        setModifier(p, Attributes.JUMP_STRENGTH, JUMP_ID, Math.sqrt(Math.min(2.5D * g, 1.0D)) - 1.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        setModifier(p, Attributes.FALL_DAMAGE_MULTIPLIER, FALL_ID, Math.min(g, 1.0D) - 1.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        setModifier(p, Attributes.SAFE_FALL_DISTANCE, SAFE_ID, 3.0D / g - 3.0D, AttributeModifier.Operation.ADD_VALUE);
    }

    private static void clearGravity(ServerPlayer p) {
        remove(p, Attributes.GRAVITY, GRAVITY_ID);
        remove(p, Attributes.JUMP_STRENGTH, JUMP_ID);
        remove(p, Attributes.FALL_DAMAGE_MULTIPLIER, FALL_ID);
        remove(p, Attributes.SAFE_FALL_DISTANCE, SAFE_ID);
    }

    private static void remove(ServerPlayer p, Holder<Attribute> attribute, ResourceLocation id) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst != null && inst.getModifier(id) != null) {
            inst.removeModifier(id);
        }
    }
}
