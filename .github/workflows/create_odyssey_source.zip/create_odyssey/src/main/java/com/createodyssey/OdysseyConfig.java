package com.createodyssey;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class OdysseyConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue HAZARDS_ENABLED;
    public static final ModConfigSpec.IntValue OXYGEN_MB_PER_SECOND;
    public static final ModConfigSpec.DoubleValue HAZARD_DAMAGE;
    public static final ModConfigSpec.IntValue ASCENT_HEIGHT;
    public static final ModConfigSpec.IntValue COUNTDOWN_TICKS;
    public static final ModConfigSpec.DoubleValue FUEL_COST_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue FE_PER_RPM;
    public static final ModConfigSpec.DoubleValue ALTERNATOR_IMPACT;
    public static final ModConfigSpec.DoubleValue MACHINE_ENERGY_MULTIPLIER;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.push("hazards");
        HAZARDS_ENABLED = b.comment("Enable oxygen / temperature hazards on planets").define("enabled", true);
        OXYGEN_MB_PER_SECOND = b.comment("Oxygen drained from the suit tank each second (doubled while sprinting)").defineInRange("oxygenMbPerSecond", 6, 0, 1000);
        HAZARD_DAMAGE = b.comment("Damage per second per missing resistance level").defineInRange("damagePerLevel", 2.0, 0.0, 100.0);
        b.pop();
        b.push("rockets");
        ASCENT_HEIGHT = b.comment("Blocks climbed before the star map opens").defineInRange("ascentHeight", 120, 20, 400);
        COUNTDOWN_TICKS = b.comment("Countdown length in ticks").defineInRange("countdownTicks", 200, 20, 1200);
        FUEL_COST_MULTIPLIER = b.comment("Multiplier applied to every trip fuel cost").defineInRange("fuelCostMultiplier", 1.0, 0.0, 100.0);
        b.pop();
        b.push("machines");
        FE_PER_RPM = b.comment("FE produced per tick per RPM by the kinetic alternator").defineInRange("fePerRpm", 1.0, 0.0, 1000.0);
        ALTERNATOR_IMPACT = b.comment("Stress impact (SU per RPM) of the kinetic alternator").defineInRange("alternatorImpact", 8.0, 0.0, 1024.0);
        MACHINE_ENERGY_MULTIPLIER = b.comment("Multiplier on the energy use of refinery / electrolyzer / liquefier").defineInRange("energyMultiplier", 1.0, 0.0, 100.0);
        b.pop();
        SPEC = b.build();
    }

    private OdysseyConfig() {}
}
