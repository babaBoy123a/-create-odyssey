package com.createodyssey.client;

import com.createodyssey.OdysseyMod;
import com.createodyssey.Planet;
import com.createodyssey.suit.SuitArmorItem;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

/** Oxygen gauge + temperature warnings, only drawn on a planet. */
public final class SuitHud {
    private static final ResourceLocation O2 = OdysseyMod.rl("textures/gui/o2.png");
    private static final ResourceLocation COLD = OdysseyMod.rl("textures/gui/cold.png");
    private static final ResourceLocation HEAT = OdysseyMod.rl("textures/gui/heat.png");

    private SuitHud() {}

    private static int suitLevel(LocalPlayer p, boolean cold) {
        int min = Integer.MAX_VALUE;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!(p.getItemBySlot(slot).getItem() instanceof SuitArmorItem suit)) {
                return 0;
            }
            min = Math.min(min, cold ? suit.coldResist() : suit.heatResist());
        }
        return min;
    }

    public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.options.hideGui) {
            return;
        }
        Planet planet = Planet.of(mc.level);
        if (planet == null) {
            return;
        }
        int x = 10;
        int y = mc.getWindow().getGuiScaledHeight() - 58;
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        int amount = 0;
        int cap = 1;
        if (chest.getItem() instanceof SuitArmorItem) {
            IFluidHandlerItem tank = chest.getCapability(Capabilities.FluidHandler.ITEM);
            if (tank != null) {
                amount = tank.getFluidInTank(0).getAmount();
                cap = Math.max(1, tank.getTankCapacity(0));
            }
        }
        g.blit(O2, x, y, 16, 16, 0.0F, 0.0F, 16, 16, 16, 16);
        g.fill(x + 20, y + 4, x + 102, y + 12, 0xAA000000);
        int w = (int) (80.0F * amount / cap);
        g.fill(x + 21, y + 5, x + 21 + w, y + 11, amount * 4 < cap ? 0xFFE04040 : 0xFF4AA0F0);
        g.drawString(mc.font, amount + " mB", x + 106, y + 4, 0xFFFFFF);
        int row = 20;
        int needCold = planet.coldLevel(mc.level);
        if (needCold > 0) {
            int have = suitLevel(p, true);
            g.blit(COLD, x, y + row, 16, 16, 0.0F, 0.0F, 16, 16, 16, 16);
            g.drawString(mc.font, have + " / " + needCold, x + 20, y + row + 4, have >= needCold ? 0x7FFFD4 : 0xFF5555);
            row += 18;
        }
        int needHeat = planet.heatLevel(mc.level);
        if (needHeat > 0) {
            int have = suitLevel(p, false);
            g.blit(HEAT, x, y + row, 16, 16, 0.0F, 0.0F, 16, 16, 16, 16);
            g.drawString(mc.font, have + " / " + needHeat, x + 20, y + row + 4, have >= needHeat ? 0xFFD27F : 0xFF5555);
        }
    }
}
