package com.createodyssey.client;

import com.createodyssey.OdysseyMod;
import com.createodyssey.entity.MobSpec;
import com.createodyssey.entity.MobSpecs;
import com.createodyssey.net.OdysseyNetwork;
import com.createodyssey.registry.ModEntities;
import com.createodyssey.registry.ModFluids;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

@EventBusSubscriber(modid = OdysseyMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    public static final KeyMapping LAUNCH_KEY = new KeyMapping("key.create_odyssey.launch", InputConstants.KEY_G, "key.categories.create_odyssey");

    private ClientSetup() {}

    public static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(OdysseyMod.rl(name), "main");
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        OdysseyNetwork.clientOpenStarMap = StarMapScreen::open;
    }

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent event) {
        event.register(LAUNCH_KEY);
    }

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (MobSpec s : MobSpecs.BY_ID.values()) {
            final String id = s.id();
            event.registerLayerDefinition(layer(id), () -> GeneratedModels.mob(id));
        }
        for (int t = 1; t <= 5; t++) {
            final int tier = t;
            event.registerLayerDefinition(layer("rocket_t" + t), () -> GeneratedModels.rocket(tier));
        }
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ROCKET.get(), RocketRenderer::new);
        for (MobSpec s : MobSpecs.BY_ID.values()) {
            registerMob(event, ModEntities.MOBS.get(s.id()).get(), s);
        }
    }

    private static <T extends Mob> void registerMob(EntityRenderersEvent.RegisterRenderers event, EntityType<T> type, MobSpec spec) {
        event.registerEntityRenderer(type, ctx -> new OdysseyMobRenderer<T>(ctx, spec));
    }

    @SubscribeEvent
    public static void onGui(RegisterGuiLayersEvent event) {
        event.registerAboveAll(OdysseyMod.rl("suit_hud"), SuitHud::render);
    }

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public static void onClientExtensions(RegisterClientExtensionsEvent event) {
        for (ModFluids.Entry entry : ModFluids.BY_ID.values()) {
            final ResourceLocation still = OdysseyMod.rl("block/" + entry.id + "_still");
            final int color = entry.color;
            event.registerFluidType(new IClientFluidTypeExtensions() {
                @Override
                public ResourceLocation getStillTexture() {
                    return still;
                }

                @Override
                public ResourceLocation getFlowingTexture() {
                    return still;
                }

                @Override
                public int getTintColor() {
                    return color;
                }
            }, entry.type);
        }
    }
}
