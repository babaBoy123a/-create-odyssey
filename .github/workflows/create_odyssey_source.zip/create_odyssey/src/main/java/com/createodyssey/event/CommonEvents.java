package com.createodyssey.event;

import com.createodyssey.OdysseyConfig;
import com.createodyssey.OdysseyMod;
import com.createodyssey.entity.MobSpec;
import com.createodyssey.entity.MobSpecs;
import com.createodyssey.entity.OdysseyCritter;
import com.createodyssey.entity.OdysseyMob;
import com.createodyssey.net.OdysseyNetwork;
import com.createodyssey.registry.ModBlockEntities;
import com.createodyssey.registry.ModBlocks;
import com.createodyssey.registry.ModEntities;
import com.createodyssey.registry.ModItems;
import com.createodyssey.suit.OxygenTank;
import com.createodyssey.suit.SuitArmorItem;
import com.simibubi.create.api.stress.BlockStressValues;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/** Mod-bus events shared by client and server. */
@EventBusSubscriber(modid = OdysseyMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class CommonEvents {
    private CommonEvents() {}

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> BlockStressValues.IMPACTS.register(ModBlocks.ALTERNATOR.get(), () -> OdysseyConfig.ALTERNATOR_IMPACT.get()));
    }

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        for (MobSpec s : MobSpecs.BY_ID.values()) {
            AttributeSupplier attrs = (s.behavior() == MobSpec.Behavior.PASSIVE ? OdysseyCritter.createAttributes(s) : OdysseyMob.createAttributes(s)).build();
            event.put(ModEntities.MOBS.get(s.id()).get(), attrs);
        }
    }

    @SubscribeEvent
    public static void onSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        for (MobSpec s : MobSpecs.BY_ID.values()) {
            registerPlacement(event, ModEntities.MOBS.get(s.id()).get(), s.flying());
        }
    }

    private static <T extends Mob> void registerPlacement(RegisterSpawnPlacementsEvent event, EntityType<T> type, boolean flying) {
        event.register(type,
                flying ? SpawnPlacementTypes.NO_RESTRICTIONS : SpawnPlacementTypes.ON_GROUND,
                flying ? Heightmap.Types.MOTION_BLOCKING : Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, level, reason, pos, random) -> true,
                RegisterSpawnPlacementsEvent.Operation.OR);
    }

    @SubscribeEvent
    public static void onCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.PROCESSOR.get(), (be, side) -> be.energy());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.PROCESSOR.get(), (be, side) -> be.fluids());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.CABLE.get(), (be, side) -> be.energy());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ALTERNATOR.get(), (be, side) -> be.energy());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.FUELING_PORT.get(), (be, side) -> be.fluids());
        event.registerItem(Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new OxygenTank(stack, SuitArmorItem.oxygenCapacity(((SuitArmorItem) stack.getItem()).tier())),
                ModItems.suitChestplates());
    }

    @SubscribeEvent
    public static void onPayloads(RegisterPayloadHandlersEvent event) {
        OdysseyNetwork.register(event);
    }
}
