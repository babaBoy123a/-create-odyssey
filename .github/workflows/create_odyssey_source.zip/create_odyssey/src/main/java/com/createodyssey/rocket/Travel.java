package com.createodyssey.rocket;

import com.createodyssey.Catalog;
import com.createodyssey.Planet;
import com.createodyssey.registry.ModBlocks;
import com.createodyssey.registry.ModEntities;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.fluids.FluidStack;

/** Server-side interplanetary travel: validation, fuel, landing pad generation, teleportation. */
public final class Travel {
    private static final String HOME_KEY = "create_odyssey_home";

    private Travel() {}

    private static void fail(ServerPlayer p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.create_odyssey." + key, args), true);
    }

    /** dest: -1 = back to the pad, 0..n-1 = planet index, n = Earth. */
    public static void go(ServerPlayer pilot, RocketEntity rocket, int dest) {
        if (rocket.level().isClientSide || rocket.getState() != RocketEntity.AWAIT) {
            return;
        }
        if (dest < 0) {
            rocket.returnToPad();
            return;
        }
        MinecraftServer server = pilot.server;
        Planet current = Planet.of(rocket.level());
        ServerLevel target;
        int cost;
        Planet planet = null;
        if (dest >= Planet.all().size()) {
            if (current == null) {
                rocket.returnToPad();
                return;
            }
            target = server.overworld();
            cost = rocket.fuelCost(current);
        } else {
            planet = Planet.all().get(dest);
            if (rocket.getTier() < planet.tier()) {
                fail(pilot, "tier_too_low");
                return;
            }
            if (planet == current) {
                rocket.returnToPad();
                return;
            }
            target = server.getLevel(planet.dimension);
            if (target == null) {
                return;
            }
            cost = rocket.fuelCost(planet);
        }
        if (rocket.getTank().getFluidAmount() < cost) {
            fail(pilot, "no_fuel", cost);
            return;
        }
        if (current == null && rocket.homePos() != null) {
            saveHome(pilot, rocket);
        }
        BlockPos ground = planet != null ? ensurePad(target) : homeGround(pilot, target);
        target.getChunk(ground.getX() >> 4, ground.getZ() >> 4);

        RocketEntity nr = ModEntities.ROCKET.get().create(target);
        if (nr == null) {
            return;
        }
        nr.setTier(rocket.getTier());
        FluidStack left = rocket.getTank().getFluid().copy();
        left.shrink(cost);
        nr.getTank().setFluid(left);
        nr.moveTo(ground.getX() + 0.5D, ground.getY() + 1.0D, ground.getZ() + 0.5D, 0.0F, 0.0F);
        nr.rememberHome();
        target.addFreshEntity(nr);

        List<ServerPlayer> riders = new ArrayList<>();
        for (Entity e : rocket.getPassengers()) {
            if (e instanceof ServerPlayer sp) {
                riders.add(sp);
            }
        }
        rocket.ejectPassengers();
        for (ServerPlayer sp : riders) {
            sp.teleportTo(target, ground.getX() + 0.5D, ground.getY() + 1.0D, ground.getZ() + 3.5D, sp.getYRot(), 0.0F);
            sp.displayClientMessage(Component.translatable("message.create_odyssey.arrived"), true);
        }
        rocket.discard();
    }

    private static void saveHome(ServerPlayer pilot, RocketEntity rocket) {
        Vec3 h = rocket.homePos();
        BlockPos plate = BlockPos.containing(h.x, h.y - 0.5D, h.z);
        CompoundTag t = new CompoundTag();
        t.putInt("x", plate.getX());
        t.putInt("y", plate.getY());
        t.putInt("z", plate.getZ());
        t.putString("dim", rocket.level().dimension().location().toString());
        pilot.getPersistentData().put(HOME_KEY, t);
    }

    private static BlockPos homeGround(ServerPlayer pilot, ServerLevel overworld) {
        CompoundTag t = pilot.getPersistentData().getCompound(HOME_KEY);
        if (t.contains("x") && overworld.dimension().location().toString().equals(t.getString("dim"))) {
            BlockPos p = new BlockPos(t.getInt("x"), t.getInt("y"), t.getInt("z"));
            overworld.getChunk(p.getX() >> 4, p.getZ() >> 4);
            return p;
        }
        BlockPos spawn = overworld.getSharedSpawnPos();
        overworld.getChunk(spawn.getX() >> 4, spawn.getZ() >> 4);
        int y = overworld.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX(), spawn.getZ());
        return new BlockPos(spawn.getX(), y - 1, spawn.getZ());
    }

    /** Builds (once) a 7x7 landing pad with a console and a fueling port at the fixed landing spot of the planet. */
    private static BlockPos ensurePad(ServerLevel level) {
        int x = Planet.PAD_X;
        int z = Planet.PAD_Z;
        level.getChunk(x >> 4, z >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos center = new BlockPos(x, y - 1, z);
        if (PadUtil.isPlate(level, center)) {
            return center;
        }
        int r = Catalog.PAD_SIZE[4] / 2;
        for (int dx = -r - 2; dx <= r + 2; dx++) {
            for (int dz = -r - 2; dz <= r + 2; dz++) {
                for (int dy = 1; dy <= 14; dy++) {
                    level.setBlock(center.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 2);
                }
            }
        }
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                level.setBlock(center.offset(dx, 0, dz), ModBlocks.PAD_PLATE.get().defaultBlockState(), 3);
            }
        }
        level.setBlock(center.offset(r + 1, 0, 0), ModBlocks.CONSOLE.get().defaultBlockState(), 3);
        level.setBlock(center.offset(-r - 1, 0, 0), ModBlocks.FUELING_PORT.get().defaultBlockState(), 3);
        return center;
    }
}
