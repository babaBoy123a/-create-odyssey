package com.createodyssey.event;

import com.createodyssey.OdysseyMod;
import com.createodyssey.suit.Hazards;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Game-bus events (server logic). */
@EventBusSubscriber(modid = OdysseyMod.MODID)
public final class GameEvents {
    private GameEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer sp && sp.tickCount % 20 == 0) {
            Hazards.tick(sp);
        }
    }
}
