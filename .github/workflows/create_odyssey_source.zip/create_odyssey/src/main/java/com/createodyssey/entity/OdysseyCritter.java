package com.createodyssey.entity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Peaceful planet creature (selene hopper, ice manta). */
public class OdysseyCritter extends PathfinderMob {
    private MobSpec cached;

    public OdysseyCritter(EntityType<? extends OdysseyCritter> type, Level level) {
        super(type, level);
        if (spec().flying()) {
            this.moveControl = new FlyingMoveControl(this, 20, true);
            this.setNoGravity(true);
        }
    }

    public MobSpec spec() {
        if (cached == null) {
            cached = MobSpecs.BY_ID.get(BuiltInRegistries.ENTITY_TYPE.getKey(getType()).getPath());
        }
        return cached;
    }

    public static AttributeSupplier.Builder createAttributes(MobSpec s) {
        AttributeSupplier.Builder b = Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, s.health())
                .add(Attributes.MOVEMENT_SPEED, s.speed());
        if (s.flying()) {
            b.add(Attributes.FLYING_SPEED, s.speed());
        }
        if (s.id().equals("selene_hopper")) {
            b.add(Attributes.JUMP_STRENGTH, 0.9D);
        }
        return b;
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        if (spec().flying()) {
            FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
            nav.setCanOpenDoors(false);
            nav.setCanFloat(true);
            nav.setCanPassDoors(true);
            return nav;
        }
        return super.createNavigation(level);
    }

    @Override
    protected void registerGoals() {
        MobSpec s = spec();
        if (!s.flying()) {
            this.goalSelector.addGoal(0, new FloatGoal(this));
        }
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        if (s.flying()) {
            this.goalSelector.addGoal(4, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        } else {
            this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        }
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }
}
