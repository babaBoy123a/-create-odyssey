package com.createodyssey.rocket;

import com.createodyssey.Catalog;
import com.createodyssey.OdysseyConfig;
import com.createodyssey.Planet;
import com.createodyssey.net.OdysseyNetwork;
import com.createodyssey.registry.ModComponents;
import com.createodyssey.registry.ModFluids;
import com.createodyssey.registry.ModItems;
import org.jetbrains.annotations.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.SimpleFluidContent;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.network.PacketDistributor;

/** A rocket of tier 1..5 standing on a launch pad: fuel tank, passengers, countdown, ascent. */
public class RocketEntity extends Entity {
    public static final int IDLE = 0;
    public static final int COUNTDOWN = 1;
    public static final int ASCEND = 2;
    public static final int AWAIT = 3;

    private static final EntityDataAccessor<Integer> DATA_TIER = SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_COUNTDOWN = SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FUEL = SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.INT);

    private boolean fuelDirty = true;
    private final FluidTank tank = new FluidTank(Catalog.ROCKET_CAPACITY[4], this::acceptsFuel) {
        @Override
        protected void onContentsChanged() {
            fuelDirty = true;
        }
    };
    private double launchY;
    private int ascendTicks;
    private int awaitTicks;
    @Nullable
    private Vec3 homePos;

    public RocketEntity(EntityType<? extends RocketEntity> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
        this.noCulling = true;
        this.setNoGravity(true);
    }

    // ------------------------------------------------------------------ data
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_TIER, 1);
        builder.define(DATA_STATE, IDLE);
        builder.define(DATA_COUNTDOWN, 0);
        builder.define(DATA_FUEL, 0);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_TIER.equals(key)) {
            refreshDimensions();
        }
    }

    public int getTier() {
        return Mth.clamp(entityData.get(DATA_TIER), 1, 5);
    }

    public void setTier(int tier) {
        int t = Mth.clamp(tier, 1, 5);
        entityData.set(DATA_TIER, t);
        tank.setCapacity(Catalog.ROCKET_CAPACITY[t - 1]);
        refreshDimensions();
    }

    public int getState() {
        return entityData.get(DATA_STATE);
    }

    public int getCountdown() {
        return entityData.get(DATA_COUNTDOWN);
    }

    public int getFuelAmount() {
        return level().isClientSide ? entityData.get(DATA_FUEL) : tank.getFluidAmount();
    }

    public FluidTank getTank() {
        return tank;
    }

    public int fillFuel(FluidStack stack, IFluidHandler.FluidAction action) {
        return tank.fill(stack, action);
    }

    private boolean acceptsFuel(FluidStack stack) {
        return ModFluids.fuelGrade(stack.getFluid()) >= ModFluids.requiredGrade(getTier());
    }

    public void rememberHome() {
        this.homePos = position();
    }

    public int fuelCost(Planet destination) {
        double mult = OdysseyConfig.FUEL_COST_MULTIPLIER.get();
        if (!tank.isEmpty() && ModFluids.fuelGrade(tank.getFluid().getFluid()) > ModFluids.requiredGrade(getTier())) {
            mult *= 0.75D;
        }
        return (int) Math.ceil(destination.cost() * mult);
    }

    private int minimumFuel() {
        return (int) Math.ceil(Planet.all().get(0).cost() * OdysseyConfig.FUEL_COST_MULTIPLIER.get());
    }

    // ------------------------------------------------------------------ shape / riding
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return dims();
    }

    @Override
    protected EntityDimensions getDefaultDimensions(Pose pose) {
        return dims();
    }

    private EntityDimensions dims() {
        int t = entityData == null ? 1 : getTier();
        return EntityDimensions.scalable(Catalog.ROCKET_WIDTH[t - 1], Catalog.ROCKET_HEIGHT[t - 1]);
    }

    @Override
    protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float partialTick) {
        int n = new int[]{2, 3, 3, 4, 5}[getTier() - 1];
        double y = (8 + 24 * n) / 16.0D + 0.2D;
        int idx = Math.max(0, getPassengers().indexOf(passenger));
        double ox = idx == 0 ? 0.0D : (idx % 2 == 1 ? 0.45D : -0.45D);
        double oz = idx >= 2 ? 0.45D : 0.0D;
        return new Vec3(ox, y, oz);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().size() < Catalog.ROCKET_SEATS[getTier() - 1] && getState() == IDLE;
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ interaction
    public Component statusComponent() {
        String fuel = tank.isEmpty() ? "-" : tank.getFluid().getHoverName().getString();
        return Component.translatable("message.create_odyssey.rocket_status", getTier(), tank.getFluidAmount(), tank.getCapacity(), fuel);
    }

    private static void msg(@Nullable Player p, String key, Object... args) {
        if (p != null) {
            p.displayClientMessage(Component.translatable("message.create_odyssey." + key, args), true);
        }
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player.isSecondaryUseActive()) {
            player.displayClientMessage(statusComponent(), true);
            return InteractionResult.CONSUME;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty() && held.getCapability(Capabilities.FluidHandler.ITEM) != null) {
            if (!FluidUtil.interactWithFluidHandler(player, hand, tank)) {
                msg(player, "fuel_wrong");
            }
            return InteractionResult.CONSUME;
        }
        if (getState() == IDLE && getPassengers().size() < Catalog.ROCKET_SEATS[getTier() - 1]) {
            player.startRiding(this);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && !isRemoved() && getState() == IDLE && source.getEntity() instanceof Player p && !getPassengers().contains(p)) {
            dropAsItem();
            discard();
            return true;
        }
        return false;
    }

    private void dropAsItem() {
        ItemStack stack = new ItemStack(ModItems.ROCKETS.get(getTier() - 1).get());
        if (!tank.isEmpty()) {
            stack.set(ModComponents.FLUID_CONTENT.get(), SimpleFluidContent.copyOf(tank.getFluid()));
        }
        spawnAtLocation(stack);
    }

    // ------------------------------------------------------------------ launch
    public void tryLaunch(@Nullable ServerPlayer by) {
        if (level().isClientSide) {
            return;
        }
        if (getState() == AWAIT) {
            sendStarMap();
            return;
        }
        if (getState() != IDLE) {
            return;
        }
        BlockPos plate = BlockPos.containing(getX(), getY() - 0.5D, getZ());
        int size = Catalog.PAD_SIZE[getTier() - 1];
        int have = PadUtil.plateCount(level(), plate, size);
        if (have < size * size) {
            msg(by, "pad_missing", have, size * size);
            return;
        }
        String err = PadUtil.clearanceError(level(), plate, getTier());
        if (err != null) {
            msg(by, err);
            return;
        }
        int min = minimumFuel();
        if (tank.getFluidAmount() < min) {
            msg(by, "no_fuel", min);
            return;
        }
        if (getPassengers().isEmpty()) {
            msg(by, "need_pilot");
            return;
        }
        homePos = position();
        entityData.set(DATA_COUNTDOWN, OdysseyConfig.COUNTDOWN_TICKS.get());
        entityData.set(DATA_STATE, COUNTDOWN);
        msg(by, "launch_ok");
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        switch (getState()) {
            case COUNTDOWN -> tickCountdown();
            case ASCEND -> tickAscend();
            case AWAIT -> tickAwait();
            default -> { }
        }
        if (fuelDirty || entityData.get(DATA_FUEL) != tank.getFluidAmount()) {
            entityData.set(DATA_FUEL, tank.getFluidAmount());
            fuelDirty = false;
        }
    }

    private void tickCountdown() {
        ServerLevel sl = (ServerLevel) level();
        int c = entityData.get(DATA_COUNTDOWN) - 1;
        entityData.set(DATA_COUNTDOWN, c);
        if (c > 0 && c % 20 == 0) {
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LEVER_CLICK, SoundSource.NEUTRAL, 1.5F, 0.6F + (c / 20) * 0.03F);
            sendCountdownMessage(c / 20);
        }
        if (c < 100) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY(), getZ(), 6, 0.9D, 0.1D, 0.9D, 0.02D);
        }
        if (c <= 0) {
            entityData.set(DATA_STATE, ASCEND);
            launchY = getY();
            ascendTicks = 0;
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.NEUTRAL, 4.0F, 0.5F);
        }
    }

    private void sendCountdownMessage(int seconds) {
        for (Entity e : getPassengers()) {
            if (e instanceof Player p) {
                p.displayClientMessage(Component.translatable("message.create_odyssey.countdown", seconds), true);
            }
        }
    }

    private void tickAscend() {
        ServerLevel sl = (ServerLevel) level();
        ascendTicks++;
        double vy = Math.min(1.5D, 0.04D + ascendTicks * 0.03D);
        setDeltaMovement(0.0D, vy, 0.0D);
        move(MoverType.SELF, getDeltaMovement());
        sl.sendParticles(ParticleTypes.FLAME, getX(), getY() - 0.2D, getZ(), 8, 0.35D, 0.1D, 0.35D, 0.06D);
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() - 0.4D, getZ(), 4, 0.4D, 0.1D, 0.4D, 0.02D);
        if (ascendTicks % 10 == 0) {
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.NEUTRAL, 2.0F, 0.5F);
        }
        if (getY() - launchY >= OdysseyConfig.ASCENT_HEIGHT.get() || (verticalCollision && ascendTicks > 10) || ascendTicks > 400) {
            setDeltaMovement(Vec3.ZERO);
            entityData.set(DATA_STATE, AWAIT);
            awaitTicks = 0;
            sendStarMap();
        }
    }

    private void tickAwait() {
        awaitTicks++;
        setDeltaMovement(Vec3.ZERO);
        if (getPassengers().isEmpty() && awaitTicks > 60) {
            returnToPad();
        }
    }

    private void sendStarMap() {
        Entity pilot = getFirstPassenger();
        if (pilot instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayer(sp, new OdysseyNetwork.OpenStarMapPayload(getId(), getTier(), tank.getFluidAmount(), Planet.indexOf(Planet.of(level()))));
        }
    }

    /** Goes back to the pad it took off from and becomes idle again. */
    public void returnToPad() {
        if (homePos != null) {
            setPos(homePos.x, homePos.y, homePos.z);
        }
        setDeltaMovement(Vec3.ZERO);
        entityData.set(DATA_STATE, IDLE);
        awaitTicks = 0;
    }

    @Nullable
    public Vec3 homePos() {
        return homePos;
    }

    // ------------------------------------------------------------------ save
    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Tier", getTier());
        tag.put("Tank", tank.writeToNBT(registryAccess(), new CompoundTag()));
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setTier(Math.max(1, tag.getInt("Tier")));
        tank.readFromNBT(registryAccess(), tag.getCompound("Tank"));
        fuelDirty = true;
    }
}
