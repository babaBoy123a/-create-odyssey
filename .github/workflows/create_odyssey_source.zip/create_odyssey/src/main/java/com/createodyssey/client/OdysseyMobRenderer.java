package com.createodyssey.client;

import com.createodyssey.OdysseyMod;
import com.createodyssey.entity.MobSpec;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class OdysseyMobRenderer<T extends Mob> extends MobRenderer<T, CubeMobModel<T>> {
    private final ResourceLocation texture;

    public OdysseyMobRenderer(EntityRendererProvider.Context context, MobSpec spec) {
        super(context, new CubeMobModel<T>(context.bakeLayer(ClientSetup.layer(spec.id())), spec), Math.max(0.2F, spec.width() * 0.5F));
        this.texture = OdysseyMod.rl("textures/entity/" + spec.id() + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
}
