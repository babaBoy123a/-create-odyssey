package com.createodyssey.entity;

/** Static description of one planet creature (generated list in MobSpecs). */
public record MobSpec(String id, String planet, Behavior behavior, boolean flying, double health, double damage, double speed,
                      float width, float height, String effect, boolean leap, boolean explode, boolean boss,
                      double armor, double kbResistance, int eggPrimary, int eggSecondary) {
    public enum Behavior { HOSTILE, NEUTRAL, PASSIVE }
}
