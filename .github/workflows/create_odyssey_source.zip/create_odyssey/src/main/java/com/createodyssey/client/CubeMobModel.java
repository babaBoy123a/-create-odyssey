package com.createodyssey.client;

import com.createodyssey.entity.MobSpec;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/** Generic animated model: parts are animated from their name (head, legN, armN, wingN, spinN, tentN, segN, tailN). */
public class CubeMobModel<T extends Mob> extends EntityModel<T> {
    private final ModelPart root;
    private final Map<String, ModelPart> parts = new LinkedHashMap<>();
    private final boolean flying;

    public CubeMobModel(ModelPart root, MobSpec spec) {
        this.root = root;
        this.flying = spec.flying();
        for (String name : GeneratedModels.parts(spec.id())) {
            parts.put(name, root.getChild(name));
        }
    }

    private static int index(String name) {
        int i = name.length();
        while (i > 0 && Character.isDigit(name.charAt(i - 1))) {
            i--;
        }
        return i == name.length() ? 0 : Integer.parseInt(name.substring(i));
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        for (Map.Entry<String, ModelPart> e : parts.entrySet()) {
            String n = e.getKey();
            ModelPart p = e.getValue();
            int i = index(n);
            if (n.equals("head")) {
                p.yRot = netHeadYaw * Mth.DEG_TO_RAD;
                p.xRot = headPitch * Mth.DEG_TO_RAD;
            } else if (n.startsWith("leg") || n.startsWith("arm")) {
                float phase = (i % 2 == 0) ? 0.0F : (float) Math.PI;
                p.xRot = Mth.cos(limbSwing * 0.6662F + phase) * 1.2F * limbSwingAmount;
            } else if (n.startsWith("wing")) {
                float side = (i % 2 == 0) ? 1.0F : -1.0F;
                p.zRot = side * Mth.sin(age * 0.6F) * 0.7F;
            } else if (n.startsWith("spin")) {
                p.yRot = age * (0.15F + 0.07F * i);
            } else if (n.startsWith("tent")) {
                p.xRot = Mth.sin(age * 0.1F + i) * 0.2F;
                p.zRot = Mth.cos(age * 0.1F + i) * 0.2F;
            } else if (n.startsWith("seg")) {
                p.yRot = Mth.sin(age * 0.2F + i) * 0.25F;
            } else if (n.startsWith("tail")) {
                p.yRot = Mth.sin(age * 0.15F) * 0.2F;
            }
        }
        if (flying) {
            root.y = Mth.sin(age * 0.1F) * 1.2F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
