package com.createodyssey.block;

import net.minecraft.world.level.block.Block;

/** Plate of a launch pad. A pad is a full square of these (3x3, 5x5 or 7x7 depending on the rocket tier). */
public class LaunchPadPlateBlock extends Block {
    public LaunchPadPlateBlock(Properties properties) {
        super(properties);
    }
}
