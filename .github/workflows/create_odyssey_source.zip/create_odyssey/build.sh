#!/usr/bin/env sh
# Builds the mod. Needs: JDK 21 and internet access (Gradle downloads NeoForge, Minecraft and Create on first run).
set -e
cd "$(dirname "$0")"
python3 tools/gen_all.py 2>/dev/null || echo "(python3 not found: using the pre-generated resources)"
./gradlew build
echo
echo "Done. Your mod: $(ls build/libs/create_odyssey-*.jar | grep -v sources | head -1)"
echo "Drop it in the mods folder of a NeoForge 1.21.1 instance that has Create 6.0.10+."
