# Guide de progression — Create: Odyssey

Tout se fabrique avec les machines de Create. Les noms entre parenthèses sont les identifiants (`/give @s create_odyssey:...`).

## 0. Les bases (Overworld)

1. **Acier** (`steel_ingot`) : bassin chauffé (Blaze Burner) + mixeur : 2 lingots de fer + 1 charbon → 2 lingots d'acier. La presse mécanique en fait des **plaques** (`steel_sheet`).
2. **Pétrole brut** (`crude_oil`) : sources rares sous terre (profondeur −20 à 50) à pomper avec des tuyaux Create ou un seau, ou **schiste bitumineux** (`oil_shale`) : mixeur chauffé, 2 schistes + 250 mB d'eau → 250 mB de pétrole + bitume.
3. **Électricité** : l'**alternateur cinétique** transforme la rotation Create en FE (1 FE/tick par RPM, 8 SU par RPM). Reliez-le aux machines avec des **câbles électriques** ou posez-le contre elles.
4. **Raffinerie électrique** (40 FE/t) : 1000 mB de pétrole → 600 mB de **kérosène** + 100 mB de **résine isolante**. Clic droit = état de la machine ; les tuyaux Create se branchent sur toutes les faces.
5. **Électrolyseur** (60 FE/t) : 500 mB d'eau → 1000 mB d'hydrogène + 500 mB d'**oxygène**.
6. **Polymère** : remplissage (bec verseur) d'un papier avec 100 mB de résine → plaque de polymère. **Céramique** : 2 argiles + sable au mixeur, puis fourneau → tuile thermique.

## 1. Les fusées

Chaque pièce traverse au moins deux procédés Create. Pour le tier N (plaque du tier, plaque secondaire et rivets selon le tableau) :

| Pièce | Fabrication |
|---|---|
| Cône de nez | assemblage séquentiel : plaque + tuile thermique (déployeur) → presse → scie (×2) |
| Segment de coque | assemblage séquentiel : plaque + plaque secondaire + rivets (déployeur) → presse (×2) |
| Module de réservoir | assemblage séquentiel : cuve Create + plaque → presse → remplissage de résine isolante (250 mB) → presse (×2) |
| Jeu d'ailerons | scie sur une plaque |
| Moteur | chambre de combustion (compactage chauffé, surchauffé dès T4) + tuyère (presse sur un bloc d'alliage, puis papier de verre) + turbopompe (assemblage séquentiel sur un mécanisme de précision) → établi mécanique |
| Ordinateur de bord | assemblage séquentiel sur un mécanisme de précision (tube électronique, plaque de cuivre, plaque du tier) |
| Cockpit | établi mécanique : verre + polymère + ordinateur de bord + plaques |
| Propulseur d'appoint, train d'atterrissage | établi mécanique (à partir du T3) |

| Tier | Plaque principale | Plaque secondaire | Rivets | Bloc de tuyère |
|---|---|---|---|---|
| T1 Pionnière | steel_sheet | Create iron_sheet | steel_nugget | steel_block |
| T2 Éclaireuse | titanium_sheet | steel_sheet | titanium_nugget | titanium_block |
| T3 Voyageuse | stainless_steel_sheet | titanium_sheet | chromium_nugget | stainless_steel_block |
| T4 Conquérante | tungsten_sheet | stainless_steel_sheet | tungsten_nugget | tungsten_block |
| T5 Stellaire | stellar_alloy_sheet | tungsten_sheet | cryonium_nugget | stellar_alloy_block |

L'**assemblage final** se fait à l'établi mécanique (Mechanical Crafter) : la grille dessine la fusée (N cône, A cockpit, H coque, T réservoir, F ailerons, E moteur, B propulseur, L train d'atterrissage).

T1 :
```
 N 
 A 
 H 
 T 
FTF
FEF
```
T2 :
```
 N 
 A 
 H 
 T 
 T 
FTF
FEF
```
T3 :
```
  N  
  A  
  H  
  T  
  T  
FBEBF
L   L
```
T4 :
```
  N  
  A  
  H  
  H  
  T  
 BTB 
FBEBF
L   L
```
T5 :
```
  N  
  A  
  H  
  H  
  T  
  T  
 BTB 
FBEBF
L   L
```

## 2. Pas de tir et lancement

- **Dalle de lancement** (`launch_pad_plate`) : pas de tir carré plein de 3×3 (T1–T2), 5×5 (T3–T4) ou 7×7 (T5). Posez la **console** (`launch_console`) et le **raccord de ravitaillement** (`fueling_port`, prise de fluide pour tuyaux) à côté.
- Clic droit avec l'item fusée sur une dalle : la fusée se pose. Ravitaillement : seaux (clic droit sur la fusée), ou tuyaux Create vers le raccord. Clic droit accroupi = état.
- Clic droit (sans seau) pour monter à bord. **G** (touche réglable « Lancer la fusée ») ou clic droit sur la console : compte à rebours de 10 s, puis ascension. La **carte stellaire** s'ouvre en altitude ; choisissez la destination.
- Carburants : **kérosène** (T1–T2), **hydrolox** (T3–T4), **méthalox** (T5). Un carburant de grade supérieur est accepté par un tier inférieur (−25 % de consommation).
  - Liquéfacteur cryogénique (120 FE/t, titane) : H₂ → hydrogène liquide, O₂ → oxygène liquide, méthane → méthane liquide ; puis hydrolox (500 LH₂ + 250 LOX) et méthalox (500 LCH₄ + 500 LOX).
  - Méthane : mixeur chauffé, glace de méthane (Europe) ou 4 chairs putréfiées + 250 mB d'eau.
- Vous arrivez sur un pad 7×7 généré automatiquement ; la fusée est déjà là avec le carburant restant. Retour : carte stellaire → « Retour sur Terre ».

## 3. Combinaisons spatiales

| Tier | Nom | Oxygène (mB) | Froid | Chaleur | Matériau d'isolation |
|---|---|---|---|---|---|
| T1 | Pionnier | 2000 | 1 | 1 | leather |
| T2 | Éclaireur | 3500 | 2 | 1 | selene_fur |
| T3 | Voyageur | 5500 | 2 | 3 | red_dust_core |
| T4 | Conquérant | 8000 | 4 | 3 | vulture_feather |
| T5 | Stellaire | 12000 | 5 | 5 | manta_membrane |

Le réservoir est dans le **plastron** : remplissez-le avec le **bec verseur** de Create (posez le plastron sur un dépôt sous le bec et alimentez le bec en oxygène par des tuyaux). Casque + plastron requis pour respirer ; la résistance effective est celle de la pièce la plus faible. Le HUD affiche l'oxygène et les résistances. Chaque pièce se fabrique à l'établi mécanique.

## 4. Les planètes

| Planète | Fusée | Gravité | Froid | Chaleur | Coût aller (mB) | Ressource |
|---|---|---|---|---|---|---|
| Lune | T1 | 0.16 g | 1 | 0 | 1000 | ilménite → titane |
| Mars | T2 | 0.38 g | 2 | 0 | 1500 | chromite → chrome (inox = acier + chrome) |
| Vénus | T3 | 0.9 g | 0 | 3 | 2000 | wolframite → tungstène (bassin surchauffé), soufre |
| Europe | T4 | 0.13 g | 4 | 0 | 2500 | cryonite → cryonium (+ hydrogène liquide), glace de méthane |
| Nova Prime | T5 | 1.1 g | 5 | 5 | 4000 | stellarite → noyaux stellaires |

Nova Prime : froid 5 la nuit, chaleur 5 le jour. **Alliage stellaire** : mixeur surchauffé, tungstène + cryonium + titane.

## 5. Créatures

| Planète | Créature | Comportement | Butin |
|---|---|---|---|
| Lune | Rampeur lunaire | hostile · 20 PV | crawler_chitin, raw_ilmenite |
| Lune | Cosmonaute perdu | hostile · 30 PV | suit_scrap, damaged_oxygen_canister, titanium_nugget |
| Lune | Lièvre sélène | passive · 6 PV | selene_fur |
| Mars | Diable de poussière | hostile · 24 PV | red_dust_core |
| Mars | Scorpion de fer | hostile · 28 PV | scorpion_stinger, raw_chromite |
| Mars | Drone rouillé | neutral · 16 PV | circuit_scrap, electron_tube, steel_sheet |
| Vénus | Limace de magma | hostile · 34 PV | sulfur, magma_gland |
| Vénus | Vautour acide | hostile · 22 PV | vulture_feather |
| Vénus | Méduse nuageuse | neutral · 10 PV | jelly_membrane |
| Europe | Golem de givre | hostile · 60 PV | raw_cryonite |
| Europe | Ver des banquises | hostile · 30 PV | burrower_scale |
| Europe | Raie des glaces | passive · 20 PV | manta_membrane |
| Nova Prime | Traqueur sporulé | hostile · 40 PV | spore_gland |
| Nova Prime | Essaim stellaire | hostile · 8 PV | star_dust |
| Nova Prime | Colosse cristallin | hostile · 120 PV | stellarite_shard |
| Nova Prime | Gardien de Nova | hostile · 600 PV | nova_core, stellarite_shard, star_core |

## 6. Structures

- **Fusée écrasée (Lune)** (Lune) — coffre de butin, repérez-les depuis votre fusée.
- **Habitat lunaire** (Lune) — coffre de butin, repérez-les depuis votre fusée.
- **Avant-poste à antenne** (Lune) — coffre de butin, repérez-les depuis votre fusée.
- **Épave de rover** (Mars) — coffre de butin, repérez-les depuis votre fusée.
- **Base à dôme martienne** (Mars) — coffre de butin, repérez-les depuis votre fusée.
- **Site de forage** (Mars) — coffre de butin, repérez-les depuis votre fusée.
- **Épave d'atterrisseur** (Vénus) — coffre de butin, repérez-les depuis votre fusée.
- **Raffinerie de soufre** (Vénus) — coffre de butin, repérez-les depuis votre fusée.
- **Tour en ruine** (Vénus) — coffre de butin, repérez-les depuis votre fusée.
- **Station glaciaire** (Europe) — coffre de butin, repérez-les depuis votre fusée.
- **Sonde écrasée** (Europe) — coffre de butin, repérez-les depuis votre fusée.
- **Laboratoire cryogénique** (Europe) — coffre de butin, repérez-les depuis votre fusée.
- **Ruines extraterrestres** (Nova Prime) — coffre de butin, repérez-les depuis votre fusée.
- **Flèche de cristal** (Nova Prime) — coffre de butin, repérez-les depuis votre fusée.
- **Arène du Gardien** (Nova Prime) — coffre de butin, repérez-les depuis votre fusée.
- L'arène du Gardien (Nova Prime) contient le générateur du boss : *Gardien de Nova* → noyau de Nova.
