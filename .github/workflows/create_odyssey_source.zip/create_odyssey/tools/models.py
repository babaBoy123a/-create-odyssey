"""3D models as cubes (pixel units, y up, ground y=0, front = -z). One script emits BOTH the model (Java LayerDefinition)
and the matching texture sheet, so UVs and textures can never drift apart."""
import json
import math
import zlib
import os
import random

from catalog import *
from paint import Cv, sh, mx, cl


def part(name, pivot, *cubes):
    return {"name": name, "pivot": pivot, "cubes": list(cubes)}


# ------------------------------------------------------------------ mob plans
def plan_crawler():
    legs = []
    i = 0
    for z in (-4, 1, 6):
        for x in (-6, 6):
            legs.append(part(f"leg{i}", (x, 4, z), (x - 1, 0, z - 1, 2, 4, 2, "dark")))
            i += 1
    return [part("body", (0, 3, 0), (-5, 3, -6, 10, 5, 14, "body"), (-1, 8, -2, 2, 2, 8, "accent")),
            part("head", (0, 5, -6), (-3, 3, -11, 6, 5, 5, "body"), (-3, 3, -12, 2, 1, 2, "dark"), (1, 3, -12, 2, 1, 2, "dark"))] + legs


def plan_astronaut():
    return [part("head", (0, 24, 0), (-4, 24, -4, 8, 8, 8, "body")),
            part("body", (0, 24, 0), (-4, 12, -2, 8, 12, 4, "body"), (-3, 13, 2, 6, 9, 3, "dark")),
            part("arm0", (-6, 22, 0), (-8, 12, -2, 4, 12, 4, "body")), part("arm1", (6, 22, 0), (4, 12, -2, 4, 12, 4, "body")),
            part("leg0", (-2, 12, 0), (-4, 0, -2, 4, 12, 4, "body")), part("leg1", (2, 12, 0), (0, 0, -2, 4, 12, 4, "body"))]


def plan_hopper():
    return [part("body", (0, 3, 0), (-3, 3, -4, 6, 5, 8, "body"), (-1, 4, 4, 2, 2, 2, "dark")),
            part("head", (0, 6, -4), (-2, 5, -8, 4, 4, 4, "body")),
            part("ear0", (-1, 9, -6), (-2, 9, -6, 1, 4, 1, "body")), part("ear1", (1, 9, -6), (1, 9, -6, 1, 4, 1, "body")),
            part("leg0", (-2, 3, -3), (-3, 0, -4, 2, 3, 2, "body")), part("leg1", (2, 3, -3), (1, 0, -4, 2, 3, 2, "body")),
            part("leg2", (-2, 4, 3), (-3, 0, 2, 2, 4, 3, "body")), part("leg3", (2, 4, 3), (1, 0, 2, 2, 4, 3, "body"))]


def plan_devil():
    return [part("spin0", (0, 0, 0), (-2, 0, -2, 4, 6, 4, "dark")), part("spin1", (0, 6, 0), (-4, 6, -4, 8, 6, 8, "body")),
            part("spin2", (0, 12, 0), (-6, 12, -6, 12, 8, 12, "body"), (-1, 14, -7, 2, 2, 1, "glow")),
            part("spin3", (0, 20, 0), (-8, 20, -8, 16, 10, 16, "dark"), (-2, 24, -9, 4, 2, 1, "glow"))]


def plan_scorpion():
    legs = []
    i = 0
    for z in (-3, 3):
        for x in (-6, 6):
            legs.append(part(f"leg{i}", (x, 4, z), (x - 1, 0, z - 1, 2, 4, 2, "dark")))
            i += 1
    return [part("body", (0, 3, 0), (-5, 3, -6, 10, 4, 12, "body")),
            part("head", (0, 4, -6), (-3, 3, -10, 6, 4, 4, "body")),
            part("arm0", (-4, 5, -9), (-6, 4, -14, 3, 2, 7, "dark"), (-7, 4, -16, 3, 2, 3, "accent")),
            part("arm1", (4, 5, -9), (3, 4, -14, 3, 2, 7, "dark"), (4, 4, -16, 3, 2, 3, "accent")),
            part("tail0", (0, 5, 6), (-1, 5, 6, 2, 2, 6, "body"), (-1, 6, 10, 2, 6, 2, "body"), (-1, 12, 9, 2, 3, 2, "accent"))] + legs


def plan_drone():
    return [part("body", (0, 4, 0), (-4, 4, -4, 8, 8, 8, "body"), (-2, 6, -5, 4, 3, 1, "glow"), (0, 12, 2, 1, 5, 1, "accent")),
            part("spin0", (0, 12, 0), (-8, 12, -1, 16, 1, 2, "dark"), (-1, 12, -8, 2, 1, 16, "dark")),
            part("skids", (0, 2, 0), (-5, 2, -3, 1, 2, 6, "dark"), (4, 2, -3, 1, 2, 6, "dark"))]


def plan_slug():
    return [part("body", (0, 0, 0), (-5, 0, -8, 10, 6, 16, "body"), (-4, 6, -4, 8, 3, 8, "accent")),
            part("head", (0, 3, -8), (-4, 1, -11, 8, 5, 4, "body")),
            part("eye0", (-3, 6, -10), (-3, 6, -10, 1, 4, 1, "glow")), part("eye1", (2, 6, -10), (2, 6, -10, 1, 4, 1, "glow")),
            part("tail", (0, 0, 8), (-3, 0, 8, 6, 4, 5, "body"), (-2, 0, 13, 4, 3, 3, "body"))]


def plan_vulture():
    return [part("body", (0, 5, 0), (-3, 5, -5, 6, 5, 10, "body")),
            part("head", (0, 9, -5), (-2, 9, -8, 4, 4, 4, "body"), (-1, 10, -11, 2, 2, 3, "accent")),
            part("wing0", (-3, 9, 0), (-14, 8, -3, 11, 1, 8, "body"), (-17, 8, -2, 3, 1, 5, "dark")),
            part("wing1", (3, 9, 0), (3, 8, -3, 11, 1, 8, "body"), (14, 8, -2, 3, 1, 5, "dark")),
            part("tail", (0, 6, 5), (-2, 6, 5, 4, 1, 6, "dark")),
            part("talons", (0, 5, 0), (-2, 2, -1, 1, 3, 1, "dark"), (1, 2, -1, 1, 3, 1, "dark"))]


def plan_jelly():
    tents = []
    for i, (x, z) in enumerate(((-3, -3), (3, -3), (-3, 3), (3, 3))):
        tents.append(part(f"tent{i}", (x, 8, z), (x - 1, 0, z - 1, 2, 8, 2, "glow")))
    return [part("dome", (0, 10, 0), (-5, 10, -5, 10, 6, 10, "body"), (-4, 16, -4, 8, 2, 8, "glow"), (-6, 8, -6, 12, 2, 12, "dark"))] + tents


def plan_golem():
    return [part("body", (0, 14, 0), (-7, 14, -4, 14, 14, 8, "body"), (-3, 18, -5, 6, 6, 1, "glow")),
            part("head", (0, 28, 0), (-4, 28, -4, 8, 8, 8, "body"), (-3, 36, -1, 2, 3, 2, "glow"), (1, 36, -1, 2, 3, 2, "glow")),
            part("arm0", (-9, 26, 0), (-13, 10, -3, 5, 18, 6, "body")), part("arm1", (9, 26, 0), (8, 10, -3, 5, 18, 6, "body")),
            part("leg0", (-3, 14, 0), (-6, 0, -3, 6, 14, 6, "body")), part("leg1", (3, 14, 0), (0, 0, -3, 6, 14, 6, "body")),
            part("crystals", (0, 26, 0), (-10, 26, -2, 3, 5, 3, "glow"), (7, 26, -2, 3, 5, 3, "glow"))]


def plan_burrower():
    return [part("head", (0, 0, -8), (-5, 0, -12, 10, 7, 8, "body"), (-4, 1, -14, 2, 2, 3, "accent"), (2, 1, -14, 2, 2, 3, "accent")),
            part("seg0", (0, 0, -4), (-4, 0, -4, 8, 6, 8, "body"), (-1, 6, -4, 2, 1, 10, "accent")),
            part("seg1", (0, 0, 4), (-3, 0, 4, 6, 5, 6, "body")), part("seg2", (0, 0, 10), (-2, 0, 10, 4, 4, 5, "body")),
            part("seg3", (0, 0, 15), (-1, 0, 15, 2, 3, 3, "dark"))]


def plan_manta():
    return [part("body", (0, 5, 0), (-8, 5, -8, 16, 3, 16, "body"), (-3, 5, -11, 6, 3, 3, "body")),
            part("wing0", (-8, 6, 0), (-16, 5, -8, 8, 2, 16, "body")), part("wing1", (8, 6, 0), (8, 5, -8, 8, 2, 16, "body")),
            part("tail", (0, 5, 8), (-1, 5, 8, 2, 2, 12, "dark"))]


def plan_stalker():
    return [part("head", (0, 26, 0), (-3, 26, -3, 6, 6, 6, "body")),
            part("body", (0, 26, 0), (-3, 14, -2, 6, 12, 4, "body"), (-2, 16, 2, 4, 6, 3, "glow"), (-1, 22, 2, 2, 3, 2, "glow")),
            part("arm0", (-4, 24, 0), (-6, 10, -1, 2, 14, 2, "dark")), part("arm1", (4, 24, 0), (4, 10, -1, 2, 14, 2, "dark")),
            part("leg0", (-2, 14, 0), (-3, 0, -1, 2, 14, 2, "dark")), part("leg1", (2, 14, 0), (1, 0, -1, 2, 14, 2, "dark"))]


def plan_swarm():
    return [part("body", (0, 2, 0), (-2, 2, -2, 4, 4, 4, "glow")),
            part("wing0", (-2, 5, 0), (-6, 5, -1, 4, 1, 3, "body")), part("wing1", (2, 5, 0), (2, 5, -1, 4, 1, 3, "body"))]


def plan_colossus():
    return [part("body", (0, 18, 0), (-9, 18, -5, 18, 16, 10, "body")),
            part("crystals", (0, 34, 0), (-6, 34, 0, 4, 8, 4, "glow"), (2, 32, 1, 4, 10, 4, "glow"), (-2, 34, 2, 4, 6, 4, "glow")),
            part("head", (0, 34, 0), (-5, 34, -5, 10, 8, 10, "body"), (-2, 40, -1, 4, 4, 2, "glow")),
            part("arm0", (-11, 32, 0), (-17, 8, -4, 7, 26, 8, "body")), part("arm1", (11, 32, 0), (10, 8, -4, 7, 26, 8, "body")),
            part("leg0", (-4, 18, 0), (-8, 0, -4, 8, 18, 8, "body")), part("leg1", (4, 18, 0), (0, 0, -4, 8, 18, 8, "body"))]


def plan_warden():
    return [part("core", (0, 20, 0), (-8, 12, -8, 16, 16, 16, "body"), (-4, 18, -9, 8, 4, 1, "glow"),
                 (-6, 28, -6, 12, 3, 12, "dark"), (-2, 31, -2, 4, 4, 4, "glow")),
            part("plate0", (0, 20, 0), (-13, 14, -6, 2, 12, 12, "dark")), part("plate1", (0, 20, 0), (11, 14, -6, 2, 12, 12, "dark")),
            part("spin0", (0, 20, 0), (10, 18, -2, 4, 6, 4, "glow"), (-14, 18, -2, 4, 6, 4, "glow")),
            part("spin1", (0, 20, 0), (-2, 18, 10, 4, 6, 4, "glow"), (-2, 18, -14, 4, 6, 4, "glow"))]


PLANS = {"crawler": plan_crawler, "astronaut": plan_astronaut, "hopper": plan_hopper, "devil": plan_devil,
         "scorpion": plan_scorpion, "drone": plan_drone, "slug": plan_slug, "vulture": plan_vulture, "jelly": plan_jelly,
         "golem": plan_golem, "burrower": plan_burrower, "manta": plan_manta, "stalker": plan_stalker,
         "swarm": plan_swarm, "colossus": plan_colossus, "warden": plan_warden}


# ------------------------------------------------------------------ rockets
def rocket_parts(t):
    r = {1: 6, 2: 6, 3: 7, 4: 8, 5: 9}[t]
    n = {1: 2, 2: 3, 3: 3, 4: 4, 5: 5}[t]
    c = [(-r + 2, 0, -r + 2, 2 * (r - 2), 4, 2 * (r - 2), "dark"), (-r, 4, -r, 2 * r, 4, 2 * r, "metal")]
    y = 8
    for i in range(n):
        c.append((-r, y, -r, 2 * r, 24, 2 * r, "hull"))
        c.append((-r - 1, y + 21, -r - 1, 2 * r + 2, 2, 2 * r + 2, "accent"))
        y += 24
    c.append((-r, y, -r, 2 * r, 16, 2 * r, "hull"))
    c.append((-r + 2, y + 4, -r - 1, 2 * r - 4, 7, 1, "glass"))
    c.append((-r - 1, y + 14, -r - 1, 2 * r + 2, 2, 2 * r + 2, "accent"))
    y += 16
    for h, w in ((8, 2 * r - 2), (8, max(4, r)), (8, 2)):
        c.append((-w // 2, y, -w // 2, w, h, w, "accent" if h == 8 and w == 2 else "hull"))
        y += h
    fw, fh = 6 + t, 18 + 4 * t
    c += [(-r - fw, 2, -1, fw, fh, 2, "accent"), (r, 2, -1, fw, fh, 2, "accent"),
          (-1, 2, -r - fw, 2, fh, fw, "accent"), (-1, 2, r, 2, fh, fw, "accent"),
          (-r - fw, 0, -2, 4, 2, 4, "dark"), (r + fw - 4, 0, -2, 4, 2, 4, "dark"),
          (-2, 0, -r - fw, 4, 2, 4, "dark"), (-2, 0, r + fw - 4, 4, 2, 4, "dark")]
    if t >= 3:
        d = r + 2
        spots = [(-d, -d), (d, d)] if t == 3 else [(-d, -d), (d, d), (-d, d), (d, -d)]
        for bx, bz in spots:
            c += [(bx - 3, 4, bz - 3, 6, 24 * n - 4, 6, "hull"), (bx - 2, 24 * n, bz - 2, 4, 6, 4, "accent"),
                  (bx - 1, 24 * n + 6, bz - 1, 2, 4, 2, "accent"), (bx - 2, 0, bz - 2, 4, 4, 4, "dark"),
                  (bx - 4, 16, bz - 1, 1, 2, 2, "metal")]
    if t >= 4:
        c.append((-r - 1, 8 + 12, -r - 1, 2 * r + 2, 1, 2 * r + 2, "glow"))
    if t == 5:
        c.append((-r - 1, 8 + 60, -r - 1, 2 * r + 2, 1, 2 * r + 2, "glow"))
    return [part("rocket", (0, 0, 0), *c)]


# ------------------------------------------------------------------ UV packing + painting
def pack(parts, W):
    x = y = rowh = 0
    for p in parts:
        newc = []
        for (cx, cy, cz, w, h, d, st) in p["cubes"]:
            bw, bh = 2 * d + 2 * w, d + h
            if x + bw > W:
                x, y, rowh = 0, y + rowh, 0
            newc.append((cx, cy, cz, w, h, d, st, x, y))
            x += bw
            rowh = max(rowh, bh)
        p["cubes"] = newc
    H = y + rowh
    return W, ((H + 15) // 16) * 16


def paint_cube(cv, u, v, w, h, d, base, dark, acc, style, st, rng, is_head_front=False):
    faces = {"top": (u + d, v, w, d, 1.12), "bottom": (u + d + w, v, w, d, 0.62), "right": (u, v + d, d, h, 0.84),
             "front": (u + d, v + d, w, h, 1.0), "left": (u + d + w, v + d, d, h, 0.84), "back": (u + 2 * d + w, v + d, w, h, 0.9)}
    col = {"body": base, "dark": dark, "accent": acc, "glow": acc, "hull": base, "metal": dark, "glass": (46, 98, 176)}[st]
    for name, (fx, fy, fw, fh, shade) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                f = shade * (1 + (rng.random() - 0.5) * 0.12)
                c = col
                if st == "glow":
                    dx, dy = (xx - fw / 2) / max(1, fw / 2), (yy - fh / 2) / max(1, fh / 2)
                    c = mx(acc, (255, 255, 255), max(0, 0.65 - math.hypot(dx, dy) * 0.6))
                    f = 1 + (rng.random() - 0.5) * 0.06
                elif st in ("body", "hull", "metal"):
                    if style == "chitin" and (yy % 3 == 0):
                        f *= 0.86
                    elif style == "suit" and (xx % 4 == 0 or yy % 4 == 0):
                        f *= 0.78
                    elif style in ("metal",) and (xx % 5 == 0 or yy % 5 == 0):
                        f *= 0.74
                    elif style == "fur":
                        f *= 1 + (rng.random() - 0.5) * 0.22
                    elif style == "crystal":
                        f *= 1.18 if ((xx + yy) % 5 == 0) else (0.9 if (xx - yy) % 6 == 0 else 1)
                    elif style == "feather" and yy % 2 == 0:
                        f *= 0.9
                    elif style == "dust":
                        f *= 1 + (rng.random() - 0.5) * 0.3
                    if st == "hull" and (xx % 8 == 0):
                        f *= 0.8
                elif st == "glass":
                    f *= 1.25 if (xx + yy) % 4 == 0 else 1
                cv.p(fx + xx, fy + yy, sh(c, f))
        if name == "front" and is_head_front and fw >= 4 and fh >= 3:
            ey = fy + max(1, fh // 3)
            ex1, ex2 = fx + max(0, fw // 4), fx + min(fw - 1, (fw * 3) // 4 - (1 if fw >= 8 else 0))
            for (ex) in {ex1, ex2}:
                cv.p(ex, ey, (255, 255, 255)); cv.p(ex, ey + 1 if fh >= 5 else ey, acc)
    return


def paint_sheet(parts, W, H, pal, style, seed, visor=False):
    base, dark, acc = pal
    cv = Cv(W, H)
    rng = random.Random(seed)
    for p in parts:
        for i, (cx, cy, cz, w, h, d, st, u, v) in enumerate(p["cubes"]):
            head = (p["name"] == "head" and i == 0) or (p["name"] in ("core", "dome") and i == 0 and False)
            paint_cube(cv, u, v, w, h, d, base, dark, acc, style, st, rng, is_head_front=head)
            if visor and p["name"] == "head" and i == 0:
                fx, fy = u + d, v + d
                for yy in range(2, min(5, h)):
                    for xx in range(1, w - 1):
                        cv.p(fx + xx, fy + yy, (40, 86, 164) if yy < 4 else (26, 56, 120))
                cv.p(fx + 2, fy + 2, (190, 226, 255))
    return cv


# ------------------------------------------------------------------ java emission
def f(v):
    return f"{float(v)}F"


def java_layer(name, parts, W, H):
    out = [f"    public static LayerDefinition {name}() {{",
           "        MeshDefinition mesh = new MeshDefinition();",
           "        PartDefinition root = mesh.getRoot();"]
    for p in parts:
        px, py, pz = p["pivot"]
        builder = "CubeListBuilder.create()"
        for (cx, cy, cz, w, h, d, st, u, v) in p["cubes"]:
            builder += f".texOffs({u}, {v}).addBox({f(cx - px)}, {f(py - cy - h)}, {f(cz - pz)}, {f(w)}, {f(h)}, {f(d)})"
        out.append(f'        root.addOrReplaceChild("{p["name"]}", {builder}, PartPose.offset({f(px)}, {f(24 - py)}, {f(pz)}));')
    out.append(f"        return LayerDefinition.create(mesh, {W}, {H});")
    out.append("    }")
    return "\n".join(out)


def rocket_item_model(tier, parts):
    cubes = parts[0]["cubes"]
    mxx = max(max(abs(c[0]), abs(c[0] + c[3])) for c in cubes)
    top = max(c[1] + c[4] for c in cubes)
    s = min(15.0 / top, 15.0 / (2 * mxx))
    styles = ["hull", "accent", "glass", "metal", "glow", "dark"]
    elems = []
    for (x, y, z, w, h, d, st, u, v) in cubes:
        idx = styles.index(st)
        uv = [idx, 0, idx + 1, 1]
        face = {k: {"uv": uv, "texture": "#0"} for k in ("north", "east", "south", "west", "up", "down")}
        fr = [round(8 + x * s, 3), round(0.5 + y * s, 3), round(8 + z * s, 3)]
        to = [round(8 + (x + w) * s, 3), round(0.5 + (y + h) * s, 3), round(8 + (z + d) * s, 3)]
        elems.append({"from": fr, "to": to, "faces": face})
    return {"textures": {"0": f"{MODID}:item/rocket_t{tier}_palette", "particle": f"{MODID}:item/rocket_t{tier}_palette"},
            "elements": elems,
            "gui_light": "side",
            "display": {"gui": {"rotation": [25, 135, 0], "translation": [0, 0, 0], "scale": [0.85, 0.85, 0.85]},
                        "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.45, 0.45, 0.45]},
                        "fixed": {"rotation": [0, 90, 0], "translation": [0, 0, 0], "scale": [0.8, 0.8, 0.8]},
                        "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.5, 0.5, 0.5]},
                        "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]}}}


def generate(write_json):
    """Writes entity/rocket textures, rocket item models + palettes; returns Java source for GeneratedModels."""
    java = ["package com.createodyssey.client;", "",
            "import net.minecraft.client.model.geom.PartPose;", "import net.minecraft.client.model.geom.builders.*;", "",
            "/** GENERATED by tools/models.py - do not edit. */",
            "public final class GeneratedModels {", "    private GeneratedModels() {}", ""]
    part_names = {}
    for m in MOBS:
        parts = PLANS[m["plan"]]()
        W, H = pack(parts, 128)
        cv = paint_sheet(parts, W, H, m["pal"], m["style"], zlib.crc32(m["id"].encode()) & 0xFFFF, visor=(m["plan"] == "astronaut"))
        cv.save(os.path.join(ASSETS, "textures", "entity", f"{m['id']}.png"))
        java.append(java_layer(m["id"], parts, W, H))
        java.append("")
        part_names[m["id"]] = [p["name"] for p in parts]
    for t in TIERS:
        parts = rocket_parts(t)
        W, H = pack(parts, 256)
        pal = (TIER_PRIMARY[t], sh(TIER_PRIMARY[t], 0.45), TIER_ACCENT[t])
        cv = paint_sheet(parts, W, H, pal, "metal" if t != 1 else "suit", 100 + t)
        cv.save(os.path.join(ASSETS, "textures", "entity", f"rocket_t{t}.png"))
        java.append(java_layer(f"rocket_t{t}", parts, W, H))
        java.append("")
        # item model + palette
        write_json(os.path.join(ASSETS, "models", "item", f"rocket_t{t}.json"), rocket_item_model(t, parts))
        pc = Cv(16, 16)
        cols = [TIER_PRIMARY[t], TIER_ACCENT[t], (58, 112, 198), sh(TIER_PRIMARY[t], 0.62), mx(TIER_ACCENT[t], (255, 255, 255), 0.4),
                sh(TIER_PRIMARY[t], 0.38)]
        for i, col in enumerate(cols):
            pc.rect(i, 0, i + 1, 16, col)
        pc.save(os.path.join(ASSETS, "textures", "item", f"rocket_t{t}_palette.png"))
    java.append("    public static LayerDefinition mob(String id) {")
    java.append("        return switch (id) {")
    for m in MOBS:
        java.append(f'            case "{m["id"]}" -> {m["id"]}();')
    java.append('            default -> throw new IllegalArgumentException("No model for " + id);')
    java.append("        };")
    java.append("    }")
    java.append("")
    java.append("    public static String[] parts(String id) {")
    java.append("        return switch (id) {")
    for mid, names in part_names.items():
        arr = ", ".join(f'"{n}"' for n in names)
        java.append(f'            case "{mid}" -> new String[] {{{arr}}};')
    java.append("            default -> new String[0];")
    java.append("        };")
    java.append("    }")
    java.append("")
    java.append("    public static LayerDefinition rocket(int tier) {")
    java.append("        return switch (tier) {")
    for t in TIERS:
        java.append(f"            case {t} -> rocket_t{t}();")
    java.append("            default -> rocket_t1();")
    java.append("        };")
    java.append("    }")
    java.append("}")
    return "\n".join(java) + "\n"
