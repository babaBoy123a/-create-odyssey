#!/usr/bin/env python3
"""Cheap API audit without a compiler: every import must exist in Create/NeoForge sources or be used by real 1.21.1 mods."""
import os, re, sys
REFS = "/home/claude/refs"
MY = "/home/claude/create_odyssey/src/main/java"
imp = re.compile(r"^import\s+(static\s+)?([\w.]+)(\.\*)?;", re.M)

known = set()
for base in (f"{REFS}/create/src/main/java", f"{REFS}/neoforge/src", f"{REFS}/neoforge/tests", f"{REFS}/mdk/src", f"{REFS}/ccg/src"):
    for dp, _, fs in os.walk(base):
        for f in fs:
            if f.endswith(".java"):
                try:
                    txt = open(os.path.join(dp, f), encoding="utf-8", errors="ignore").read()
                except OSError:
                    continue
                for m in imp.finditer(txt):
                    known.add(m.group(2))

def exists_in_repo(name):
    path = name.replace(".", "/") + ".java"
    if name.startswith("com.simibubi.create."):
        return os.path.exists(f"{REFS}/create/src/main/java/{path}")
    if name.startswith("net.neoforged.neoforge."):
        return os.path.exists(f"{REFS}/neoforge/src/main/java/{path}") or os.path.exists(f"{REFS}/neoforge/src/client/java/{path}")
    return None

bad, unknown = [], []
mine = set()
for dp, _, fs in os.walk(MY):
    for f in fs:
        if f.endswith(".java"):
            p = os.path.join(dp, f)
            mod = ".".join(os.path.relpath(p, MY)[:-5].split(os.sep))
            mine.add(mod)
for dp, _, fs in os.walk(MY):
    for f in fs:
        if not f.endswith(".java"):
            continue
        p = os.path.join(dp, f)
        txt = open(p, encoding="utf-8").read()
        for m in imp.finditer(txt):
            name = m.group(2)
            if name in mine or name.startswith("java.") or name.startswith("javax.annotation"):
                continue
            r = exists_in_repo(name)
            if r is False:
                bad.append((os.path.relpath(p, MY), name))
            elif r is None and name not in known:
                unknown.append((os.path.relpath(p, MY), name))
print("== imports that do NOT exist in the Create/NeoForge sources (certain errors):")
for b in bad: print("  ", *b)
print("== imports never seen in any reference 1.21.1 code (check by hand):")
for u in sorted(set(unknown)): print("  ", *u)
print(f"known corpus imports: {len(known)}")
