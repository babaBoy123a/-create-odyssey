"""Deterministic procedural pixel art (Pillow). Every texture of the mod comes from here."""
import math
import os
import random
from PIL import Image


def cl(v):
    return max(0, min(255, int(v)))


def sh(c, f):
    return (cl(c[0] * f), cl(c[1] * f), cl(c[2] * f))


def mx(a, b, t):
    return tuple(cl(a[i] * (1 - t) + b[i] * t) for i in range(3))


class Cv:
    def __init__(self, w=16, h=16, bg=(0, 0, 0, 0)):
        self.im = Image.new("RGBA", (w, h), bg)
        self.px = self.im.load()
        self.w, self.h = w, h

    def p(self, x, y, c, a=255):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[x, y] = (c[0], c[1], c[2], a)

    def get(self, x, y):
        return self.px[x, y] if 0 <= x < self.w and 0 <= y < self.h else (0, 0, 0, 0)

    def rect(self, x0, y0, x1, y1, c, a=255):
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.p(x, y, c, a)

    def circle(self, cx, cy, r, c, a=255):
        for y in range(int(cy - r) - 1, int(cy + r) + 2):
            for x in range(int(cx - r) - 1, int(cx + r) + 2):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    self.p(x, y, c, a)

    def noise(self, base, var, seed, x0=0, y0=0, x1=None, y1=None):
        r = random.Random(seed)
        x1 = self.w if x1 is None else x1
        y1 = self.h if y1 is None else y1
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.p(x, y, sh(base, 1 + (r.random() - 0.5) * var))

    def opaque(self, x, y):
        return self.get(x, y)[3] > 0

    def light(self):
        src = self.im.copy().load()
        for y in range(self.h):
            for x in range(self.w):
                r, g, b, a = src[x, y]
                if a == 0:
                    continue
                up = self.get(x, y - 1)[3] > 0 and (x, y - 1)
                f = 1.0
                if y == 0 or src[x, y - 1][3] == 0:
                    f *= 1.22
                if x == 0 or src[x - 1, y][3] == 0:
                    f *= 1.1
                if y == self.h - 1 or src[x, y + 1][3] == 0:
                    f *= 0.78
                if x == self.w - 1 or src[x + 1, y][3] == 0:
                    f *= 0.88
                self.px[x, y] = (cl(r * f), cl(g * f), cl(b * f), a)

    def outline(self):
        src = self.im.copy().load()
        for y in range(self.h):
            for x in range(self.w):
                if src[x, y][3] != 0:
                    continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self.w and 0 <= ny < self.h and src[nx, ny][3] > 200:
                        r, g, b, _ = src[nx, ny]
                        self.px[x, y] = (cl(r * 0.28), cl(g * 0.28), cl(b * 0.3), 255)
                        break

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.im.save(path)


def finish(cv, outline=True):
    cv.light()
    if outline:
        cv.outline()
    return cv


# ---------------------------------------------------------------- metal items
def ingot(c):
    cv = Cv()
    cv.rect(4, 5, 12, 6, sh(c, 1.3))
    cv.rect(3, 6, 13, 10, c)
    cv.rect(3, 10, 13, 11, sh(c, 0.72))
    cv.rect(12, 6, 13, 10, sh(c, 0.85))
    cv.p(5, 6, sh(c, 1.6)); cv.p(6, 7, sh(c, 1.45))
    return finish(cv)


def nugget(c):
    cv = Cv()
    for x, y in [(5, 8), (8, 6), (7, 10), (10, 9)]:
        cv.rect(x, y, x + 3, y + 3, c)
        cv.p(x, y, sh(c, 1.5))
    return finish(cv)


def sheet(c):
    cv = Cv()
    cv.rect(2, 3, 14, 13, c)
    cv.rect(2, 3, 14, 4, sh(c, 1.3))
    cv.rect(2, 12, 14, 13, sh(c, 0.7))
    for x, y in [(3, 4), (12, 4), (3, 11), (12, 11)]:
        cv.p(x, y, sh(c, 1.7))
    for x in range(5, 11):
        cv.p(x, 8, sh(c, 0.85))
    return finish(cv)


def raw_chunk(c, seed):
    cv = Cv()
    r = random.Random(seed)
    for _ in range(3):
        x, y, s = r.randint(3, 8), r.randint(4, 9), r.randint(4, 6)
        cv.rect(x, y, x + s, y + s - 1, sh(c, 0.9 + r.random() * 0.3))
    cv.noise(c, 0.35, seed + 1, 3, 4, 13, 12)
    for y in range(16):
        for x in range(16):
            if cv.get(x, y)[3] and not (3 <= x < 13 and 4 <= y < 12):
                pass
    return finish(cv)


def dust_pile(c):
    cv = Cv()
    for y in range(7, 13):
        w = (y - 6) * 2
        cv.rect(8 - w // 2 - 1, y, 8 + w // 2 + 1, y + 1, sh(c, 1.0 - (y - 7) * 0.04))
    cv.noise(c, 0.3, 11, 3, 7, 13, 13)
    return finish(cv)


# ---------------------------------------------------------------- rocket part icons
def part_icon(kind, tier_c, acc, trans=False):
    c = tier_c
    cv = Cv()
    if kind == "cone":
        for y in range(2, 14):
            half = int((y - 2) * 0.55) + 1
            cv.rect(8 - half, y, 8 + half, y + 1, c)
        cv.rect(4, 11, 12, 13, acc)
    elif kind == "hull":
        cv.rect(4, 2, 12, 14, c)
        cv.rect(4, 5, 12, 6, acc); cv.rect(4, 10, 12, 11, acc)
        for y in (3, 8, 12):
            cv.p(5, y, sh(c, 0.6)); cv.p(10, y, sh(c, 0.6))
    elif kind == "tank":
        cv.rect(4, 3, 12, 13, c)
        cv.rect(5, 2, 11, 3, sh(c, 0.9)); cv.rect(5, 13, 11, 14, sh(c, 0.8))
        cv.rect(5, 4, 6, 12, sh(c, 1.25)); cv.rect(4, 7, 12, 9, acc)
    elif kind == "fins":
        for y in range(3, 14):
            n = (y - 3) // 2 + 1
            cv.rect(6 - n, y, 6, y + 1, c)
            cv.rect(10, y, 10 + n, y + 1, c)
        cv.rect(6, 6, 10, 14, sh(c, 0.85)); cv.rect(7, 6, 9, 8, acc)
    elif kind == "chamber":
        cv.rect(5, 2, 11, 9, c)
        cv.circle(8, 10, 4, c)
        cv.rect(5, 5, 11, 6, acc)
        cv.rect(7, 12, 9, 14, sh(c, 0.6))
    elif kind in ("nozzle", "nozzle_rough"):
        base = c if kind == "nozzle" else sh(c, 0.62)
        for y in range(3, 14):
            half = 2 + (y - 3) // 2
            cv.rect(8 - half, y, 8 + half, y + 1, base)
        if kind == "nozzle":
            cv.rect(3, 12, 13, 14, acc)
        else:
            cv.noise(base, 0.5, 5, 3, 3, 13, 14)
    elif kind == "pump":
        cv.circle(8, 8, 6, sh(c, 0.7))
        cv.circle(8, 8, 4, c)
        cv.rect(7, 2, 9, 14, sh(c, 1.15)); cv.rect(2, 7, 14, 9, sh(c, 1.15))
        cv.circle(8, 8, 1.6, acc)
    elif kind == "engine":
        cv.rect(5, 2, 11, 7, c); cv.rect(4, 4, 5, 9, acc); cv.rect(11, 4, 12, 9, acc)
        for y in range(7, 14):
            half = 2 + (y - 7) // 2
            cv.rect(8 - half, y, 8 + half, y + 1, sh(c, 0.85))
        cv.rect(4, 12, 12, 14, acc)
    elif kind == "avionics":
        cv.rect(2, 3, 14, 13, (38, 112, 70))
        for x, y, w, h in [(4, 5, 4, 3), (9, 5, 3, 4), (5, 9, 6, 2)]:
            cv.rect(x, y, x + w, y + h, (28, 28, 34))
        for x in range(3, 13, 2):
            cv.p(x, 12, (222, 188, 70))
        cv.rect(11, 10, 13, 12, acc)
    elif kind == "cockpit":
        cv.circle(8, 9, 6, c)
        cv.rect(2, 9, 14, 14, c)
        cv.circle(8, 8, 3.5, (58, 112, 198))
        cv.p(7, 7, (170, 220, 255)); cv.p(8, 7, (170, 220, 255))
        cv.rect(2, 12, 14, 14, acc)
    elif kind == "booster":
        cv.rect(6, 5, 10, 13, c); cv.rect(7, 2, 9, 5, acc); cv.rect(7, 4, 9, 6, c)
        cv.rect(4, 10, 6, 14, acc); cv.rect(10, 10, 12, 14, acc); cv.rect(6, 13, 10, 15, sh(c, 0.6))
    elif kind == "gear":
        cv.rect(7, 2, 9, 7, c)
        for i in range(6):
            cv.rect(7 - i, 7 + i, 9 - i, 8 + i, c)
            cv.rect(7 + i, 7 + i, 9 + i, 8 + i, c)
        cv.rect(1, 13, 6, 14, acc); cv.rect(10, 13, 15, 14, acc)
    cv = finish(cv)
    if trans:
        for y in range(16):
            for x in range(16):
                r, g, b, a = cv.px[x, y]
                if a:
                    f = 0.78 if (x + y) % 2 else 0.9
                    cv.px[x, y] = (cl(r * f), cl(g * f), cl(b * f + 12), 235)
    return cv


# ---------------------------------------------------------------- drops
def drop_icon(kind, c, seed):
    cv = Cv()
    r = random.Random(seed)
    if kind == "shard":
        for y in range(2, 14):
            half = min(y - 1, 14 - y) // 2 + 1
            off = (y - 8) // 3
            cv.rect(8 + off - half, y, 8 + off + half, y + 1, c)
        cv.rect(7, 4, 8, 11, sh(c, 1.4))
    elif kind == "scrap":
        pts = [(3, 5, 7, 4), (6, 8, 7, 4), (4, 10, 4, 3)]
        for x, y, w, h in pts:
            cv.rect(x, y, x + w, y + h, sh(c, 0.9 + r.random() * 0.25))
        cv.p(8, 6, sh(c, 0.5)); cv.p(5, 11, sh(c, 0.5))
    elif kind == "canister":
        cv.rect(5, 3, 11, 14, c); cv.rect(6, 2, 10, 3, (150, 150, 160))
        cv.rect(5, 7, 11, 9, (210, 90, 60)); cv.rect(9, 4, 10, 13, sh(c, 1.3))
        cv.p(7, 5, (30, 30, 36)); cv.p(8, 12, (30, 30, 36))
    elif kind == "fur":
        for _ in range(60):
            x, y = r.randint(3, 12), r.randint(3, 12)
            if (x - 7.5) ** 2 + (y - 7.5) ** 2 < 24:
                cv.p(x, y, sh(c, 0.85 + r.random() * 0.3))
        cv.circle(8, 8, 4, c)
        cv.noise(c, 0.3, seed, 4, 4, 12, 12)
    elif kind == "orb":
        cv.circle(8, 8, 5, c)
        cv.circle(7, 7, 2.2, sh(c, 1.5)); cv.p(6, 6, (255, 255, 255))
    elif kind == "stinger":
        for i in range(10):
            cv.rect(3 + i, 12 - i - (1 if i > 6 else 0), 5 + i - (i // 3), 13 - i, c)
        cv.rect(11, 3, 13, 5, sh(c, 1.4))
    elif kind == "dust":
        cv = dust_pile(c)
    elif kind == "feather":
        for i in range(11):
            cv.rect(3 + i, 13 - i, 6 + i, 14 - i, c)
        for i in range(4):
            cv.p(5 + i * 2, 11 - i * 2 - 1, sh(c, 1.4)); cv.p(7 + i * 2, 12 - i * 2, sh(c, 0.7))
    elif kind == "membrane":
        for y in range(3, 13):
            for x in range(2, 14):
                if abs(math.sin(x * 0.7) * 2 + 8 - y) < 4.5:
                    cv.p(x, y, sh(c, 0.85 + 0.3 * math.sin(x + y)), 220)
    elif kind == "core":
        for y in range(2, 14):
            half = 6 - abs(y - 8)
            cv.rect(8 - half, y, 8 + half, y + 1, c)
        cv.rect(7, 6, 9, 10, (255, 255, 255)); cv.circle(8, 8, 1.2, sh(c, 1.6))
    elif kind == "tile":
        cv.rect(2, 2, 14, 14, c)
        for x in range(2, 14, 4):
            cv.rect(x, 2, x + 1, 14, sh(c, 0.82))
        for y in range(2, 14, 4):
            cv.rect(2, y, 14, y + 1, sh(c, 0.82))
    elif kind == "blob":
        cv.circle(8, 9, 5, c); cv.circle(6, 8, 2, sh(c, 1.6)); cv.noise(c, 0.3, seed, 3, 5, 13, 14)
    return finish(cv)


# ---------------------------------------------------------------- suits
def suit_icon(piece, tc, acc):
    cv = Cv()
    visor = (44, 92, 170)
    if piece == "helmet":
        cv.rect(4, 3, 12, 13, tc); cv.rect(5, 2, 11, 3, tc); cv.rect(3, 5, 4, 11, sh(tc, 0.8)); cv.rect(12, 5, 13, 11, sh(tc, 0.8))
        cv.rect(5, 6, 11, 10, visor); cv.rect(6, 7, 8, 8, (170, 214, 255)); cv.rect(5, 3, 11, 4, acc)
        cv.rect(7, 12, 9, 13, sh(tc, 0.6))
    elif piece == "chestplate":
        cv.rect(3, 4, 13, 14, tc); cv.rect(1, 3, 5, 8, sh(tc, 0.9)); cv.rect(11, 3, 15, 8, sh(tc, 0.9))
        cv.rect(6, 5, 10, 11, acc); cv.rect(7, 6, 9, 8, (255, 240, 200))
        cv.rect(4, 12, 12, 13, sh(tc, 0.7)); cv.rect(2, 1, 4, 4, (150, 190, 220)); cv.rect(12, 1, 14, 4, (150, 190, 220))
    elif piece == "leggings":
        cv.rect(3, 2, 13, 6, tc); cv.rect(3, 6, 7, 14, tc); cv.rect(9, 6, 13, 14, tc)
        cv.rect(3, 4, 13, 5, acc); cv.rect(4, 9, 6, 10, sh(tc, 0.7)); cv.rect(10, 9, 12, 10, sh(tc, 0.7))
    else:
        cv.rect(2, 7, 7, 13, tc); cv.rect(9, 7, 14, 13, tc)
        cv.rect(2, 11, 7, 14, acc); cv.rect(9, 11, 14, 14, acc); cv.rect(3, 8, 5, 9, sh(tc, 1.3))
    return finish(cv)


def armor_layers(tc, acc, seed):
    """64x32 vanilla armor layers: layer_1 (helmet, chest, boots) and layer_2 (leggings)."""
    outs = []
    for layer in (1, 2):
        cv = Cv(64, 32)
        r = random.Random(seed + layer)
        areas = [(0, 0, 32, 16), (16, 16, 40, 32), (40, 16, 56, 32), (0, 16, 16, 32)]
        for x0, y0, x1, y1 in areas:
            for y in range(y0, y1):
                for x in range(x0, x1):
                    f = 1 + (r.random() - 0.5) * 0.1 + (0.06 if (x // 4 + y // 4) % 2 else 0)
                    cv.p(x, y, sh(tc, f))
        # panel lines + rivets
        for x0, y0, x1, y1 in areas:
            for x in range(x0, x1, 8):
                for y in range(y0, y1):
                    cv.p(x, y, sh(tc, 0.72))
            for y in range(y0, y1, 8):
                for x in range(x0, x1):
                    cv.p(x, y, sh(tc, 0.72))
        if layer == 1:
            for x in range(8, 16):                       # visor on the helmet front
                for y in range(9, 14):
                    cv.p(x, y, (36, 80, 160) if y < 12 else (24, 56, 120))
            cv.p(9, 10, (180, 220, 255)); cv.p(10, 10, (180, 220, 255))
            for x in range(8, 16):
                cv.p(x, 8, acc)                          # helmet brow stripe
            for y in range(20, 32):                      # chest accent + back tank
                cv.p(23, y, acc); cv.p(24, y, acc)
            for y in range(20, 32):
                for x in range(32, 40):
                    t = abs(x - 35.5) / 4.0
                    cv.p(x, y, mx((150, 160, 172), (232, 238, 244), 1 - t) if 22 <= y <= 30 else sh(tc, 0.6))
        else:
            for y in range(24, 28):
                for x in range(0, 16):
                    cv.p(x, y, acc if x % 8 < 2 else cv.get(x, y)[:3])
            for x in range(16, 40):
                cv.p(x, 20, acc)                         # belt
        outs.append(cv)
    return outs


# ---------------------------------------------------------------- block tiles
def tile(style, base, seed, extra=None):
    cv = Cv()
    r = random.Random(seed)
    cv.noise(base, 0.14, seed)
    if style == "rock":
        for _ in range(6):
            x, y = r.randint(0, 14), r.randint(0, 14)
            for i in range(r.randint(2, 4)):
                cv.p(x + i, y + (i % 2), sh(base, 0.72))
        for _ in range(10):
            cv.p(r.randint(0, 15), r.randint(0, 15), sh(base, 1.22))
    elif style == "dust":
        cv.noise(base, 0.22, seed + 3)
        for _ in range(26):
            cv.p(r.randint(0, 15), r.randint(0, 15), sh(base, 1.18 if r.random() < 0.5 else 0.82))
        for cx, cy, rad in [(r.randint(3, 12), r.randint(3, 12), 2)]:
            for y in range(16):
                for x in range(16):
                    d = math.hypot(x - cx, y - cy)
                    if abs(d - rad) < 0.7:
                        cv.p(x, y, sh(base, 0.85))
    elif style == "sand":
        for y in range(16):
            for x in range(16):
                w = math.sin((x + y * 0.6) * 0.9 + seed) * 0.06
                cv.p(x, y, sh(base, 1 + w + (r.random() - 0.5) * 0.08))
    elif style == "ice":
        cv.noise(base, 0.1, seed + 2)
        for _ in range(5):
            x, y = r.randint(0, 12), r.randint(0, 15)
            for i in range(r.randint(3, 6)):
                cv.p(x + i, y, (240, 252, 255))
        for _ in range(4):
            x, y = r.randint(0, 15), r.randint(0, 12)
            for i in range(r.randint(2, 4)):
                cv.p(x, y + i, sh(base, 0.8))
    elif style == "crystal":
        cv.noise(base, 0.1, seed)
        for k in range(5):
            x, y = r.randint(1, 13), r.randint(1, 13)
            for i in range(3):
                cv.p(x + i, y + i, sh(base, 1.6)); cv.p(x + i + 1, y + i, sh(base, 1.3)); cv.p(x - i, y + i, sh(base, 0.7))
    elif style == "shale":
        for y in range(16):
            f = 0.8 + 0.25 * (math.sin(y * 1.3 + seed) > 0.2)
            for x in range(16):
                cv.p(x, y, sh(base, f * (1 + (r.random() - 0.5) * 0.15)))
    elif style in ("plating", "plating_cracked"):
        cv.noise(base, 0.08, seed)
        for i in range(16):
            for k in (0, 8, 15):
                cv.p(i, k, sh(base, 0.62)); cv.p(k, i, sh(base, 0.62))
        for x, y in [(2, 2), (5, 2), (10, 2), (13, 2), (2, 13), (13, 13), (2, 10), (13, 10)]:
            cv.p(x, y, sh(base, 1.5))
        if style == "plating_cracked":
            x, y = 3, 3
            for _ in range(16):
                cv.p(x, y, (26, 24, 24)); x += r.choice([0, 1, 1]); y += r.choice([1, 1, 0])
    elif style == "lamp":
        cv.noise((255, 226, 150), 0.1, seed)
        for i in range(16):
            for k in (0, 15):
                cv.p(i, k, (120, 98, 60)); cv.p(k, i, (120, 98, 60))
        for y in range(4, 12):
            for x in range(4, 12):
                cv.p(x, y, (255, 250, 214))
    return cv


def ore_tile(stone_style, stone_base, ore_c, seed):
    cv = tile(stone_style, stone_base, seed)
    r = random.Random(seed + 77)
    for _ in range(5):
        cx, cy = r.randint(2, 13), r.randint(2, 13)
        for dx, dy in [(0, 0), (1, 0), (0, 1), (1, 1)] if r.random() < 0.6 else [(0, 0), (1, 0)]:
            cv.p(cx + dx, cy + dy, sh(ore_c, 0.8 + r.random() * 0.5))
        cv.p(cx, cy, sh(ore_c, 1.45))
    return cv


def metal_block(c, seed):
    cv = Cv()
    cv.noise(c, 0.1, seed)
    for i in range(16):
        for k in (0, 15):
            cv.p(i, k, sh(c, 0.7)); cv.p(k, i, sh(c, 0.7))
        cv.p(i, 1, sh(c, 1.18)); cv.p(1, i, sh(c, 1.12))
        cv.p(i, 8, sh(c, 0.86))
    for x, y in [(3, 3), (12, 3), (3, 12), (12, 12)]:
        cv.p(x, y, sh(c, 1.5)); cv.p(x + 1, y + 1, sh(c, 0.6))
    return cv


def machine_tile(kind, face, seed):
    r = random.Random(seed)
    steel = (112, 118, 130)
    cv = Cv()
    pal = {"electric_refinery": ((126, 122, 116), (240, 130, 40)), "electrolyzer": ((108, 126, 148), (80, 210, 255)),
           "cryo_liquefier": ((170, 182, 196), (160, 235, 255)), "launch_pad_plate": ((132, 134, 140), (250, 210, 40)),
           "launch_console": ((70, 74, 86), (90, 255, 140)), "fueling_port": ((134, 120, 70), (250, 210, 40)),
           "kinetic_alternator": ((132, 110, 90), (214, 120, 60)), "machine_bottom": ((90, 92, 100), (160, 160, 170))}
    base, acc = pal.get(kind, (steel, (200, 200, 200)))
    cv.noise(base, 0.1, seed)
    for i in range(16):
        for k in (0, 15):
            cv.p(i, k, sh(base, 0.68)); cv.p(k, i, sh(base, 0.68))
    if kind == "launch_pad_plate":
        if face == "top":
            for y in range(16):
                for x in range(16):
                    if (x < 2 or x > 13 or y < 2 or y > 13) and ((x + y) // 3) % 2 == 0:
                        cv.p(x, y, (36, 36, 40))
                    elif (x < 2 or x > 13 or y < 2 or y > 13):
                        cv.p(x, y, acc)
            for k in range(4, 12):
                cv.p(k, 8, sh(base, 0.8)); cv.p(8, k, sh(base, 0.8))
    elif kind == "electric_refinery":
        if face == "side":
            for x in range(3, 13):
                for y in (4, 5, 10, 11):
                    cv.p(x, y, sh(base, 0.7))
            cv.rect(6, 6, 10, 10, (40, 36, 34)); cv.rect(7, 7, 9, 9, acc)
        else:
            cv.rect(4, 4, 12, 12, sh(base, 0.8)); cv.rect(6, 6, 10, 10, sh(base, 1.3))
    elif kind == "electrolyzer":
        if face == "side":
            cv.rect(3, 3, 13, 13, (40, 50, 66))
            for y in range(4, 12):
                cv.rect(4, y, 12, y + 1, mx((50, 90, 130), acc, 0.4 + 0.5 * math.sin(y)))
        else:
            cv.rect(4, 4, 12, 12, sh(base, 0.8)); cv.rect(7, 7, 9, 9, acc)
    elif kind == "cryo_liquefier":
        for _ in range(30):
            cv.p(r.randint(1, 14), r.randint(1, 14), (240, 252, 255))
        if face == "side":
            cv.rect(4, 4, 12, 12, (60, 90, 120)); cv.rect(5, 5, 11, 11, mx((90, 140, 190), acc, 0.5))
    elif kind == "launch_console":
        if face == "top":
            cv.rect(2, 2, 14, 14, (24, 30, 34))
            for y in range(3, 13, 2):
                cv.rect(3, y, 3 + r.randint(4, 10), y + 1, acc)
        else:
            cv.rect(3, 6, 13, 12, (28, 32, 40))
            for x in range(4, 12, 2):
                cv.p(x, 8, acc if x % 4 == 0 else (230, 70, 60)); cv.p(x, 10, (250, 210, 60))
    elif kind == "fueling_port":
        for y in range(16):
            for x in range(16):
                if (x < 2 or x > 13) and ((x + y) // 3) % 2 == 0:
                    cv.p(x, y, (36, 36, 40))
        cv.rect(5, 5, 11, 11, (60, 60, 66)); cv.rect(6, 6, 10, 10, (20, 20, 24)); cv.rect(7, 7, 9, 9, acc)
    elif kind == "kinetic_alternator":
        if face == "end":
            cv.circle(8, 8, 6, (70, 60, 56)); cv.circle(8, 8, 4.5, acc); cv.circle(8, 8, 2, (210, 210, 220))
            cv.circle(8, 8, 1, (60, 60, 66))
        else:
            for x in range(2, 14, 3):
                cv.rect(x, 1, x + 2, 15, sh(acc, 0.85 + 0.1 * (x % 2)))
    return cv


def cable_tex():
    cv = Cv()
    cv.noise((196, 112, 58), 0.12, 3)
    for x in range(16):
        cv.p(x, 0, (36, 34, 36)); cv.p(x, 15, (36, 34, 36)); cv.p(x, 7, (52, 48, 52)); cv.p(x, 8, (52, 48, 52))
    return cv


def fluid_still(c, seed, frames=16):
    cv = Cv(16, 16 * frames)
    r = random.Random(seed)
    for f in range(frames):
        for y in range(16):
            for x in range(16):
                w = math.sin((x * 0.55 + f * math.tau / frames)) * 0.07 + math.sin((y * 0.5 + x * 0.3 - f * math.tau / frames)) * 0.07
                cv.p(x, f * 16 + y, sh(c, 1 + w + (r.random() - 0.5) * 0.02), 235)
    return cv


def bucket(c):
    cv = Cv()
    steel = (170, 174, 184)
    for y in range(5, 14):
        half = 5 - (y - 5) // 4
        cv.rect(8 - half, y, 8 + half, y + 1, steel)
    cv.rect(2, 4, 14, 5, sh(steel, 0.8))
    cv.rect(4, 5, 12, 7, c)
    cv.rect(5, 2, 6, 4, sh(steel, 0.7)); cv.rect(10, 2, 11, 4, sh(steel, 0.7)); cv.rect(5, 2, 11, 3, sh(steel, 0.7))
    return finish(cv)


def gui_icon(kind):
    cv = Cv()
    if kind == "o2":
        cv.circle(8, 8, 6, (70, 150, 230)); cv.circle(6, 6, 2, (200, 235, 255)); cv.rect(10, 10, 13, 12, (40, 100, 190))
    elif kind == "cold":
        for k in range(-6, 7):
            cv.p(8 + k, 8, (180, 235, 255)); cv.p(8, 8 + k, (180, 235, 255)); cv.p(8 + k // 1, 8 + k, (140, 210, 245)); cv.p(8 + k, 8 - k, (140, 210, 245))
        cv.circle(8, 8, 1.5, (255, 255, 255))
    elif kind == "heat":
        for y in range(2, 14):
            half = int(4 * math.sin((y - 2) / 11 * math.pi) + 0.5)
            cv.rect(8 - half, y, 8 + half, y + 1, (250, 120 + y * 6, 30))
        cv.rect(7, 9, 9, 13, (255, 230, 120))
    return cv
