#!/usr/bin/env python3
"""Validates every generated resource: JSON syntax, referenced textures/models/items, lang keys, NBT structures."""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from catalog import *
import structures

errors = []
def err(msg): errors.append(msg)

# ---- 1. every json parses
jsons = glob.glob(f"{RES}/**/*.json", recursive=True) + glob.glob(f"{RES}/**/*.mcmeta", recursive=True)
for p in jsons:
    try:
        json.load(open(p, encoding="utf-8"))
    except Exception as e:
        err(f"bad json {p}: {e}")

# ---- known ids
create_ids = set()
lang = json.load(open("/home/claude/refs/create/src/generated/resources/assets/create/lang/en_us.json", encoding="utf-8"))
for k in lang:
    if k.startswith("item.create.") or k.startswith("block.create."):
        create_ids.add(k.split(".", 2)[2])
items = set(simple_item_ids()) | set(transitional_ids())
blocks = {m[0] + "_block" for m in METALS} | {b[0] for b in PLANET_BLOCKS} | {o[0] for o in ORES} | \
         {"kinetic_alternator", "power_cable", "electric_refinery", "electrolyzer", "cryo_liquefier", "launch_pad_plate", "launch_console", "fueling_port"}
fluids = {f[0] for f in FLUIDS}
items |= blocks | {f"{f}_bucket" for f in fluids} | {f"rocket_t{t}" for t in TIERS} | {m["id"] + "_spawn_egg" for m in MOBS}
for t in TIERS:
    for piece in ("helmet", "chestplate", "leggings", "boots"):
        items.add(f"suit_t{t}_{piece}")

def item_exists(ref):
    if ref.startswith("#"):
        return True
    ns, _, name = ref.partition(":") if ":" in ref else (MODID, "", ref)
    if ns == MODID: return name in items
    if ns == "create": return name in create_ids
    return True   # vanilla

# ---- 2. models reference existing textures / parents
for p in glob.glob(f"{ASSETS}/models/**/*.json", recursive=True):
    d = json.load(open(p))
    for k, v in (d.get("textures") or {}).items():
        if v.startswith("#"): continue
        ns, _, path = v.partition(":")
        if ns == MODID and not os.path.exists(f"{ASSETS}/textures/{path}.png"):
            err(f"{p}: missing texture {v}")
    par = d.get("parent", "")
    if par.startswith(MODID + ":") and not os.path.exists(f"{ASSETS}/models/{par.split(':')[1]}.json"):
        err(f"{p}: missing parent {par}")
for p in glob.glob(f"{ASSETS}/blockstates/*.json"):
    txt = open(p).read()
    import re
    for m in re.findall(rf'"model": "{MODID}:([^"]+)"', txt):
        if not os.path.exists(f"{ASSETS}/models/{m}.json"):
            err(f"{p}: missing model {m}")

# ---- 3. every item has a model + texture, every block a blockstate + loot table
for i in items:
    if not os.path.exists(f"{ASSETS}/models/item/{i}.json"): err(f"item without model: {i}")
for b in blocks:
    if not os.path.exists(f"{ASSETS}/blockstates/{b}.json"): err(f"block without blockstate: {b}")
    if not os.path.exists(f"{DATA}/loot_table/blocks/{b}.json"): err(f"block without loot table: {b}")
for f in fluids:
    if not os.path.exists(f"{ASSETS}/blockstates/{f}.json"): err(f"fluid without blockstate: {f}")
for m in MOBS:
    for fn in (f"{ASSETS}/textures/entity/{m['id']}.png", f"{DATA}/loot_table/entities/{m['id']}.json"):
        if not os.path.exists(fn): err(f"missing {fn}")
for t in TIERS:
    for fn in (f"{ASSETS}/textures/entity/rocket_t{t}.png", f"{ASSETS}/textures/models/armor/suit_t{t}_layer_1.png", f"{ASSETS}/textures/models/armor/suit_t{t}_layer_2.png"):
        if not os.path.exists(fn): err(f"missing {fn}")

# ---- 4. lang keys (both languages)
fr = json.load(open(f"{ASSETS}/lang/fr_fr.json", encoding="utf-8")); en = json.load(open(f"{ASSETS}/lang/en_us.json", encoding="utf-8"))
need = [f"item.{MODID}.{i}" for i in items if i not in blocks] + [f"block.{MODID}.{b}" for b in blocks] + \
       [f"block.{MODID}.{f}" for f in fluids] + [f"fluid_type.{MODID}.{f}" for f in fluids] + [f"entity.{MODID}.{m['id']}" for m in MOBS] + \
       [f"planet.{MODID}.{p['id']}" for p in PLANETS] + [f"entity.{MODID}.rocket", "itemGroup.create_odyssey", f"key.create_odyssey.launch"]
for k in need:
    if k not in fr: err(f"lang fr missing {k}")
    if k not in en: err(f"lang en missing {k}")
if set(fr) != set(en): err(f"lang key mismatch fr/en: {sorted(set(fr) ^ set(en))[:5]}")

# ---- 5. recipes
def refs_in(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ("item", "id", "name") and isinstance(v, str): yield v
            else: yield from refs_in(v)
    elif isinstance(obj, list):
        for v in obj: yield from refs_in(v)
for p in glob.glob(f"{DATA}/recipe/**/*.json", recursive=True):
    d = json.load(open(p))
    for r in refs_in(d):
        if ":" in r and r.split(":")[0] in (MODID, "create") and not r.startswith("#"):
            if r.split(":")[0] == MODID and r.split(":")[1] in fluids: continue
            if not item_exists(r): err(f"{os.path.relpath(p, DATA)}: unknown item {r}")
for p in glob.glob(f"{DATA}/loot_table/**/*.json", recursive=True) + glob.glob(f"{DATA}/advancement/*.json"):
    for r in refs_in(json.load(open(p))):
        if r.startswith(MODID + ":") or r.startswith("create:"):
            if not item_exists(r) and "blocks/" not in r and "entities/" not in r:
                err(f"{os.path.relpath(p, DATA)}: unknown item {r}")

# ---- 6. structures
total = 0
for sid, planet, sp, sep in STRUCTURES:
    p = f"{DATA}/structure/{sid}.nbt"
    if not os.path.exists(p): err(f"missing structure {sid}"); continue
    n = structures.read_nbt(p)
    size = n["size"]; blocks_ = n["blocks"]; pal = n["palette"]
    total += len(blocks_)
    for b in blocks_:
        x, y, z = b["pos"]
        if not (0 <= x < size[0] and 0 <= y < size[1] and 0 <= z < size[2]): err(f"{sid}: block out of bounds {b['pos']}"); break
        if b["state"] >= len(pal): err(f"{sid}: bad palette index"); break
    for e in pal:
        nm = e["Name"]
        if nm.startswith(MODID + ":"):
            name = nm.split(":")[1]
            if name not in blocks: err(f"{sid}: unknown mod block {nm}")
    for f in (f"{DATA}/worldgen/structure/{sid}.json", f"{DATA}/worldgen/template_pool/{sid}/start.json", f"{DATA}/worldgen/structure_set/{sid}.json"):
        if not os.path.exists(f): err(f"missing {f}")

# ---- 7. worldgen references
for p in PLANETS:
    for f in (f"{DATA}/dimension/{p['id']}.json", f"{DATA}/dimension_type/{p['id']}.json", f"{DATA}/worldgen/noise_settings/{p['id']}.json"):
        if not os.path.exists(f): err(f"missing {f}")
    for b in p["biomes"]:
        if not os.path.exists(f"{DATA}/worldgen/biome/{b}.json"): err(f"missing biome {b}")
    for ore, tgt, *_ in PLANET_ORES[p["id"]]:
        if not os.path.exists(f"{DATA}/worldgen/placed_feature/{ore}_{p['id']}.json"): err(f"missing placed feature {ore}_{p['id']}")

print(f"checked {len(jsons)} json files, {len(items)} items, {len(blocks)} blocks, {len(fluids)} fluids, {len(MOBS)} mobs, {len(STRUCTURES)} structures ({total} blocks)")
if errors:
    print(f"{len(errors)} PROBLEMS:")
    for e in errors[:60]: print("  -", e)
    sys.exit(1)
print("ALL RESOURCE CHECKS PASSED")
