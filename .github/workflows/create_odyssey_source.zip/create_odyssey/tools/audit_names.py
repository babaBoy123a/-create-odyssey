#!/usr/bin/env python3
"""Heuristic: report capitalised identifiers used in a Java file that are neither imported, declared, same-package nor java.lang."""
import os, re
MY = "/home/claude/create_odyssey/src/main/java"
LANG = set("""String Math Object Integer Double Float Long Boolean Character Byte Short Override Runnable Class Enum StringBuilder
SuppressWarnings Deprecated Exception RuntimeException IllegalArgumentException IllegalStateException Iterable Comparable Number
Thread System Void FunctionalInterface Record SafeVarargs Throwable Error AutoCloseable CharSequence""".split())
wild = {"net.minecraft.client.model.geom.builders": set("LayerDefinition MeshDefinition PartDefinition CubeListBuilder CubeDeformation".split())}
pkgs = {}
for dp, _, fs in os.walk(MY):
    for f in fs:
        if f.endswith(".java"):
            pkg = os.path.relpath(dp, MY).replace(os.sep, ".")
            pkgs.setdefault(pkg, set()).add(f[:-5])
for dp, _, fs in os.walk(MY):
    for f in sorted(fs):
        if not f.endswith(".java"):
            continue
        p = os.path.join(dp, f)
        src = open(p, encoding="utf-8").read()
        pkg = re.search(r"^package\s+([\w.]+);", src, re.M).group(1)
        imported = set()
        for m in re.finditer(r"^import\s+(static\s+)?([\w.]+?)(\.\*)?;", src, re.M):
            if m.group(3):
                imported |= wild.get(m.group(2), set())
            else:
                imported.add(m.group(2).split(".")[-1])
        body = re.sub(r"//.*", "", src)
        body = re.sub(r"/\*.*?\*/", "", body, flags=re.S)
        body = re.sub(r'"(\\.|[^"\\])*"', '""', body)
        declared = set(re.findall(r"\b(?:class|interface|enum|record)\s+([A-Z]\w*)", body))
        generics = set(re.findall(r"<\s*([A-Z])\b(?:\s+extends[^>]*)?>", body)) | set(re.findall(r"\b([A-Z])\b", body))
        used = set(re.findall(r"(?<![\w.])([A-Z][a-z]\w*)\b", body))   # Capitalised words with a lowercase 2nd letter (types), not preceded by a dot
        missing = sorted(u for u in used if u not in imported and u not in declared and u not in LANG
                         and u not in pkgs.get(pkg, set()) and u not in generics)
        if missing:
            print(os.path.relpath(p, MY), "->", ", ".join(missing))
