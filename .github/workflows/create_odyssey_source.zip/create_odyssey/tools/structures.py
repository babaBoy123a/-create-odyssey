"""Generates the 15 structure templates (.nbt) + worldgen JSON (structure, template_pool, structure_set)."""
import gzip
import math
import os
import random
import struct

from catalog import *

DATA_VERSION = 3955  # Minecraft 1.21.1

H = f"{MODID}:hull_plating"
HC = f"{MODID}:cracked_hull_plating"
LAMP = f"{MODID}:habitat_lamp"
AIR = "minecraft:air"


# ------------------------------------------------------------------ NBT
def w_str(s):
    b = s.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def payload(tid, val):
    if tid == 1:
        return struct.pack(">b", val)
    if tid == 2:
        return struct.pack(">h", val)
    if tid == 3:
        return struct.pack(">i", val)
    if tid == 4:
        return struct.pack(">q", val)
    if tid == 5:
        return struct.pack(">f", val)
    if tid == 8:
        return w_str(val)
    if tid == 9:
        et, items = val
        return struct.pack(">bi", et, len(items)) + b"".join(payload(et, i) for i in items)
    if tid == 10:
        out = b""
        for k, (t, v) in val.items():
            out += struct.pack(">b", t) + w_str(k) + payload(t, v)
        return out + b"\x00"
    raise ValueError(tid)


def write_nbt(path, root):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = struct.pack(">b", 10) + w_str("") + payload(10, root)
    with gzip.open(path, "wb") as fh:
        fh.write(data)


def read_nbt(path):
    """Tiny reader used by validate.py to prove files are well formed."""
    with gzip.open(path, "rb") as fh:
        buf = fh.read()
    pos = [0]

    def take(fmt):
        n = struct.calcsize(fmt)
        v = struct.unpack_from(fmt, buf, pos[0])[0]
        pos[0] += n
        return v

    def rstr():
        n = take(">H")
        s = buf[pos[0]:pos[0] + n].decode()
        pos[0] += n
        return s

    def rval(t):
        if t == 1: return take(">b")
        if t == 2: return take(">h")
        if t == 3: return take(">i")
        if t == 4: return take(">q")
        if t == 5: return take(">f")
        if t == 6: return take(">d")
        if t == 8: return rstr()
        if t == 9:
            et = take(">b"); n = take(">i")
            return [rval(et) for _ in range(n)]
        if t == 10:
            d = {}
            while True:
                tt = take(">b")
                if tt == 0:
                    return d
                k = rstr()
                d[k] = rval(tt)
        raise ValueError(t)

    assert take(">b") == 10
    rstr()
    return rval(10)


# ------------------------------------------------------------------ voxel builder
class Vox:
    def __init__(self, seed=1):
        self.b = {}
        self.rng = random.Random(seed)

    def set(self, x, y, z, name, props=None, nbt=None):
        self.b[(int(x), int(y), int(z))] = (name, tuple(sorted((props or {}).items())), nbt)

    def box(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(x0, x1):
            for y in range(y0, y1):
                for z in range(z0, z1):
                    self.set(x, y, z, name, props)

    def shell(self, x0, y0, z0, x1, y1, z1, wall, props=None, fill_air=True):
        for x in range(x0, x1):
            for y in range(y0, y1):
                for z in range(z0, z1):
                    edge = x in (x0, x1 - 1) or y in (y0, y1 - 1) or z in (z0, z1 - 1)
                    if edge:
                        self.set(x, y, z, wall, props)
                    elif fill_air:
                        self.set(x, y, z, AIR)

    def mixed(self, name_a, name_b, p):
        return name_a if self.rng.random() > p else name_b

    def chest(self, x, y, z, planet, facing="south"):
        self.set(x, y, z, "minecraft:chest", {"facing": facing, "type": "single", "waterlogged": "false"},
                 {"id": (8, "minecraft:chest"), "LootTable": (8, f"{MODID}:chests/{planet}")})

    def spawner(self, x, y, z, entity):
        nbt = {"id": (8, "minecraft:mob_spawner"), "SpawnCount": (2, 1), "SpawnRange": (2, 8), "RequiredPlayerRange": (2, 24),
               "MaxNearbyEntities": (2, 1), "MinSpawnDelay": (2, 400), "MaxSpawnDelay": (2, 800), "Delay": (2, 40),
               "SpawnData": (10, {"entity": (10, {"id": (8, entity)})})}
        self.set(x, y, z, "minecraft:spawner", None, nbt)

    def save(self, path):
        xs, ys, zs = [k[0] for k in self.b], [k[1] for k in self.b], [k[2] for k in self.b]
        mnx, mny, mnz = min(xs), min(ys), min(zs)
        palette, pal_idx, blocks = [], {}, []
        for (x, y, z), (name, props, nbt) in sorted(self.b.items()):
            key = (name, props)
            if key not in pal_idx:
                pal_idx[key] = len(palette)
                entry = {"Name": (8, name)}
                if props:
                    entry["Properties"] = (10, {k: (8, v) for k, v in props})
                palette.append(entry)
            blk = {"pos": (9, (3, [x - mnx, y - mny, z - mnz])), "state": (3, pal_idx[key])}
            if nbt:
                blk["nbt"] = (10, nbt)
            blocks.append(blk)
        root = {"DataVersion": (3, DATA_VERSION),
                "size": (9, (3, [max(xs) - mnx + 1, max(ys) - mny + 1, max(zs) - mnz + 1])),
                "palette": (9, (10, [{k: v for k, v in e.items()} for e in palette])),
                "blocks": (9, (10, blocks)),
                "entities": (9, (10, []))}
        write_nbt(path, root)
        return len(blocks)


# ------------------------------------------------------------------ designs
def moon_crashed_rocket():
    v = Vox(11)
    for x in range(0, 24):
        r = 3 if x < 18 else max(1, 3 - (x - 17))
        for dy in range(-3, 4):
            for dz in range(-3, 4):
                d = math.hypot(dy, dz)
                y, z = 3 + dy, 4 + dz
                if x < 2 and v.rng.random() < 0.5:
                    continue
                if r - 0.6 <= d <= r + 0.4:
                    v.set(x, y, z, v.mixed(H, HC, 0.25))
                elif d < r - 0.6:
                    v.set(x, y, z, AIR)
    for x in range(15, 19):
        for k in range(1, 4):
            v.set(x, 3, 4 + 3 + k, H); v.set(x, 3, 4 - 3 - k, H); v.set(x, 3 + 3 + k, 4, HC)
    for _ in range(14):
        v.set(v.rng.randint(-3, 26), 0, v.rng.randint(-2, 10), v.mixed(H, HC, 0.5))
    v.set(6, 5, 4, LAMP); v.set(14, 5, 4, LAMP)
    v.chest(9, 1, 4, "moon", "east")
    return v


def dome(planet, wall, glass, radius=7, chests=2, lamps=True, entry=True, floor=H):
    v = Vox(21)
    c = radius + 1
    for x in range(0, 2 * c + 1):
        for z in range(0, 2 * c + 1):
            for y in range(0, radius + 2):
                d = math.sqrt((x - c) ** 2 + y * y + (z - c) ** 2)
                if y == 0 and d <= radius:
                    v.set(x, y, z, floor)
                elif d <= radius - 0.9 and y > 0:
                    v.set(x, y, z, AIR)
                elif radius - 0.9 < d <= radius + 0.4 and y > 0:
                    ang = int(math.atan2(z - c, x - c) * 3 / math.pi) + y // 3
                    v.set(x, y, z, glass if (ang % 2 == 0 and y > 1) else wall)
    if entry:
        for dx in (0, 1):
            for y in (1, 2, 3):
                v.set(c - 1 + dx, y, 2 * c - 1, AIR); v.set(c - 1 + dx, y, 2 * c, AIR); v.set(c - 1 + dx, y, 2 * c - 2, AIR)
    if lamps:
        v.set(c, radius - 1, c, LAMP)
        v.set(c - 3, radius - 3, c, LAMP); v.set(c + 3, radius - 3, c, LAMP)
    v.chest(c - 3, 1, c, planet, "east")
    if chests > 1:
        v.chest(c + 3, 1, c, planet, "west")
    v.set(c, 1, c - 2, "minecraft:iron_block"); v.set(c, 2, c - 2, "minecraft:lever", {"face": "floor", "facing": "north", "powered": "false"})
    return v


def moon_habitat():
    return dome("moon", H, "minecraft:glass")


def mars_dome_base():
    return dome("mars", HC, "minecraft:tinted_glass", radius=8)


def antenna_outpost():
    v = Vox(31)
    v.shell(0, 0, 0, 7, 5, 7, H)
    for y in (1, 2):
        v.set(3, y, 0, AIR)
    v.set(0, 2, 3, "minecraft:glass"); v.set(6, 2, 3, "minecraft:glass")
    v.set(3, 3, 3, LAMP)
    v.chest(1, 1, 5, "moon", "east")
    for y in range(5, 18):
        v.set(3, y, 3 + 0, "minecraft:iron_bars" if y > 5 else H)
    v.set(3, 18, 3, LAMP)
    for k in range(1, 4):
        v.set(3 + k, 12, 3, "minecraft:iron_bars"); v.set(3 - k, 12, 3, "minecraft:iron_bars")
    return v


def rover_wreck():
    v = Vox(41)
    v.shell(0, 1, 0, 9, 4, 5, H, fill_air=True)
    for x in range(1, 5):
        v.set(x, 4, 2, "minecraft:glass")
    for cx, cz in ((1, -1), (7, -1), (1, 5), (7, 5)):
        for dx in range(-1, 2):
            for dy in range(0, 3):
                if abs(dx) + abs(dy - 1) <= 2:
                    v.set(cx + dx, dy, cz, "minecraft:black_concrete")
    v.set(11, 0, 2, "minecraft:black_concrete"); v.set(12, 0, 2, "minecraft:black_concrete"); v.set(11, 1, 2, "minecraft:black_concrete")
    v.set(0, 2, 2, AIR); v.set(0, 3, 2, AIR)
    v.chest(7, 2, 2, "mars", "west")
    v.set(4, 3, 2, LAMP)
    return v


def drill_site():
    v = Vox(51)
    v.box(0, 0, 0, 7, 1, 7, H)
    for x, z in ((0, 0), (6, 0), (0, 6), (6, 6)):
        for y in range(1, 14):
            v.set(x, y, z, "minecraft:iron_bars")
    v.box(0, 13, 0, 7, 14, 7, H)
    for y in range(14, 20):
        v.set(3, y, 3, "minecraft:iron_bars")
    v.set(3, 20, 3, LAMP)
    for y in range(1, 13):
        v.set(3, y, 3, "minecraft:chain", {"axis": "y", "waterlogged": "false"} if y % 3 else None)
    v.box(2, 1, 2, 5, 2, 5, "minecraft:coal_block")
    v.chest(1, 1, 5, "mars", "east")
    return v


def lander_wreck():
    v = Vox(61)
    for x in range(0, 13):
        for z in range(0, 13):
            for y in range(0, 7):
                d = math.sqrt((x - 6) ** 2 + (y * 1.1) ** 2 + (z - 6) ** 2)
                if d <= 4.8 and y > 0:
                    v.set(x, y, z, AIR)
                elif 4.8 < d <= 5.9 and y >= 0:
                    v.set(x, y, z, v.mixed("minecraft:blackstone", HC, 0.45))
    for x, z in ((1, 1), (11, 1), (1, 11), (11, 11)):
        for y in range(0, 3):
            v.set(x, y, z, "minecraft:iron_bars")
    for y in (1, 2):
        v.set(6, y, 0, AIR); v.set(6, y, 1, AIR)
    v.chest(8, 1, 6, "venus", "west")
    v.set(6, 5, 6, LAMP)
    return v


def sulfur_refinery():
    v = Vox(71)
    for cx in (3, 11, 19):
        for x in range(cx - 2, cx + 3):
            for z in range(0, 5):
                d = math.hypot(x - cx, z - 2)
                for y in range(0, 9):
                    if d <= 2.4:
                        v.set(x, y, z + 0, H if (d > 1.4 or y in (0, 8)) else AIR)
    v.box(0, 9, 0, 22, 10, 5, "minecraft:iron_bars")
    v.shell(8, 0, 7, 15, 5, 12, "minecraft:blackstone")
    v.set(11, 1, 7, AIR); v.set(11, 2, 7, AIR)
    v.chest(9, 1, 10, "venus", "south")
    v.set(11, 3, 9, LAMP)
    for _ in range(18):
        v.set(v.rng.randint(0, 22), 0, v.rng.randint(5, 14), f"{MODID}:sulfur_block")
    return v


def ruined_tower():
    v = Vox(81)
    for y in range(0, 17):
        for x in range(0, 7):
            for z in range(0, 7):
                edge = x in (0, 6) or z in (0, 6)
                if edge and not (y > 10 and v.rng.random() < (y - 9) * 0.12):
                    v.set(x, y, z, v.mixed("minecraft:blackstone", HC, 0.3))
                elif not edge:
                    v.set(x, y, z, AIR)
    for y in (0,):
        v.set(3, 1, 0, AIR); v.set(3, 2, 0, AIR)
    v.box(1, 8, 1, 6, 9, 6, "minecraft:blackstone")
    v.chest(2, 9, 2, "venus", "east")
    v.set(4, 6, 3, LAMP)
    return v


def ice_station():
    v = Vox(91)
    for ox in (0, 12, 24):
        v.shell(ox, 0, 0, ox + 8, 5, 8, "minecraft:packed_ice")
        for y in (2, 3):
            v.set(ox + 3, y, 0, "minecraft:glass"); v.set(ox + 4, y, 0, "minecraft:glass")
        v.set(ox + 4, 3, 4, LAMP)
    for ox in (8, 20):
        v.shell(ox, 0, 2, ox + 4, 4, 5, H)
        for z in (3,):
            v.set(ox, 1, z, AIR); v.set(ox, 2, z, AIR); v.set(ox + 3, 1, z, AIR); v.set(ox + 3, 2, z, AIR)
    v.chest(2, 1, 5, "europa", "east"); v.chest(26, 1, 5, "europa", "west")
    return v


def crashed_probe():
    v = Vox(101)
    for x in range(0, 11):
        for y in range(0, 6):
            for z in range(0, 11):
                d = math.sqrt((x - 5) ** 2 + (y * 1.0) ** 2 + (z - 5) ** 2)
                if d <= 3.3 and y > 0:
                    v.set(x, y, z, AIR)
                elif d <= 4.6:
                    v.set(x, y, z, v.mixed("minecraft:iron_block", H, 0.4))
    for y in range(5, 13):
        v.set(5, y, 5, "minecraft:iron_bars")
    v.set(5, 13, 5, LAMP)
    v.set(5, 1, 0, AIR); v.set(5, 2, 0, AIR); v.set(5, 1, 1, AIR); v.set(5, 2, 1, AIR)
    v.chest(5, 1, 6, "europa", "north")
    return v


def cryo_lab():
    v = Vox(111)
    v.shell(0, 0, 0, 13, 6, 9, H)
    for x in range(2, 11, 2):
        for y in (1, 2, 3):
            v.set(x, y, 7, "minecraft:glass")
        v.set(x, 1, 7, "minecraft:blue_ice"); v.set(x, 2, 7, "minecraft:blue_ice")
    v.set(6, 1, 0, AIR); v.set(6, 2, 0, AIR)
    v.set(3, 4, 4, LAMP); v.set(9, 4, 4, LAMP)
    v.box(5, 1, 3, 8, 2, 4, "minecraft:iron_block")
    v.chest(1, 1, 1, "europa", "east"); v.chest(11, 1, 1, "europa", "west")
    return v


def alien_ruins():
    v = Vox(121)
    N, S = f"{MODID}:nova_stone", f"{MODID}:nova_soil"
    C = f"{MODID}:nova_crystal_block"
    for x in range(0, 17):
        for z in range(0, 17):
            d = math.hypot(x - 8, z - 8)
            if d <= 8:
                v.set(x, 0, z, N if v.rng.random() < 0.7 else S)
    for k in range(6):
        a = k * math.pi / 3
        px, pz = round(8 + 6 * math.cos(a)), round(8 + 6 * math.sin(a))
        h = 5 if k % 2 == 0 else 3
        for y in range(1, h + 1):
            v.set(px, y, pz, N)
        v.set(px, h + 1, pz, C)
    for k in range(0, 6, 2):
        a1, a2 = k * math.pi / 3, (k + 1) * math.pi / 3
        for t in range(0, 6):
            x = round(8 + 6 * math.cos(a1 + (a2 - a1) * t / 5)); z = round(8 + 6 * math.sin(a1 + (a2 - a1) * t / 5))
            v.set(x, 6, z, N)
    v.set(8, 1, 8, C); v.chest(8, 2, 8, "nova_prime", "south")
    return v


def crystal_spire():
    v = Vox(131)
    C = f"{MODID}:nova_crystal_block"
    N = f"{MODID}:nova_stone"
    for y in range(0, 24):
        r = max(0.5, 5.2 - y * 0.2)
        for x in range(-6, 7):
            for z in range(-6, 7):
                d = math.hypot(x, z)
                if d <= r and (y < 2 or d > r - 1.6 or y > 18):
                    v.set(x + 6, y, z + 6, C if (x + z + y) % 7 else N)
                elif d <= r:
                    v.set(x + 6, y, z + 6, AIR)
    for y in (1, 2):
        v.set(6, y, 0, AIR); v.set(6, y, 1, AIR); v.set(6, y, 2, AIR)
    v.chest(6, 1, 6, "nova_prime", "south")
    v.set(6, 6, 6, LAMP)
    return v


def warden_arena():
    v = Vox(141)
    N = f"{MODID}:nova_stone"
    C = f"{MODID}:nova_crystal_block"
    c = 15
    for x in range(0, 2 * c + 1):
        for z in range(0, 2 * c + 1):
            d = math.hypot(x - c, z - c)
            if d <= 14:
                v.set(x, 0, z, N if int(d) % 3 else C)
            if d <= 3.5:
                v.set(x, 1, z, N)
    for k in range(8):
        a = k * math.pi / 4
        px, pz = round(c + 12 * math.cos(a)), round(c + 12 * math.sin(a))
        for y in range(1, 9):
            v.set(px, y, pz, N)
        v.set(px, 9, pz, C)
    v.spawner(c, 2, c, f"{MODID}:nova_warden")
    v.chest(c - 3, 2, c, "nova_prime", "east"); v.chest(c + 3, 2, c, "nova_prime", "west")
    return v


BUILDERS = {"moon_crashed_rocket": moon_crashed_rocket, "moon_habitat": moon_habitat, "moon_antenna_outpost": antenna_outpost,
            "mars_rover_wreck": rover_wreck, "mars_dome_base": mars_dome_base, "mars_drill_site": drill_site,
            "venus_lander_wreck": lander_wreck, "venus_sulfur_refinery": sulfur_refinery, "venus_ruined_tower": ruined_tower,
            "europa_ice_station": ice_station, "europa_crashed_probe": crashed_probe, "europa_cryo_lab": cryo_lab,
            "nova_alien_ruins": alien_ruins, "nova_crystal_spire": crystal_spire, "nova_warden_arena": warden_arena}


def generate(write_json):
    import json
    total = 0
    for i, (sid, planet, spacing, sep) in enumerate(STRUCTURES):
        v = BUILDERS[sid]()
        total += v.save(os.path.join(DATA, "structure", f"{sid}.nbt"))
        biomes = [f"{MODID}:{b}" for b in PLANET[planet]["biomes"]]
        write_json(os.path.join(DATA, "worldgen", "structure", f"{sid}.json"), {
            "type": "minecraft:jigsaw", "biomes": biomes, "step": "surface_structures", "spawn_overrides": {},
            "terrain_adaptation": "beard_thin", "start_pool": f"{MODID}:{sid}/start", "size": 1,
            "start_height": {"absolute": -1}, "project_start_to_heightmap": "WORLD_SURFACE_WG",
            "max_distance_from_center": 80, "use_expansion_hack": False})
        write_json(os.path.join(DATA, "worldgen", "template_pool", sid, "start.json"), {
            "fallback": "minecraft:empty",
            "elements": [{"weight": 1, "element": {"element_type": "minecraft:single_pool_element", "location": f"{MODID}:{sid}",
                                                    "processors": "minecraft:empty", "projection": "rigid"}}]})
        write_json(os.path.join(DATA, "worldgen", "structure_set", f"{sid}.json"), {
            "structures": [{"structure": f"{MODID}:{sid}", "weight": 1}],
            "placement": {"type": "minecraft:random_spread", "spacing": spacing, "separation": sep, "salt": 710000 + i * 37}})
    return total
