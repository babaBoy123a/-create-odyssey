"""Single source of truth for Create: Odyssey. Generators read this file; Java Catalog is generated from it."""
import os

MODID = "create_odyssey"
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "src", "main", "resources")
JAVA = os.path.join(ROOT, "src", "main", "java", "com", "createodyssey")
ASSETS = os.path.join(RES, "assets", MODID)
DATA = os.path.join(RES, "data", MODID)
TIERS = [1, 2, 3, 4, 5]

ROCKET_NAMES = {1: ("Pionnière", "Pioneer"), 2: ("Éclaireuse", "Scout"), 3: ("Voyageuse", "Voyager"),
                4: ("Conquérante", "Conqueror"), 5: ("Stellaire", "Stellar")}
SUIT_NAMES = {1: ("Pionnier", "Pioneer"), 2: ("Éclaireur", "Scout"), 3: ("Voyageur", "Voyager"),
              4: ("Conquérant", "Conqueror"), 5: ("Stellaire", "Stellar")}
TIER_PRIMARY = {1: (236, 236, 240), 2: (150, 168, 190), 3: (206, 211, 222), 4: (74, 70, 86), 5: (150, 104, 232)}
TIER_ACCENT = {1: (232, 118, 40), 2: (56, 120, 214), 3: (206, 52, 52), 4: (236, 172, 50), 5: (244, 204, 92)}
# fuel grade needed by each rocket tier
ROCKET_FUEL = {1: "kerosene", 2: "kerosene", 3: "hydrolox", 4: "hydrolox", 5: "methalox"}
ROCKET_CAPACITY = {1: 3000, 2: 4500, 3: 6000, 4: 8000, 5: 12000}
ROCKET_SEATS = {1: 1, 2: 1, 3: 2, 4: 3, 5: 4}
ROCKET_W = {1: 1.6, 2: 1.6, 3: 2.8, 4: 3.0, 5: 3.2}
ROCKET_H = {1: 6.2, 2: 7.7, 3: 7.7, 4: 9.2, 5: 10.7}
PAD_SIZE = {1: 3, 2: 3, 3: 5, 4: 5, 5: 7}
SUIT_O2 = {1: 2000, 2: 3500, 3: 5500, 4: 8000, 5: 12000}
SUIT_COLD = {1: 1, 2: 2, 3: 2, 4: 4, 5: 5}
SUIT_HEAT = {1: 1, 2: 1, 3: 3, 4: 3, 5: 5}
SUIT_DEFENSE = {1: (2, 4, 3, 3), 2: (2, 5, 4, 3), 3: (3, 5, 4, 4), 4: (3, 6, 5, 4), 5: (3, 8, 6, 3)}  # helmet, chest, legs, boots
SUIT_TOUGH = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}
SUIT_DURA = {1: 25, 2: 30, 3: 35, 4: 42, 5: 50}

# id, french genitive ("d'acier"), english, color, has_sheet
METALS = [
    ("steel", "d'acier", "Steel", (122, 128, 140), True),
    ("titanium", "de titane", "Titanium", (170, 178, 192), True),
    ("chromium", "de chrome", "Chromium", (150, 176, 186), False),
    ("stainless_steel", "d'acier inoxydable", "Stainless Steel", (196, 202, 210), True),
    ("tungsten", "de tungstène", "Tungsten", (74, 70, 82), True),
    ("cryonium", "de cryonium", "Cryonium", (118, 212, 238), False),
    ("stellar_alloy", "d'alliage stellaire", "Stellar Alloy", (150, 110, 224), True),
]
METAL = {m[0]: m for m in METALS}

# ores: id, fr, en, drop item, base stone, ore color, hardness, tool tag, planet
ORES = [
    ("ilmenite_ore", "Minerai d'ilménite", "Ilmenite Ore", "raw_ilmenite", "moon_stone", (60, 52, 70), 3.0, "needs_iron_tool"),
    ("chromite_ore", "Minerai de chromite", "Chromite Ore", "raw_chromite", "mars_stone", (150, 150, 168), 3.2, "needs_iron_tool"),
    ("wolframite_ore", "Minerai de wolframite", "Wolframite Ore", "raw_wolframite", "venus_basalt", (96, 70, 60), 3.8, "needs_diamond_tool"),
    ("cryonite_ore", "Minerai de cryonite", "Cryonite Ore", "raw_cryonite", "europa_stone", (110, 220, 250), 3.8, "needs_diamond_tool"),
    ("stellarite_ore", "Minerai de stellarite", "Stellarite Ore", "stellarite_shard", "nova_stone", (170, 110, 250), 4.0, "needs_diamond_tool"),
]
RAW_ITEMS = [  # id, fr, en, color
    ("raw_ilmenite", "Ilménite brute", "Raw Ilmenite", (96, 80, 110)),
    ("crushed_ilmenite", "Ilménite broyée", "Crushed Ilmenite", (130, 112, 150)),
    ("raw_chromite", "Chromite brute", "Raw Chromite", (150, 150, 170)),
    ("crushed_chromite", "Chromite broyée", "Crushed Chromite", (180, 184, 204)),
    ("raw_wolframite", "Wolframite brute", "Raw Wolframite", (110, 80, 70)),
    ("crushed_wolframite", "Wolframite broyée", "Crushed Wolframite", (150, 116, 100)),
    ("raw_cryonite", "Cryonite brute", "Raw Cryonite", (110, 214, 242)),
    ("crushed_cryonite", "Cryonite broyée", "Crushed Cryonite", (160, 232, 250)),
]
MISC_ITEMS = [  # id, fr, en, color, kind
    ("ceramic_blend", "Mélange céramique", "Ceramic Blend", (214, 196, 178), "dust"),
    ("ceramic_tile", "Tuile thermique", "Heat Tile", (236, 228, 214), "tile"),
    ("polymer_sheet", "Plaque de polymère", "Polymer Sheet", (222, 226, 232), "sheet"),
    ("bitumen", "Bitume", "Bitumen", (36, 34, 32), "blob"),
]
DROPS = [  # id, fr, en, color, icon kind
    ("crawler_chitin", "Chitine de rampeur", "Crawler Chitin", (178, 178, 192), "shard"),
    ("suit_scrap", "Débris de combinaison", "Suit Scrap", (226, 226, 232), "scrap"),
    ("damaged_oxygen_canister", "Bonbonne d'oxygène endommagée", "Damaged Oxygen Canister", (120, 170, 204), "canister"),
    ("selene_fur", "Fourrure sélène", "Selene Fur", (236, 236, 242), "fur"),
    ("red_dust_core", "Noyau de poussière rouge", "Red Dust Core", (196, 76, 54), "orb"),
    ("scorpion_stinger", "Dard de scorpion", "Scorpion Stinger", (156, 76, 44), "stinger"),
    ("circuit_scrap", "Débris de circuit", "Circuit Scrap", (62, 154, 94), "scrap"),
    ("sulfur", "Soufre", "Sulfur", (238, 218, 62), "dust"),
    ("magma_gland", "Glande de magma", "Magma Gland", (244, 114, 32), "orb"),
    ("vulture_feather", "Plume de vautour acide", "Acid Vulture Feather", (156, 204, 62), "feather"),
    ("jelly_membrane", "Membrane de méduse", "Jelly Membrane", (212, 172, 232), "membrane"),
    ("burrower_scale", "Écaille de ver des glaces", "Burrower Scale", (172, 222, 242), "shard"),
    ("manta_membrane", "Membrane de raie", "Manta Membrane", (122, 182, 232), "membrane"),
    ("spore_gland", "Glande sporulée", "Spore Gland", (202, 74, 202), "orb"),
    ("star_dust", "Poussière d'étoile", "Star Dust", (242, 232, 124), "dust"),
    ("stellarite_shard", "Éclat de stellarite", "Stellarite Shard", (164, 112, 244), "shard"),
    ("star_core", "Noyau stellaire", "Star Core", (204, 164, 255), "core"),
    ("nova_core", "Noyau de Nova", "Nova Core", (255, 124, 224), "core"),
]

# rocket parts: id -> (fr, en, icon kind). tier suffix _tN is added.
PARTS = {
    "nose_cone": ("Cône de nez", "Nose Cone", "cone"),
    "hull_segment": ("Segment de coque", "Hull Segment", "hull"),
    "fuel_tank_module": ("Module de réservoir", "Fuel Tank Module", "tank"),
    "fin_set": ("Jeu d'ailerons", "Fin Set", "fins"),
    "combustion_chamber": ("Chambre de combustion", "Combustion Chamber", "chamber"),
    "rough_nozzle": ("Tuyère brute", "Rough Nozzle", "nozzle_rough"),
    "nozzle": ("Tuyère", "Nozzle", "nozzle"),
    "turbopump": ("Turbopompe", "Turbopump", "pump"),
    "engine": ("Moteur de fusée", "Rocket Engine", "engine"),
    "avionics": ("Ordinateur de bord", "Flight Computer", "avionics"),
    "cockpit": ("Cockpit", "Cockpit", "cockpit"),
    "booster": ("Propulseur d'appoint", "Booster", "booster"),
    "landing_gear": ("Train d'atterrissage", "Landing Gear", "gear"),
}
TRANSITIONAL = ["nose_cone", "hull_segment", "fuel_tank_module", "turbopump", "avionics"]


def part_ids(tier):
    out = ["nose_cone", "hull_segment", "fuel_tank_module", "fin_set", "combustion_chamber", "rough_nozzle",
           "nozzle", "turbopump", "engine", "avionics", "cockpit"]
    if tier >= 3:
        out += ["booster", "landing_gear"]
    return out


# per-tier ingredient choices
PLATE = {1: "steel_sheet", 2: "titanium_sheet", 3: "stainless_steel_sheet", 4: "tungsten_sheet", 5: "stellar_alloy_sheet"}
SECOND_PLATE = {1: "create:iron_sheet", 2: "steel_sheet", 3: "titanium_sheet", 4: "stainless_steel_sheet", 5: "tungsten_sheet"}
RIVET = {1: "steel_nugget", 2: "titanium_nugget", 3: "chromium_nugget", 4: "tungsten_nugget", 5: "cryonium_nugget"}
ALLOY_BLOCK = {1: "steel_block", 2: "titanium_block", 3: "stainless_steel_block", 4: "tungsten_block", 5: "stellar_alloy_block"}
SUIT_MAT = {1: "leather", 2: "selene_fur", 3: "red_dust_core", 4: "vulture_feather", 5: "manta_membrane"}

FLUIDS = [  # id, fr, en, color, density, viscosity, temperature
    ("crude_oil", "Pétrole brut", "Crude Oil", (34, 30, 26), 1100, 3000, 300),
    ("kerosene", "Kérosène", "Kerosene", (232, 202, 84), 800, 1200, 300),
    ("hydrogen", "Hydrogène", "Hydrogen", (204, 232, 255), 600, 500, 290),
    ("oxygen", "Oxygène", "Oxygen", (150, 202, 255), 700, 500, 290),
    ("liquid_hydrogen", "Hydrogène liquide", "Liquid Hydrogen", (172, 202, 255), 900, 600, 20),
    ("liquid_oxygen", "Oxygène liquide", "Liquid Oxygen", (92, 142, 242), 1100, 700, 90),
    ("methane", "Méthane", "Methane", (190, 212, 160), 650, 500, 290),
    ("liquid_methane", "Méthane liquide", "Liquid Methane", (150, 182, 110), 450, 700, 110),
    ("hydrolox", "Hydrolox", "Hydrolox", (142, 192, 255), 950, 800, 25),
    ("methalox", "Méthalox", "Methalox", (120, 214, 172), 900, 900, 100),
    ("insulating_resin", "Résine isolante", "Insulating Resin", (232, 212, 172), 1200, 4000, 300),
]

# planet blocks: id, fr, en, hardness, style
PLANET_BLOCKS = [
    ("moon_regolith", "Régolithe lunaire", "Lunar Regolith", 0.6, "dust"),
    ("moon_stone", "Roche lunaire", "Moon Rock", 1.5, "rock"),
    ("mars_sand", "Sable martien", "Martian Sand", 0.5, "sand"),
    ("mars_stone", "Roche martienne", "Martian Rock", 1.5, "rock"),
    ("venus_ash", "Cendres vénusiennes", "Venusian Ash", 0.6, "dust"),
    ("venus_basalt", "Basalte vénusien", "Venusian Basalt", 1.8, "rock"),
    ("sulfur_block", "Bloc de soufre", "Sulfur Block", 1.0, "crystal"),
    ("europa_ice", "Glace d'Europe", "Europan Ice", 0.5, "ice"),
    ("europa_stone", "Croûte d'Europe", "Europan Crust", 1.5, "rock"),
    ("methane_ice", "Glace de méthane", "Methane Ice", 0.8, "ice"),
    ("nova_soil", "Sol de Nova", "Nova Soil", 0.6, "dust"),
    ("nova_stone", "Roche de Nova", "Nova Rock", 1.6, "rock"),
    ("nova_crystal_block", "Cristal de Nova", "Nova Crystal", 1.5, "crystal"),
    ("oil_shale", "Schiste bitumineux", "Oil Shale", 1.8, "shale"),
    ("hull_plating", "Plaque de coque", "Hull Plating", 3.0, "plating"),
    ("cracked_hull_plating", "Plaque de coque fissurée", "Cracked Hull Plating", 3.0, "plating_cracked"),
    ("habitat_lamp", "Lampe d'habitat", "Habitat Lamp", 1.0, "lamp"),
]
SURFACE = {"moon": ("moon_regolith", "moon_stone"), "mars": ("mars_sand", "mars_stone"),
           "venus": ("venus_ash", "venus_basalt"), "europa": ("europa_ice", "europa_stone"),
           "nova_prime": ("nova_soil", "nova_stone")}

PLANETS = [  # id, fr, en, tier, gravity, cold, heat, cost, sky, fog, terrain amplitude, biomes
    dict(id="moon", fr="Lune", en="Moon", tier=1, gravity=0.16, cold=1, heat=0, cost=1000, sky=(0, 0, 0), fog=(14, 14, 18),
         amp=0.16, fluid=None, biomes=("moon_plains", "moon_craters"), time=6000),
    dict(id="mars", fr="Mars", en="Mars", tier=2, gravity=0.38, cold=2, heat=0, cost=1500, sky=(142, 84, 60), fog=(176, 104, 74),
         amp=0.32, fluid=None, biomes=("mars_dunes", "mars_canyons"), time=6000),
    dict(id="venus", fr="Vénus", en="Venus", tier=3, gravity=0.90, cold=0, heat=3, cost=2000, sky=(176, 154, 66), fog=(206, 176, 76),
         amp=0.28, fluid="lava", biomes=("venus_ashlands", "venus_volcanic"), time=6000),
    dict(id="europa", fr="Europe", en="Europa", tier=4, gravity=0.13, cold=4, heat=0, cost=2500, sky=(8, 16, 36), fog=(120, 172, 204),
         amp=0.14, fluid="water", biomes=("europa_ice_sheet", "europa_fractured"), time=6000),
    dict(id="nova_prime", fr="Nova Prime", en="Nova Prime", tier=5, gravity=1.10, cold=5, heat=5, cost=4000, sky=(70, 24, 104),
         fog=(120, 44, 150), amp=0.30, fluid=None, biomes=("nova_glowforest", "nova_crystal_fields"), time=None),
]
PLANET = {p["id"]: p for p in PLANETS}

# ore features per planet: (ore block, target stone, vein size, count per chunk, min y, max y)
PLANET_ORES = {
    "moon": [("ilmenite_ore", "moon_stone", 9, 14, -50, 90)],
    "mars": [("chromite_ore", "mars_stone", 8, 12, -50, 90)],
    "venus": [("wolframite_ore", "venus_basalt", 7, 10, -50, 80), ("sulfur_block", "venus_basalt", 10, 6, -20, 90)],
    "europa": [("cryonite_ore", "europa_stone", 7, 10, -50, 80), ("methane_ice", "europa_ice", 12, 8, -10, 90)],
    "nova_prime": [("stellarite_ore", "nova_stone", 6, 8, -50, 80), ("nova_crystal_block", "nova_stone", 8, 6, -20, 90)],
}

# mobs: id, planet, behavior(hostile|neutral|passive), flying, hp, dmg, speed, w, h, effect, leap, explode, boss, armor, kbres, weight, min, max, egg, plan, palette(base, dark, accent), style
MOBS = [
    dict(id="lunar_crawler", fr="Rampeur lunaire", en="Lunar Crawler", planet="moon", behavior="hostile", flying=False, hp=20, dmg=4, speed=0.30, w=1.0, h=0.6, effect="none", leap=True, explode=False, boss=False, armor=2, kb=0.0, weight=40, mn=2, mx=4, plan="crawler", pal=((150, 150, 162), (74, 74, 88), (232, 90, 70)), style="chitin"),
    dict(id="lost_astronaut", fr="Cosmonaute perdu", en="Lost Astronaut", planet="moon", behavior="hostile", flying=False, hp=30, dmg=5, speed=0.22, w=0.7, h=1.9, effect="none", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=25, mn=1, mx=2, plan="astronaut", pal=((226, 226, 232), (150, 150, 160), (232, 120, 40)), style="suit"),
    dict(id="selene_hopper", fr="Lièvre sélène", en="Selene Hopper", planet="moon", behavior="passive", flying=False, hp=6, dmg=0, speed=0.28, w=0.5, h=0.8, effect="none", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=30, mn=2, mx=4, plan="hopper", pal=((236, 236, 244), (190, 190, 204), (60, 60, 80)), style="fur"),
    dict(id="dust_devil", fr="Diable de poussière", en="Dust Devil", planet="mars", behavior="hostile", flying=False, hp=24, dmg=3, speed=0.35, w=0.9, h=1.9, effect="blind", leap=False, explode=False, boss=False, armor=0, kb=0.4, weight=15, mn=1, mx=1, plan="devil", pal=((200, 120, 84), (140, 76, 52), (255, 210, 150)), style="dust"),
    dict(id="iron_scorpion", fr="Scorpion de fer", en="Iron Scorpion", planet="mars", behavior="hostile", flying=False, hp=28, dmg=6, speed=0.28, w=1.2, h=0.9, effect="poison", leap=False, explode=False, boss=False, armor=6, kb=0.0, weight=30, mn=1, mx=3, plan="scorpion", pal=((150, 72, 48), (92, 44, 30), (240, 200, 60)), style="chitin"),
    dict(id="rusted_drone", fr="Drone rouillé", en="Rusted Drone", planet="mars", behavior="neutral", flying=True, hp=16, dmg=4, speed=0.5, w=0.8, h=1.0, effect="none", leap=False, explode=False, boss=False, armor=2, kb=0.0, weight=20, mn=1, mx=2, plan="drone", pal=((140, 96, 70), (84, 58, 44), (80, 220, 255)), style="metal"),
    dict(id="magma_slug", fr="Limace de magma", en="Magma Slug", planet="venus", behavior="hostile", flying=False, hp=34, dmg=5, speed=0.2, w=1.2, h=0.7, effect="fire", leap=False, explode=False, boss=False, armor=0, kb=0.2, weight=30, mn=1, mx=2, plan="slug", pal=((120, 46, 28), (60, 26, 20), (255, 150, 40)), style="glow"),
    dict(id="acid_vulture", fr="Vautour acide", en="Acid Vulture", planet="venus", behavior="hostile", flying=True, hp=22, dmg=5, speed=0.6, w=1.2, h=0.9, effect="poison", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=20, mn=1, mx=2, plan="vulture", pal=((96, 112, 52), (54, 66, 34), (190, 255, 70)), style="feather"),
    dict(id="cloud_jelly", fr="Méduse nuageuse", en="Cloud Jelly", planet="venus", behavior="neutral", flying=True, hp=10, dmg=2, speed=0.1, w=0.9, h=1.1, effect="nausea", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=20, mn=1, mx=3, plan="jelly", pal=((212, 172, 232), (150, 110, 190), (255, 240, 120)), style="glow"),
    dict(id="frost_golem", fr="Golem de givre", en="Frost Golem", planet="europa", behavior="hostile", flying=False, hp=60, dmg=8, speed=0.2, w=1.4, h=2.5, effect="slow", leap=False, explode=False, boss=False, armor=4, kb=0.8, weight=20, mn=1, mx=1, plan="golem", pal=((176, 220, 240), (96, 150, 190), (120, 255, 255)), style="crystal"),
    dict(id="ice_burrower", fr="Ver des banquises", en="Ice Burrower", planet="europa", behavior="hostile", flying=False, hp=30, dmg=6, speed=0.3, w=1.0, h=0.6, effect="slow", leap=False, explode=False, boss=False, armor=2, kb=0.0, weight=25, mn=1, mx=2, plan="burrower", pal=((190, 226, 240), (110, 160, 190), (255, 255, 255)), style="chitin"),
    dict(id="ice_manta", fr="Raie des glaces", en="Ice Manta", planet="europa", behavior="passive", flying=True, hp=20, dmg=0, speed=0.4, w=1.6, h=0.5, effect="none", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=15, mn=1, mx=2, plan="manta", pal=((120, 182, 232), (70, 120, 180), (230, 250, 255)), style="fur"),
    dict(id="spore_stalker", fr="Traqueur sporulé", en="Spore Stalker", planet="nova_prime", behavior="hostile", flying=False, hp=40, dmg=7, speed=0.32, w=0.7, h=2.0, effect="poison", leap=False, explode=False, boss=False, armor=0, kb=0.0, weight=25, mn=1, mx=2, plan="stalker", pal=((82, 44, 96), (46, 24, 62), (230, 80, 230)), style="glow"),
    dict(id="starswarm", fr="Essaim stellaire", en="Starswarm", planet="nova_prime", behavior="hostile", flying=True, hp=8, dmg=3, speed=0.5, w=0.4, h=0.4, effect="none", leap=False, explode=True, boss=False, armor=0, kb=0.0, weight=30, mn=3, mx=6, plan="swarm", pal=((250, 240, 140), (200, 170, 70), (255, 255, 255)), style="glow"),
    dict(id="crystal_colossus", fr="Colosse cristallin", en="Crystal Colossus", planet="nova_prime", behavior="hostile", flying=False, hp=120, dmg=12, speed=0.2, w=1.8, h=2.9, effect="none", leap=False, explode=False, boss=False, armor=8, kb=1.0, weight=8, mn=1, mx=1, plan="colossus", pal=((120, 80, 190), (70, 44, 120), (210, 160, 255)), style="crystal"),
    dict(id="nova_warden", fr="Gardien de Nova", en="Nova Warden", planet="nova_prime", behavior="hostile", flying=True, hp=600, dmg=14, speed=0.3, w=2.4, h=2.6, effect="wither", leap=False, explode=False, boss=True, armor=10, kb=1.0, weight=0, mn=1, mx=1, plan="warden", pal=((90, 60, 150), (44, 28, 90), (255, 110, 230)), style="crystal"),
]
MOB = {m["id"]: m for m in MOBS}

# loot: mob id -> list of (item, min, max, chance)
MOB_LOOT = {
    "lunar_crawler": [("crawler_chitin", 0, 2, 1.0), ("raw_ilmenite", 1, 1, 0.12)],
    "lost_astronaut": [("suit_scrap", 1, 2, 1.0), ("damaged_oxygen_canister", 1, 1, 0.3), ("titanium_nugget", 1, 2, 0.25)],
    "selene_hopper": [("selene_fur", 1, 2, 1.0)],
    "dust_devil": [("red_dust_core", 1, 1, 0.7)],
    "iron_scorpion": [("scorpion_stinger", 1, 1, 0.7), ("raw_chromite", 1, 2, 0.4)],
    "rusted_drone": [("circuit_scrap", 1, 2, 1.0), ("create:electron_tube", 1, 1, 0.15), ("steel_sheet", 1, 1, 0.3)],
    "magma_slug": [("sulfur", 1, 3, 1.0), ("magma_gland", 1, 1, 0.5)],
    "acid_vulture": [("vulture_feather", 1, 3, 1.0)],
    "cloud_jelly": [("jelly_membrane", 1, 2, 1.0)],
    "frost_golem": [("raw_cryonite", 1, 3, 1.0)],
    "ice_burrower": [("burrower_scale", 1, 2, 1.0)],
    "ice_manta": [("manta_membrane", 1, 2, 1.0)],
    "spore_stalker": [("spore_gland", 1, 1, 0.7)],
    "starswarm": [("star_dust", 0, 1, 0.8)],
    "crystal_colossus": [("stellarite_shard", 2, 4, 1.0)],
    "nova_warden": [("nova_core", 1, 1, 1.0), ("stellarite_shard", 4, 8, 1.0), ("star_core", 1, 1, 0.5)],
}
# chest loot per planet: (item, min, max, weight)
CHEST_LOOT = {
    "moon": [("steel_sheet", 2, 6, 10), ("polymer_sheet", 1, 3, 8), ("ceramic_tile", 1, 4, 8), ("damaged_oxygen_canister", 1, 1, 4), ("suit_scrap", 1, 3, 8), ("create:iron_sheet", 2, 5, 8), ("create:precision_mechanism", 1, 1, 2)],
    "mars": [("titanium_sheet", 1, 4, 10), ("circuit_scrap", 1, 3, 8), ("create:electron_tube", 1, 3, 6), ("steel_ingot", 2, 6, 8), ("red_dust_core", 1, 1, 3), ("create:precision_mechanism", 1, 2, 4)],
    "venus": [("stainless_steel_sheet", 1, 4, 10), ("sulfur", 2, 6, 8), ("titanium_ingot", 1, 3, 8), ("chromium_ingot", 1, 3, 6), ("create:brass_ingot", 2, 5, 6)],
    "europa": [("tungsten_ingot", 1, 3, 8), ("tungsten_sheet", 1, 3, 8), ("stainless_steel_ingot", 2, 5, 8), ("manta_membrane", 1, 2, 4), ("polymer_sheet", 2, 5, 6)],
    "nova_prime": [("stellar_alloy_ingot", 1, 3, 8), ("star_dust", 2, 5, 8), ("stellarite_shard", 1, 3, 6), ("cryonium_ingot", 1, 3, 6), ("star_core", 1, 1, 2)],
}

PLANET_FR = {p["id"]: p["fr"] for p in PLANETS}
PLANET_EN = {p["id"]: p["en"] for p in PLANETS}

STRUCTURES = [  # id, planet, biomes, spacing, separation
    ("moon_crashed_rocket", "moon", 22, 8), ("moon_habitat", "moon", 26, 10), ("moon_antenna_outpost", "moon", 20, 8),
    ("mars_rover_wreck", "mars", 22, 8), ("mars_dome_base", "mars", 26, 10), ("mars_drill_site", "mars", 20, 8),
    ("venus_lander_wreck", "venus", 22, 8), ("venus_sulfur_refinery", "venus", 26, 10), ("venus_ruined_tower", "venus", 20, 8),
    ("europa_ice_station", "europa", 24, 10), ("europa_crashed_probe", "europa", 22, 8), ("europa_cryo_lab", "europa", 26, 10),
    ("nova_alien_ruins", "nova_prime", 22, 8), ("nova_crystal_spire", "nova_prime", 22, 8), ("nova_warden_arena", "nova_prime", 40, 14),
]
STRUCTURE_NAMES = {
    "moon_crashed_rocket": ("Fusée écrasée (Lune)", "Crashed Rocket (Moon)"), "moon_habitat": ("Habitat lunaire", "Lunar Habitat"),
    "moon_antenna_outpost": ("Avant-poste à antenne", "Antenna Outpost"), "mars_rover_wreck": ("Épave de rover", "Rover Wreck"),
    "mars_dome_base": ("Base à dôme martienne", "Martian Dome Base"), "mars_drill_site": ("Site de forage", "Drill Site"),
    "venus_lander_wreck": ("Épave d'atterrisseur", "Lander Wreck"), "venus_sulfur_refinery": ("Raffinerie de soufre", "Sulfur Refinery"),
    "venus_ruined_tower": ("Tour en ruine", "Ruined Tower"), "europa_ice_station": ("Station glaciaire", "Ice Station"),
    "europa_crashed_probe": ("Sonde écrasée", "Crashed Probe"), "europa_cryo_lab": ("Laboratoire cryogénique", "Cryo Lab"),
    "nova_alien_ruins": ("Ruines extraterrestres", "Alien Ruins"), "nova_crystal_spire": ("Flèche de cristal", "Crystal Spire"),
    "nova_warden_arena": ("Arène du Gardien", "Warden Arena"),
}

# ---------- names for generic things ----------
PART_FR_T = "{} (T{})"


def tier_name_fr(tier):
    return ROCKET_NAMES[tier][0]


def simple_item_ids():
    ids = []
    for m in METALS:
        ids += [f"{m[0]}_ingot", f"{m[0]}_nugget"]
        if m[4]:
            ids.append(f"{m[0]}_sheet")
    ids += [r[0] for r in RAW_ITEMS] + [m[0] for m in MISC_ITEMS] + [d[0] for d in DROPS]
    for t in TIERS:
        ids += [f"{p}_t{t}" for p in part_ids(t)]
    return ids


def transitional_ids():
    return [f"incomplete_{p}_t{t}" for t in TIERS for p in TRANSITIONAL]
