# Create: Odyssey (addon pour Create — NeoForge 1.21.1)

Exploration spatiale en 5 tiers : 5 fusées, 5 planètes, combinaisons à réservoir d'oxygène, carburant raffiné à l'électricité,
16 créatures + 1 boss, 15 structures. Tout est fabriqué avec les machines de Create (presse, mixeur, concasseur, assemblage séquentiel…).

## État du projet (important)
- Les sources, les 700+ fichiers de ressources, les 15 structures (.nbt) et les textures sont générés et **validés statiquement**
  (syntaxe Java, JSON, textures, langues, recettes, structures : `python3 tools/validate.py`).
- Le projet **n'a pas encore été compilé ni lancé dans Minecraft** : l'environnement où il a été écrit n'avait pas accès aux dépôts
  Maven de NeoForge / Create / Mojang. Voir `RISQUES.md` : une première compilation peut révéler quelques erreurs à corriger.

## Compiler (obtenir le .jar à glisser dans `mods/`)
Prérequis : JDK 21, accès internet.
```
./build.sh        # Linux / macOS   (ou : ./gradlew build)
build.bat         # Windows
```
Le fichier produit est `build/libs/create_odyssey-1.0.0.jar`. Il se glisse dans le dossier `mods` d'une instance
**NeoForge 1.21.1** qui contient **Create 6.0.10 ou plus**. Aucun autre mod n'est requis (voir `MODS_UTILISES.md`).

## Pourquoi 1.21.1 et pas 26.x ?
Au 12 octobre 2026, Minecraft Java est en 26.3, mais Create n'est pas encore publié officiellement pour 26.x (portage « en cours »).
1.21.1 est la version la plus récente de Minecraft pour laquelle Create existe. Le jar ne marche ni sur Forge ni sur une autre version.

## Régénérer les ressources
`python3 tools/gen_all.py` (Pillow + numpy) régénère textures, modèles, recettes, loot, tags, advancements, worldgen, structures,
les fichiers de langue et le catalogue Java (`Catalog.java`, `MobSpecs.java`, `GeneratedModels.java`) depuis `tools/catalog.py`.
Pour changer un nom, un coût ou une planète : modifiez `tools/catalog.py`, relancez le script, recompilez.

## Dépannage
Commandes de test : `/give @s create_odyssey:rocket_t1`, `/execute in create_odyssey:moon run tp @s 8 100 8`.
Les paramètres (oxygène, dégâts, hauteur d'ascension, coûts de carburant, énergie des machines) sont dans
`config/create_odyssey-common.toml`.
