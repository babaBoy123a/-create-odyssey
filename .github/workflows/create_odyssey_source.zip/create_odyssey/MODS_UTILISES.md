# Mods utilisés

| Mod | Rôle | Requis ? | Version | Loader | Lien |
|---|---|---|---|---|---|
| Create | Dépendance principale : machines, recettes (pressage, mixage, assemblage séquentiel…), cinétique, tuyaux, becs verseurs | **Oui** | 6.0.10 ou plus (compilé contre 6.0.11-312) | NeoForge 1.21.1 | https://modrinth.com/mod/create |
| NeoForge | Loader | **Oui** | 21.1.x (21.1.0 ou plus) | — | https://neoforged.net |

- Flywheel, Ponder et Registrate sont embarqués par Create 6.x (jar-in-jar) : rien à ajouter. Si votre version de Create ne les embarque
  pas, installez les versions demandées par Create.
- Aucun autre mod n'est nécessaire. GeckoLib n'est volontairement **pas** utilisé : les modèles 3D sont des cubes générés (voir `tools/models.py`).
- Compatibilité : énergie en FE (compatible avec les câbles/machines des autres mods), fluides NeoForge (tuyaux, pompes et cuves de Create),
  tags communs `c:ingots/*`, `c:plates/*`, `c:nuggets/*`, `c:storage_blocks/*`.
- JEI / EMI : non requis ; les recettes Create de l'addon apparaissent automatiquement avec leurs propres catégories.
