@echo off
rem Builds the mod. Needs: JDK 21 and internet access (Gradle downloads NeoForge, Minecraft and Create on first run).
cd /d "%~dp0"
python tools\gen_all.py 2>nul || echo (python not found: using the pre-generated resources)
call gradlew.bat build
echo.
echo Done. Your mod is in build\libs\create_odyssey-1.0.0.jar
echo Drop it in the mods folder of a NeoForge 1.21.1 instance that has Create 6.0.10+.
pause
