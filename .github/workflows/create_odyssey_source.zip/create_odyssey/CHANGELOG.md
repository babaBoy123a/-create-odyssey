# 1.0.0
- Première version : 5 fusées, 5 planètes, combinaisons spatiales, raffinage électrique, 16 créatures + boss, 15 structures.
